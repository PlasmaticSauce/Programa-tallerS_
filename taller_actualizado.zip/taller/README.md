# Taller Mecánico - Clientes, Vehículos, Órdenes y Pagos

## Módulos

- Clientes con historial de servicios.
- Catálogo de vehículos por cliente.
- Relación Cliente → Vehículo → Orden de trabajo.
- **Catálogo de Servicios** con precio, para armar conceptos dentro de una orden
  (cantidad × precio = subtotal). El costo total de la orden se calcula solo si
  se capturan conceptos; si no, se usa el campo "Costo total" a mano.
- Control de pagos por orden (abonos parciales), con edición y borrado de pagos
  mal capturados.
- Dashboard con indicadores operativos y financieros.
- Reportes: resumen general, reporte de órdenes finalizadas por día, y
  exportación a Excel.
- Impresión y exportación a PDF de la orden de trabajo, con los datos del
  taller, los conceptos con precio, el historial de pagos y espacio de firma.
- Historial por cliente y por vehículo.
- Pestaña general de historial con búsqueda y filtro por estado.
- Respaldo mensual de la base de datos + Excel, con opción de copiarlo también
  a otra ubicación (USB, disco externo, carpeta en la nube).
- Migración automática de una base anterior que guardaba vehículo y placas
  directamente en las órdenes.

## Datos del taller para el PDF

Edita `app/config.py` con el nombre, dirección, teléfono y correo del taller.
Si colocas un logo en `data/logo.png`, aparece automáticamente en el encabezado.

## Ejecutar

```bash
pip install -r requirements.txt
python main.py
```

La base de datos se crea en `data/taller.db`.

## Notas sobre esta actualización

- Los tres estados de una orden ahora son "Recibido", "Diagnóstico" y
  "Terminado" (antes decía "Terminando").
- Se agregó una fecha de cierre real, distinta de la fecha de ingreso: el
  "Reporte de hoy" y el respaldo mensual ahora filtran por el día en que la
  orden se marcó como Terminado, no por el día en que ingresó.
- Si esta base ya venía de una versión anterior con el error que cerraba por
  accidente las órdenes en "En reparación" o "Esperando refacción", esa
  migración ya no se puede deshacer automáticamente (no se guardó el estado
  original). Conviene revisar a mano las órdenes antiguas que no recuerdes
  haber cerrado.
- El uso de la misma base de datos desde dos computadoras a la vez (por red)
  no es seguro con SQLite; si necesitan varias estaciones de trabajo al mismo
  tiempo, conviene migrar a un servidor de base de datos más adelante.
