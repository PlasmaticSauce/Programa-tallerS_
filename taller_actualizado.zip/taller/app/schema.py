"""Modelo de datos del sistema del taller.

La aplicación se construye a partir de estas entidades. Clientes, vehículos y
órdenes están relacionados para conservar el historial completo de cada unidad.
"""
from dataclasses import dataclass


@dataclass(frozen=True)
class Field:
    key: str
    label: str
    kind: str = "text"  # text | multiline | number | date | choice | ref
    required: bool = False
    options: tuple[str, ...] = ()
    ref: str = ""
    in_table: bool = True


@dataclass(frozen=True)
class Entity:
    table: str
    title: str
    singular: str
    fields: tuple[Field, ...]


ESTADOS = (
    "Recibido",
    "Diagnóstico",
    "Terminado",
)
ESTADOS_CERRADOS = ("Terminado",)
ESTADO_COBRADO = "Terminado"
METODOS_PAGO = ("Efectivo", "Transferencia", "Tarjeta", "Depósito", "Otro")

CLIENTES = Entity(
    "clientes", "Clientes", "cliente",
    (
        Field("nombre", "Nombre", required=True),
        Field("telefono", "Teléfono"),
        Field("correo", "Correo"),
        Field("direccion", "Dirección"),
        Field("notas", "Notas", "multiline", in_table=False),
    ),
)

VEHICULOS = Entity(
    "vehiculos", "Vehículos", "vehículo",
    (
        Field("cliente_id", "Cliente", "ref", required=True, ref="clientes"),
        Field("marca", "Marca", required=True),
        Field("modelo", "Modelo", required=True),
        Field("anio", "Año"),
        Field("version", "Versión"),
        Field("placas", "Placas"),
        Field("vin", "VIN / NIV"),
        Field("kilometraje", "Kilometraje"),
        Field("color", "Color"),
        Field("notas", "Notas", "multiline", in_table=False),
    ),
)

PROVEEDORES = Entity(
    "proveedores", "Proveedores", "proveedor",
    (
        Field("empresa", "Empresa", required=True),
        Field("contacto", "Contacto"),
        Field("telefono", "Teléfono"),
        Field("correo", "Correo"),
        Field("productos", "Productos que surte", "multiline"),
        Field("notas", "Notas", "multiline", in_table=False),
    ),
)

SERVICIOS = Entity(
    "servicios", "Servicios", "servicio",
    (
        Field("nombre", "Servicio", required=True),
        Field("precio", "Precio", "number", required=True),
        Field("descripcion", "Descripción", "multiline", in_table=False),
    ),
)

ORDENES = Entity(
    "ordenes", "Órdenes de trabajo", "orden",
    (
        Field("fecha", "Fecha de ingreso", "date", required=True),
        Field("cliente_id", "Cliente", "ref", required=True, ref="clientes"),
        Field("vehiculo_id", "Vehículo", "ref", required=True, ref="vehiculos"),
        Field("servicio", "Servicio a realizar", "multiline", required=True),
        Field("estado", "Estado", "choice", options=ESTADOS),
        Field("costo", "Costo total", "number"),
        Field("notas", "Notas", "multiline", in_table=False),
    ),
)

# El orden importa: las tablas referenciadas deben existir antes de las que las usan.
ENTITIES = {e.table: e for e in (CLIENTES, VEHICULOS, PROVEEDORES, SERVICIOS, ORDENES)}
