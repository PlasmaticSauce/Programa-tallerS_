"""Conceptos (servicios con precio) capturados dentro de una orden de trabajo."""
from PySide6.QtWidgets import (
    QAbstractItemView, QComboBox, QDialog, QDialogButtonBox, QDoubleSpinBox,
    QFormLayout, QHBoxLayout, QHeaderView, QLabel, QLineEdit, QMessageBox,
    QPushButton, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget,
)


class OrderItemDialog(QDialog):
    """Alta / edición de un concepto de una orden.

    Si se elige un servicio del catálogo, la descripción y el precio se
    autocompletan (y se pueden ajustar) para no tener que escribirlos a mano
    cada vez.
    """
    def __init__(self, parent, db, item: dict | None = None):
        super().__init__(parent)
        self.db = db
        self.result_values: dict | None = None
        self.setWindowTitle("Editar concepto" if item else "Agregar concepto")
        self.setMinimumWidth(460)

        self.service = QComboBox()
        self.service.addItem("Otro (descripción libre) — no está en el catálogo", None)
        self._services = {sid: (nombre, precio) for sid, nombre, precio in db.service_options()}
        for sid, (nombre, precio) in self._services.items():
            self.service.addItem(f"{nombre} · ${precio:,.2f}", sid)
        self.service.currentIndexChanged.connect(self._service_selected)

        self.description = QLineEdit()
        self.quantity = QDoubleSpinBox()
        self.quantity.setRange(0.01, 9999)
        self.quantity.setDecimals(2)
        self.quantity.setValue(1)
        self.price = QDoubleSpinBox()
        self.price.setRange(0, 99_999_999)
        self.price.setDecimals(2)
        self.price.setPrefix("$ ")
        self.price.setGroupSeparatorShown(True)

        form = QFormLayout(); form.setSpacing(12)
        form.addRow("Servicio del catálogo", self.service)
        form.addRow("Descripción *", self.description)
        form.addRow("Cantidad", self.quantity)
        form.addRow("Precio unitario", self.price)

        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        buttons.button(QDialogButtonBox.StandardButton.Save).setText("Guardar")
        buttons.button(QDialogButtonBox.StandardButton.Save).setObjectName("primary")
        buttons.button(QDialogButtonBox.StandardButton.Cancel).setText("Cancelar")
        buttons.accepted.connect(self._validate_and_accept)
        buttons.rejected.connect(self.reject)

        layout = QVBoxLayout(self); layout.setContentsMargins(24, 24, 24, 20); layout.setSpacing(16)
        layout.addLayout(form)
        layout.addWidget(buttons)

        if item:
            idx = self.service.findData(item.get("servicio_id"))
            if idx >= 0:
                self.service.setCurrentIndex(idx)
            self.description.setText(item.get("descripcion") or "")
            self.quantity.setValue(float(item.get("cantidad") or 1))
            self.price.setValue(float(item.get("precio_unitario") or 0))

    def _service_selected(self) -> None:
        sid = self.service.currentData()
        if sid is None:
            return
        nombre, precio = self._services[sid]
        if not self.description.text().strip():
            self.description.setText(nombre)
        self.price.setValue(precio)

    def _validate_and_accept(self) -> None:
        description = self.description.text().strip()
        if not description:
            QMessageBox.warning(self, "Falta información", "Escribe una descripción para el concepto.")
            return
        self.result_values = {
            "servicio_id": self.service.currentData(),
            "descripcion": description,
            "cantidad": self.quantity.value(),
            "precio_unitario": self.price.value(),
        }
        self.accept()


class OrderItemsEditor(QWidget):
    """Tabla de conceptos con botones para agregar/editar/eliminar, lista para
    incrustarse tanto en el formulario de alta/edición de una orden como en
    el detalle de una orden ya guardada.

    Mantiene la lista de conceptos en memoria (self.items); quien lo use decide
    cuándo guardarla en la base de datos (ver Database.set_order_items).
    """
    def __init__(self, parent, db):
        super().__init__(parent)
        self.db = db
        self.items: list[dict] = []
        self.on_change = None  # callback opcional, se llama tras cualquier cambio

        self.table = QTableWidget(0, 4)
        self.table.setHorizontalHeaderLabels(["Descripción", "Cantidad", "Precio unit.", "Subtotal"])
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.table.setAlternatingRowColors(True)
        self.table.setShowGrid(False)
        self.table.verticalHeader().setVisible(False)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.table.setMaximumHeight(140)
        self.table.itemSelectionChanged.connect(self._update_buttons)

        self.add_btn = QPushButton("＋ Agregar concepto"); self.add_btn.clicked.connect(self._add)
        self.edit_btn = QPushButton("Editar"); self.edit_btn.clicked.connect(self._edit); self.edit_btn.setEnabled(False)
        self.delete_btn = QPushButton("Eliminar"); self.delete_btn.clicked.connect(self._delete); self.delete_btn.setEnabled(False)
        actions = QHBoxLayout(); actions.addWidget(self.add_btn); actions.addWidget(self.edit_btn); actions.addWidget(self.delete_btn); actions.addStretch()

        hint = QLabel(
            "Elige un servicio del catálogo o usa \"Otro (descripción libre)\" para algo "
            "que no esté en la lista. Si agregas al menos un concepto, el costo total de "
            "la orden se calcula solo."
        )
        hint.setWordWrap(True)
        hint.setStyleSheet("color:#8C8C8C;font-size:11px;")

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(8)
        layout.addWidget(self.table)
        layout.addLayout(actions)
        layout.addWidget(hint)

    def load(self, items: list[dict]) -> None:
        """Carga conceptos ya existentes (por ejemplo, los de una orden que se está editando)."""
        self.items = [
            {
                "servicio_id": it.get("servicio_id"),
                "descripcion": it["descripcion"],
                "cantidad": float(it["cantidad"]),
                "precio_unitario": float(it["precio_unitario"]),
            }
            for it in items
        ]
        self._refresh()

    def get_items(self) -> list[dict]:
        return list(self.items)

    def total(self) -> float:
        return sum(it["cantidad"] * it["precio_unitario"] for it in self.items)

    def _refresh(self) -> None:
        self.table.setRowCount(len(self.items))
        for r, it in enumerate(self.items):
            subtotal = it["cantidad"] * it["precio_unitario"]
            values = (it["descripcion"], f"{it['cantidad']:g}", f"${it['precio_unitario']:,.2f}", f"${subtotal:,.2f}")
            for c, v in enumerate(values):
                self.table.setItem(r, c, QTableWidgetItem(str(v)))
        self._update_buttons()
        if self.on_change:
            self.on_change()

    def _selected_index(self):
        row = self.table.currentRow()
        return row if 0 <= row < len(self.items) else None

    def _update_buttons(self) -> None:
        has = self._selected_index() is not None
        self.edit_btn.setEnabled(has)
        self.delete_btn.setEnabled(has)

    def _add(self) -> None:
        dlg = OrderItemDialog(self, self.db)
        if dlg.exec() and dlg.result_values:
            self.items.append(dlg.result_values)
            self._refresh()

    def _edit(self) -> None:
        idx = self._selected_index()
        if idx is None:
            return
        dlg = OrderItemDialog(self, self.db, self.items[idx])
        if dlg.exec() and dlg.result_values:
            self.items[idx] = dlg.result_values
            self._refresh()

    def _delete(self) -> None:
        idx = self._selected_index()
        if idx is None:
            return
        del self.items[idx]
        self._refresh()
