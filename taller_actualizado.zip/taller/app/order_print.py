"""Impresión y exportación a PDF de órdenes de trabajo."""
from pathlib import Path

from PySide6.QtCore import QMarginsF
from PySide6.QtGui import QPageSize, QPageLayout, QTextDocument
from PySide6.QtPrintSupport import QPrinter, QPrintDialog
from PySide6.QtWidgets import QFileDialog, QMessageBox

from app.config import TALLER_NOMBRE, TALLER_DIRECCION, TALLER_TELEFONO, TALLER_CORREO, LOGO_PATH


class OrderPrintService:
    def __init__(self, parent, db, order_id: int):
        self.parent = parent
        self.db = db
        self.order_id = order_id

    def _data(self):
        row = self.db.order_detail(self.order_id)
        if not row:
            return None
        return row

    @staticmethod
    def _esc(value) -> str:
        import html
        return html.escape(str(value or "—"))

    @staticmethod
    def _fecha(value) -> str:
        from datetime import datetime
        try:
            return datetime.strptime(value, "%Y-%m-%d").strftime("%d/%m/%Y")
        except (ValueError, TypeError):
            return value or ""

    def _header_html(self, row) -> str:
        contacto = " · ".join(
            x for x in (TALLER_DIRECCION, TALLER_TELEFONO, TALLER_CORREO) if x
        )
        logo_html = ""
        if LOGO_PATH.exists():
            logo_html = f"<img src='{LOGO_PATH.as_uri()}' height='54' style='margin-bottom:6px' /><br>"
        return f"""
        <table style='border:0'><tr>
          <td style='border:0;padding:0'>
            {logo_html}
            <div class='brand'>{self._esc(TALLER_NOMBRE)}</div>
            <div class='subtitle'>{self._esc(contacto) if contacto else 'Documento para cliente'}</div>
          </td>
          <td style='border:0;padding:0' class='ot'>OT-{self.order_id:05d}<br>
            <span class='subtitle'>Ingreso: {self._esc(self._fecha(row.get('fecha')))}</span><br>
            <span class='subtitle'>Cierre: {self._esc(self._fecha(row.get('fecha_cierre')) or '—')}</span>
          </td>
        </tr></table>
        """

    def _items_html(self) -> str:
        items = self.db.order_items(self.order_id)
        if not items:
            return ""
        rows = "".join(
            f"<tr><td>{self._esc(it['descripcion'])}</td>"
            f"<td style='text-align:center'>{it['cantidad']:g}</td>"
            f"<td style='text-align:right'>${it['precio_unitario']:,.2f}</td>"
            f"<td style='text-align:right'>${it['subtotal']:,.2f}</td></tr>"
            for it in items
        )
        return f"""
        <div class='section'>CONCEPTOS</div>
        <table>
          <tr><th>Descripción</th><th style='text-align:center'>Cant.</th>
              <th style='text-align:right'>Precio unit.</th><th style='text-align:right'>Subtotal</th></tr>
          {rows}
        </table>
        """

    def _payments_html(self) -> str:
        payments = self.db.payments_for_order(self.order_id)
        if not payments:
            return ""
        rows = "".join(
            f"<tr><td>{self._esc(self._fecha(p['fecha']))}</td>"
            f"<td>{self._esc(p['metodo'])}</td>"
            f"<td>{self._esc(p.get('referencia') or '')}</td>"
            f"<td style='text-align:right'>${p['monto']:,.2f}</td></tr>"
            for p in payments
        )
        return f"""
        <div class='section'>PAGOS REGISTRADOS</div>
        <table>
          <tr><th>Fecha</th><th>Método</th><th>Referencia</th><th style='text-align:right'>Monto</th></tr>
          {rows}
        </table>
        """

    def html(self) -> str:
        row = self._data()
        if not row:
            return ""
        total = float(row.get("costo") or 0)
        paid = float(row.get("pagado") or 0)
        balance = max(0, total - paid)
        payment_state = "PAGADO" if total > 0 and balance <= .005 else ("PAGO PARCIAL" if paid > 0 else "PENDIENTE")

        return f"""
        <html><head><meta charset='utf-8'><style>
        body {{ font-family: Arial, sans-serif; color:#202020; font-size:10pt; }}
        .header {{ border-bottom:3px solid #b00020; padding-bottom:10px; margin-bottom:14px; }}
        .brand {{ font-size:20pt; font-weight:bold; color:#b00020; }}
        .subtitle {{ color:#666; font-size:9pt; }}
        .ot {{ font-size:16pt; font-weight:bold; text-align:right; }}
        table {{ width:100%; border-collapse:collapse; }}
        td, th {{ border:1px solid #d5d5d5; padding:7px; vertical-align:top; }}
        th {{ background:#eeeeee; text-align:left; }}
        .section {{ background:#222; color:white; font-weight:bold; padding:7px; margin-top:13px; }}
        .money td {{ text-align:center; }}
        .money .value {{ font-size:13pt; font-weight:bold; }}
        .state {{ font-weight:bold; color:#b00020; }}
        .sign-box {{ border:1px solid #999; border-top:0; height:60px; }}
        .sign-label {{ text-align:center; border-top:1px solid #202020; padding-top:4px; }}
        .small {{ color:#777; font-size:8pt; }}
        </style></head><body>
        <div class='header'>{self._header_html(row)}</div>
        <div class='section'>CLIENTE Y VEHÍCULO</div>
        <table>
          <tr><th width='22%'>Cliente</th><td>{self._esc(row.get('cliente'))}</td><th width='18%'>Placas</th><td>{self._esc(row.get('placas') or 'Sin placas')}</td></tr>
          <tr><th>Vehículo</th><td>{self._esc(row.get('vehiculo') or 'Sin vehículo')}</td><th>Kilometraje</th><td>{self._esc(row.get('kilometraje'))}</td></tr>
          <tr><th>Estado</th><td class='state' colspan='3'>{self._esc(row.get('estado'))}</td></tr>
        </table>
        <div class='section'>SERVICIO SOLICITADO</div>
        <table><tr><th>Descripción</th></tr><tr><td>{self._esc(row.get('servicio'))}</td></tr></table>
        {self._items_html()}
        <div class='section'>NOTAS / OBSERVACIONES</div>
        <table><tr><td>{self._esc(row.get('notas') or 'Sin observaciones')}</td></tr></table>
        <div class='section'>RESUMEN DE PAGO</div>
        <table class='money'><tr><th>Total</th><th>Pagado</th><th>Saldo</th><th>Estado</th></tr>
          <tr><td class='value'>${total:,.2f}</td><td class='value'>${paid:,.2f}</td><td class='value'>${balance:,.2f}</td><td class='value'>{payment_state}</td></tr></table>
        {self._payments_html()}
        <br>
        <table style='border:0'><tr>
          <td style='border:0;width:45%'><div class='sign-box'></div><div class='sign-label'>Firma del cliente</div></td>
          <td style='border:0;width:10%'></td>
          <td style='border:0;width:45%'><div class='sign-box'></div><div class='sign-label'>Firma / recepción del taller</div></td>
        </tr></table>
        <p class='small'>Documento generado por el sistema de gestión del taller. OT-{self.order_id:05d}.</p>
        </body></html>
        """

    def _configured_printer(self):
        printer = QPrinter(QPrinter.PrinterMode.HighResolution)
        printer.setPageSize(QPageSize(QPageSize.PageSizeId.Letter))
        printer.setPageMargins(QMarginsF(12, 12, 12, 12), QPageLayout.Unit.Millimeter)
        return printer

    def print_order(self):
        if not self._data():
            return
        printer = self._configured_printer()
        dialog = QPrintDialog(printer, self.parent)
        dialog.setWindowTitle("Imprimir orden de trabajo")
        if dialog.exec():
            doc = QTextDocument()
            doc.setHtml(self.html())
            doc.print_(printer)

    def save_pdf(self):
        if not self._data():
            return
        default_name = f"OT-{self.order_id:05d}.pdf"
        path, _ = QFileDialog.getSaveFileName(
            self.parent, "Guardar orden como PDF", str(Path.home() / default_name), "PDF (*.pdf)"
        )
        if not path:
            return
        if not path.lower().endswith(".pdf"):
            path += ".pdf"
        printer = self._configured_printer()
        printer.setOutputFormat(QPrinter.OutputFormat.PdfFormat)
        printer.setOutputFileName(path)
        doc = QTextDocument()
        doc.setHtml(self.html())
        doc.print_(printer)
        QMessageBox.information(self.parent, "PDF creado", f"La orden OT-{self.order_id:05d} se guardó correctamente.\n\n{path}")
