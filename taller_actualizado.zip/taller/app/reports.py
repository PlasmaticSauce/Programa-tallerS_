"""Pestaña de reportes: resumen general y órdenes de trabajo finalizadas."""
from datetime import date as _date
from pathlib import Path

from PySide6.QtCore import QDate
from PySide6.QtWidgets import (
    QAbstractItemView, QCheckBox, QDateEdit, QFileDialog, QFrame, QHBoxLayout,
    QHeaderView, QLabel, QLineEdit, QMessageBox, QPushButton, QTableWidget,
    QTableWidgetItem, QVBoxLayout, QWidget,
)

from app.backup import backup_now, export_finished_orders_excel
from app.schema import ESTADO_COBRADO, ESTADOS_CERRADOS

DB_DATE = "yyyy-MM-dd"
SHOW_DATE = "dd/MM/yyyy"


class ReportsTab(QWidget):
    def __init__(self, db):
        super().__init__()
        self.db = db

        self.cards = {}
        cards_row = QHBoxLayout()
        cards_row.setSpacing(14)
        for key, label in (
            ("abiertas", "Órdenes abiertas"),
            ("clientes", "Clientes"),
            ("proveedores", "Proveedores"),
            ("ingresos", "Cobrado (órdenes terminadas)"),
        ):
            card, value_label = self._make_card(label)
            self.cards[key] = value_label
            cards_row.addWidget(card)

        actions_row = QHBoxLayout()
        actions_row.setSpacing(10)
        self.export_btn = QPushButton("Exportar reporte a Excel")
        self.export_btn.clicked.connect(self.export_excel)
        self.backup_btn = QPushButton("Generar respaldo del mes")
        self.backup_btn.setObjectName("primary")
        self.backup_btn.clicked.connect(self.run_backup)
        actions_row.addWidget(self.export_btn)
        actions_row.addWidget(self.backup_btn)
        actions_row.addStretch()

        title = QLabel("Órdenes de trabajo finalizadas")
        title.setObjectName("sectionTitle")

        self.search = QLineEdit()
        self.search.setPlaceholderText("Buscar por cliente o placas…")
        self.search.textChanged.connect(self.refresh)

        self.use_date = QCheckBox("Filtrar por día")
        self.use_date.toggled.connect(self._on_date_toggle)

        self.date_filter = QDateEdit(QDate.currentDate())
        self.date_filter.setCalendarPopup(True)
        self.date_filter.setDisplayFormat(SHOW_DATE)
        self.date_filter.setEnabled(False)
        self.date_filter.dateChanged.connect(self.refresh)

        self.today_btn = QPushButton("Reporte de hoy")
        self.today_btn.clicked.connect(self._filter_today)

        filter_row = QHBoxLayout()
        filter_row.setSpacing(10)
        filter_row.addWidget(self.search, 1)
        filter_row.addWidget(self.use_date)
        filter_row.addWidget(self.date_filter)
        filter_row.addWidget(self.today_btn)

        self.summary_label = QLabel()
        self.summary_label.setStyleSheet("color:#8C8C8C;")

        self.table = QTableWidget(0, 8)
        self.table.setHorizontalHeaderLabels(
            ["OT", "Fecha de cierre", "Cliente", "Vehículo", "Placas", "Servicio", "Costo", "Saldo"]
        )
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.NoSelection)
        self.table.setAlternatingRowColors(True)
        self.table.setShowGrid(False)
        self.table.verticalHeader().setVisible(False)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(14)
        layout.addLayout(cards_row)
        layout.addLayout(actions_row)
        layout.addWidget(title)
        layout.addLayout(filter_row)
        layout.addWidget(self.summary_label)
        layout.addWidget(self.table)

        self.refresh()

    @staticmethod
    def _make_card(label: str):
        card = QFrame()
        card.setObjectName("card")
        value = QLabel("0")
        value.setObjectName("cardValue")
        caption = QLabel(label)
        caption.setObjectName("cardLabel")
        box = QVBoxLayout(card)
        box.setContentsMargins(18, 14, 18, 14)
        box.addWidget(caption)
        box.addWidget(value)
        return card, value

    def _on_date_toggle(self, checked: bool) -> None:
        self.date_filter.setEnabled(checked)
        self.refresh()

    def _filter_today(self) -> None:
        self.date_filter.setDate(QDate.currentDate())
        self.use_date.setChecked(True)
        self.refresh()

    def _current_rows(self) -> list:
        date_str = self.date_filter.date().toString(DB_DATE) if self.use_date.isChecked() else None
        query = self.search.text().strip() or None
        return self.db.finished_orders(date=date_str, query=query)

    @staticmethod
    def _fmt_date(value: str) -> str:
        d = QDate.fromString(value or "", DB_DATE)
        return d.toString(SHOW_DATE) if d.isValid() else (value or "—")

    def refresh(self) -> None:
        by_status = {estado: (n, total) for estado, n, total in self.db.orders_by_status()}
        abiertas = sum(n for estado, (n, _) in by_status.items() if estado not in ESTADOS_CERRADOS)
        # Se usa lo realmente cobrado (pagos), para que coincida con el Dashboard.
        # El costo total facturado de cada orden se sigue viendo en la tabla de abajo.
        cobrado = self.db.collected_for_finished_orders()

        self.cards["abiertas"].setText(str(abiertas))
        self.cards["clientes"].setText(str(self.db.count("clientes")))
        self.cards["proveedores"].setText(str(self.db.count("proveedores")))
        self.cards["ingresos"].setText(f"${cobrado:,.2f}")

        rows = self._current_rows()
        self.table.setRowCount(len(rows))
        total = 0.0
        for r_i, r in enumerate(rows):
            costo = float(r.get("costo") or 0)
            saldo = float(r.get("saldo") or 0)
            total += costo
            cierre = r.get("fecha_cierre") or r.get("fecha")
            values = (
                f"OT-{r['id']:05d}", self._fmt_date(cierre), r.get("cliente") or "—",
                r.get("vehiculo") or "—", r.get("placas") or "—", r.get("servicio") or "—",
                f"${costo:,.2f}", f"${saldo:,.2f}",
            )
            for c, v in enumerate(values):
                self.table.setItem(r_i, c, QTableWidgetItem(str(v)))

        etiqueta_fecha = f" del {self.date_filter.date().toString(SHOW_DATE)}" if self.use_date.isChecked() else ""
        self.summary_label.setText(
            f"{len(rows)} orden(es) finalizada(s){etiqueta_fecha} · Total: ${total:,.2f}"
        )

    def export_excel(self) -> None:
        rows = self._current_rows()
        if not rows:
            QMessageBox.information(
                self, "Sin datos", "No hay órdenes finalizadas que coincidan con el filtro actual."
            )
            return
        suffix = (
            self.date_filter.date().toString(DB_DATE) if self.use_date.isChecked() else _date.today().isoformat()
        )
        default_name = f"reporte_ordenes_finalizadas_{suffix}.xlsx"
        path, _ = QFileDialog.getSaveFileName(
            self, "Exportar reporte a Excel", str(Path.home() / default_name), "Excel (*.xlsx)"
        )
        if not path:
            return
        if not path.lower().endswith(".xlsx"):
            path += ".xlsx"
        try:
            export_finished_orders_excel(rows, path)
        except Exception as error:
            QMessageBox.critical(self, "Error", f"No se pudo generar el archivo de Excel.\n\n{error}")
            return
        QMessageBox.information(self, "Reporte generado", f"El reporte se guardó correctamente en:\n\n{path}")

    def run_backup(self) -> None:
        answer = QMessageBox.question(
            self,
            "Generar respaldo",
            "Se creará un respaldo de la base de datos y un reporte en Excel de las "
            "órdenes y trabajos del mes actual, guardados en la carpeta "
            "'respaldos' del programa.\n\n¿Deseas continuar?",
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        try:
            info = backup_now(self.db)
        except Exception as error:
            QMessageBox.critical(self, "Error", f"No se pudo generar el respaldo.\n\n{error}")
            return
        QMessageBox.information(
            self,
            "Respaldo generado",
            f"Respaldo del {info['fecha']} guardado en:\n{info['carpeta']}\n\n"
            f"• Base de datos: {Path(info['db']).name}\n"
            f"• Reporte de órdenes: {Path(info['excel']).name}",
        )
        self._offer_copy_elsewhere(info)

    def _offer_copy_elsewhere(self, info: dict) -> None:
        """Ofrece copiar el respaldo recién creado a otra ubicación (USB, nube, etc.).

        Guardar el respaldo solo junto al programa no protege los datos si el
        equipo se daña o se pierde; conviene tener una copia en otro lado.
        """
        answer = QMessageBox.question(
            self,
            "Copiar a otra ubicación",
            "Se recomienda guardar también una copia de este respaldo en una "
            "USB, disco externo o carpeta en la nube (Google Drive, Dropbox, etc.).\n\n"
            "¿Deseas elegir una carpeta ahora para copiarlo?",
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        destino = QFileDialog.getExistingDirectory(self, "Elegir carpeta destino")
        if not destino:
            return
        import shutil
        try:
            shutil.copy2(info["db"], destino)
            shutil.copy2(info["excel"], destino)
        except Exception as error:
            QMessageBox.critical(self, "Error", f"No se pudo copiar el respaldo.\n\n{error}")
            return
        QMessageBox.information(self, "Copia realizada", f"Respaldo copiado también en:\n{destino}")
