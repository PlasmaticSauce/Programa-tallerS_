"""Exportación a Excel y respaldos periódicos del taller."""
import sqlite3
from datetime import date, datetime

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill
from openpyxl.utils import get_column_letter

from app.db import DB_PATH
from app.schema import ESTADOS

# Carpeta de respaldos, junto a la carpeta "data", dentro de la propia
# instalación del programa (no depende de una ruta del usuario).
BACKUP_DIR = DB_PATH.parent.parent / "respaldos"

HEADER_FILL = PatternFill(start_color="1E1E1E", end_color="1E1E1E", fill_type="solid")
HEADER_FONT = Font(color="FFFFFF", bold=True)


def _autosize(ws) -> None:
    for col_cells in ws.columns:
        length = max((len(str(c.value)) if c.value is not None else 0) for c in col_cells)
        ws.column_dimensions[get_column_letter(col_cells[0].column)].width = min(max(length + 2, 10), 60)


def _style_header(ws) -> None:
    for cell in ws[1]:
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL


def build_orders_workbook(db) -> Workbook:
    """Arma un libro de Excel con el resumen por estado y el detalle de órdenes."""
    wb = Workbook()

    resumen = wb.active
    resumen.title = "Resumen"
    resumen.append(["Estado", "Órdenes", "Monto"])
    _style_header(resumen)
    by_status = {estado: (n, total) for estado, n, total in db.orders_by_status()}
    for estado in ESTADOS:
        n, total = by_status.get(estado, (0, 0.0))
        resumen.append([estado, n, total])
    _autosize(resumen)

    detalle = wb.create_sheet("Órdenes")
    detalle.append(
        ["OT", "Fecha", "Cliente", "Vehículo", "Placas", "Servicio",
         "Estado", "Costo total", "Pagado", "Saldo"]
    )
    _style_header(detalle)
    rows = db.conn.execute(
        "SELECT o.id, o.fecha, c.nombre AS cliente, "
        "TRIM(COALESCE(v.marca,'') || ' ' || COALESCE(v.modelo,'')) AS vehiculo, v.placas, "
        "o.servicio, o.estado, o.costo, "
        "COALESCE((SELECT SUM(monto) FROM pagos p WHERE p.orden_id = o.id), 0) AS pagado "
        "FROM ordenes o "
        "JOIN clientes c ON c.id = o.cliente_id "
        "LEFT JOIN vehiculos v ON v.id = o.vehiculo_id "
        "ORDER BY o.fecha DESC, o.id DESC"
    ).fetchall()
    for r in rows:
        costo = float(r[7] or 0)
        pagado = float(r[8] or 0)
        detalle.append([
            f"OT-{r[0]:05d}", r[1], r[2], r[3] or "—", r[4] or "—",
            r[5], r[6], costo, pagado, max(0.0, costo - pagado),
        ])
    _autosize(detalle)

    return wb


def export_orders_excel(db, path) -> None:
    """Exporta el resumen y detalle de órdenes a un archivo .xlsx en 'path'."""
    build_orders_workbook(db).save(path)


def export_finished_orders_excel(rows: list, path) -> None:
    """Exporta a Excel una lista ya filtrada de órdenes finalizadas
    (usada para el reporte diario de la pestaña Reportes)."""
    wb = Workbook()
    ws = wb.active
    ws.title = "Órdenes finalizadas"
    ws.append(["OT", "Fecha de cierre", "Cliente", "Vehículo", "Placas", "Servicio", "Costo total", "Pagado", "Saldo"])
    _style_header(ws)

    total_costo = 0.0
    for r in rows:
        costo = float(r.get("costo") or 0)
        pagado = float(r.get("pagado") or 0)
        saldo = float(r.get("saldo", max(0.0, costo - pagado)))
        total_costo += costo
        cierre = r.get("fecha_cierre") or r.get("fecha")
        ws.append([
            f"OT-{r['id']:05d}", cierre, r.get("cliente") or "—",
            r.get("vehiculo") or "—", r.get("placas") or "—",
            r.get("servicio") or "—", costo, pagado, saldo,
        ])
    ws.append([])
    ws.append(["", "", "", "", "", "Total", total_costo, "", ""])
    for cell in ws[ws.max_row]:
        cell.font = Font(bold=True)
    _autosize(ws)
    wb.save(path)


def backup_now(db) -> dict:
    """Genera el respaldo del mes actual: copia de la base de datos completa
    (clientes, vehículos, órdenes y pagos) más un Excel de las órdenes/trabajos,
    guardados en la carpeta 'respaldos' junto al programa.

    Si ya existe un respaldo de este mes, se reemplaza por uno actualizado.
    """
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    stamp = date.today().strftime("%Y-%m")
    db_backup_path = BACKUP_DIR / f"respaldo_{stamp}.db"
    excel_backup_path = BACKUP_DIR / f"respaldo_ordenes_{stamp}.xlsx"

    # Copia segura de la base de datos con la API de respaldo de SQLite,
    # para no arriesgar el archivo aunque el programa esté en uso.
    dest_conn = sqlite3.connect(db_backup_path)
    try:
        db.conn.backup(dest_conn)
    finally:
        dest_conn.close()

    export_orders_excel(db, excel_backup_path)

    return {
        "carpeta": str(BACKUP_DIR),
        "db": str(db_backup_path),
        "excel": str(excel_backup_path),
        "fecha": datetime.now().strftime("%d/%m/%Y %H:%M"),
    }
