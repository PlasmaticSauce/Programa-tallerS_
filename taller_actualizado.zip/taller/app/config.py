"""Datos del taller que aparecen en la orden impresa / PDF.

Edita los valores de abajo con la información real del negocio.
Si colocas un archivo de imagen (png o jpg) en data/logo.png, se
usará automáticamente como logo en el encabezado del PDF.
"""
from pathlib import Path

TALLER_NOMBRE = "Taller Mecánico"
TALLER_DIRECCION = ""  # Ej. "Calle Falsa 123, Col. Centro, Ciudad"
TALLER_TELEFONO = ""   # Ej. "55 1234 5678"
TALLER_CORREO = ""     # Ej. "contacto@tallermecanico.com"

LOGO_PATH = Path(__file__).resolve().parent.parent / "data" / "logo.png"
