"""Base de datos SQLite y migraciones de versiones anteriores."""
import sqlite3
from pathlib import Path

from app.schema import ENTITIES, Entity, ESTADO_COBRADO, ESTADOS_CERRADOS

DB_PATH = Path(__file__).resolve().parent.parent / "data" / "taller.db"


class Database:
    def __init__(self, path: Path = DB_PATH):
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(path)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA foreign_keys = ON")
        self._create_tables()
        self._migrate_old_orders()
        self._migrate_order_statuses()
        self._migrate_closing_date()
        self._create_payments_table()
        self._create_order_items_table()

    # ---------- estructura ----------
    def _create_tables(self) -> None:
        for entity in ENTITIES.values():
            self._create_table(entity)

    def _create_table(self, entity: Entity) -> None:
        columns = ["id INTEGER PRIMARY KEY AUTOINCREMENT"]
        for f in entity.fields:
            if f.kind == "ref":
                # required se refleja en la tabla nueva; las migraciones antiguas
                # conservan sus columnas originales para no perder información.
                null = " NOT NULL" if f.required else ""
                columns.append(f"{f.key} INTEGER{null} REFERENCES {f.ref}(id)")
            elif f.kind == "number":
                columns.append(f"{f.key} REAL NOT NULL DEFAULT 0")
            else:
                columns.append(f"{f.key} TEXT NOT NULL DEFAULT ''")
        with self.conn:
            self.conn.execute(f"CREATE TABLE IF NOT EXISTS {entity.table} ({', '.join(columns)})")

    def _columns(self, table: str) -> set[str]:
        return {r[1] for r in self.conn.execute(f"PRAGMA table_info({table})")}

    def _add_column_if_missing(self, table: str, definition: str, name: str) -> None:
        if name not in self._columns(table):
            with self.conn:
                self.conn.execute(f"ALTER TABLE {table} ADD COLUMN {definition}")

    def _migrate_old_orders(self) -> None:
        """Actualiza una base anterior que guardaba vehículo/placas como texto.

        Se crean vehículos a partir de las órdenes existentes y cada orden queda
        vinculada al vehículo correspondiente. Las columnas antiguas se conservan
        para que una actualización nunca borre datos.
        """
        order_cols = self._columns("ordenes")
        if "vehiculo_id" not in order_cols:
            self._add_column_if_missing("ordenes", "vehiculo_id INTEGER", "vehiculo_id")
        if "notas" not in order_cols:
            self._add_column_if_missing("ordenes", "notas TEXT NOT NULL DEFAULT ''", "notas")

        # Bases nuevas ya usan vehiculo_id; no hay nada más que migrar.
        old_cols = {"vehiculo", "placas"}.issubset(order_cols)
        if not old_cols:
            return

        rows = self.conn.execute(
            "SELECT id, cliente_id, vehiculo, placas FROM ordenes "
            "WHERE (vehiculo_id IS NULL OR vehiculo_id = 0) AND cliente_id IS NOT NULL"
        ).fetchall()
        with self.conn:
            for row in rows:
                vehiculo = (row[2] or "").strip()
                placas = (row[3] or "").strip()
                if not vehiculo and not placas:
                    continue
                # Intentamos separar una descripción antigua del vehículo en marca/modelo.
                parts = vehiculo.split(None, 1)
                marca = parts[0] if parts else "Sin especificar"
                modelo = parts[1] if len(parts) > 1 else "Sin especificar"
                existing = self.conn.execute(
                    "SELECT id FROM vehiculos WHERE cliente_id = ? AND placas = ? "
                    "AND marca = ? AND modelo = ? LIMIT 1",
                    (row[1], placas, marca, modelo),
                ).fetchone()
                if existing:
                    vehicle_id = existing[0]
                else:
                    cur = self.conn.execute(
                        "INSERT INTO vehiculos "
                        "(cliente_id, marca, modelo, placas) VALUES (?, ?, ?, ?)",
                        (row[1], marca, modelo, placas),
                    )
                    vehicle_id = cur.lastrowid
                self.conn.execute(
                    "UPDATE ordenes SET vehiculo_id = ? WHERE id = ?",
                    (vehicle_id, row[0]),
                )


    def _migrate_order_statuses(self) -> None:
        """Normaliza estados de versiones anteriores a los 3 estados actuales.

        Nota: una versión anterior de esta migración marcaba "En reparación" y
        "Esperando refacción" como cerradas (Terminando/Terminado) por error,
        cuando en realidad seguían en curso. Aquí ya quedan como "Diagnóstico"
        (abiertas). Si tu base ya corrió esa migración anterior, esas órdenes
        pueden haber quedado marcadas como terminadas sin estarlo; conviene
        revisar manualmente las órdenes antiguas que no recuerdes haber cerrado.
        """
        mapping = {
            "En diagnóstico": "Diagnóstico",
            "En reparación": "Diagnóstico",
            "Esperando refacción": "Diagnóstico",
            "Terminando": "Terminado",
            "Entregado": "Terminado",
        }
        with self.conn:
            for old, new in mapping.items():
                self.conn.execute("UPDATE ordenes SET estado = ? WHERE estado = ?", (new, old))
            self.conn.execute("UPDATE ordenes SET estado = 'Recibido' WHERE estado IS NULL OR TRIM(estado) = ''")

    def _migrate_closing_date(self) -> None:
        """Agrega la columna de fecha de cierre, usada para los reportes por día.

        Para órdenes que ya estaban cerradas antes de esta actualización, se usa
        su fecha de ingreso como aproximación (no hay forma de recuperar la fecha
        real en la que se cerraron).
        """
        order_cols = self._columns("ordenes")
        is_new = "fecha_cierre" not in order_cols
        self._add_column_if_missing("ordenes", "fecha_cierre TEXT NOT NULL DEFAULT ''", "fecha_cierre")
        if is_new:
            placeholders = ",".join("?" for _ in ESTADOS_CERRADOS)
            with self.conn:
                self.conn.execute(
                    f"UPDATE ordenes SET fecha_cierre = fecha "
                    f"WHERE estado IN ({placeholders}) AND (fecha_cierre IS NULL OR fecha_cierre = '')",
                    ESTADOS_CERRADOS,
                )

    def _create_payments_table(self) -> None:
        with self.conn:
            self.conn.execute("""
                CREATE TABLE IF NOT EXISTS pagos (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    orden_id INTEGER NOT NULL REFERENCES ordenes(id) ON DELETE RESTRICT,
                    fecha TEXT NOT NULL DEFAULT '',
                    monto REAL NOT NULL DEFAULT 0,
                    metodo TEXT NOT NULL DEFAULT 'Efectivo',
                    referencia TEXT NOT NULL DEFAULT '',
                    notas TEXT NOT NULL DEFAULT ''
                )
            """)

    def _create_order_items_table(self) -> None:
        with self.conn:
            self.conn.execute("""
                CREATE TABLE IF NOT EXISTS orden_conceptos (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    orden_id INTEGER NOT NULL REFERENCES ordenes(id) ON DELETE CASCADE,
                    servicio_id INTEGER REFERENCES servicios(id),
                    descripcion TEXT NOT NULL DEFAULT '',
                    cantidad REAL NOT NULL DEFAULT 1,
                    precio_unitario REAL NOT NULL DEFAULT 0
                )
            """)

    def order_paid(self, order_id: int) -> float:
        return float(self.conn.execute("SELECT COALESCE(SUM(monto),0) FROM pagos WHERE orden_id = ?", (order_id,)).fetchone()[0])

    def order_balance(self, order_id: int) -> float:
        row = self.conn.execute("SELECT COALESCE(costo,0) FROM ordenes WHERE id = ?", (order_id,)).fetchone()
        total = float(row[0] or 0) if row else 0.0
        return max(0.0, total - self.order_paid(order_id))

    def payment_order_options(self) -> list[dict]:
        rows = self.conn.execute("""
            SELECT o.id, o.fecha, c.nombre AS cliente, TRIM(COALESCE(v.marca,'') || ' ' || COALESCE(v.modelo,'')) AS vehiculo, v.placas, COALESCE(o.costo,0) AS total
            FROM ordenes o JOIN clientes c ON c.id=o.cliente_id LEFT JOIN vehiculos v ON v.id=o.vehiculo_id
            ORDER BY o.id DESC
        """).fetchall()
        out=[]
        for r in rows:
            bal=self.order_balance(r[0])
            if bal > 0.005:
                label=f"OT-{r[0]:05d} · {r[2]} · {r[3] or 'Vehículo'} · Saldo ${bal:,.2f}"
                out.append({"id":r[0],"label":label})
        return out

    def add_payment(self, orden_id: int, monto: float, metodo: str, fecha: str, referencia: str='', notas: str='') -> None:
        balance=self.order_balance(orden_id)
        if monto <= 0 or monto > balance + 0.005:
            raise ValueError(f"El monto supera el saldo disponible (${balance:,.2f}).")
        with self.conn:
            self.conn.execute("INSERT INTO pagos (orden_id,fecha,monto,metodo,referencia,notas) VALUES (?,?,?,?,?,?)", (orden_id,fecha,monto,metodo,referencia,notas))

    def payment_overview(self) -> list[dict]:
        rows=self.conn.execute("""
            SELECT o.id,o.fecha,c.nombre AS cliente,TRIM(COALESCE(v.marca,'') || ' ' || COALESCE(v.modelo,'')) AS vehiculo,v.placas,
                   COALESCE(o.costo,0) AS total,COALESCE(SUM(p.monto),0) AS pagado,
                   (SELECT metodo FROM pagos p2 WHERE p2.orden_id=o.id ORDER BY p2.id DESC LIMIT 1) AS ultimo_metodo
            FROM ordenes o JOIN clientes c ON c.id=o.cliente_id LEFT JOIN vehiculos v ON v.id=o.vehiculo_id
            LEFT JOIN pagos p ON p.orden_id=o.id
            GROUP BY o.id ORDER BY o.id DESC
        """).fetchall()
        out=[]
        for r in rows:
            total=float(r[5] or 0); paid=float(r[6] or 0); balance=max(0,total-paid)
            status='Pagado' if total>0 and balance<=0.005 else ('Parcial' if paid>0 else 'Pendiente')
            out.append({"id":r[0],"fecha":r[1],"cliente":r[2],"vehiculo":r[3],"placas":r[4],"total":total,"pagado":paid,"saldo":balance,"estado_pago":status,"ultimo_metodo":r[7]})
        return out

    def dashboard_metrics(self) -> dict:
        from datetime import date
        today=date.today().isoformat(); month=today[:7]
        orders=self.conn.execute("SELECT COUNT(*) FROM ordenes").fetchone()[0]
        open_orders=self.conn.execute("SELECT COUNT(*) FROM ordenes WHERE estado != ?", (ESTADO_COBRADO,)).fetchone()[0]
        paid_total=float(self.conn.execute("SELECT COALESCE(SUM(monto),0) FROM pagos").fetchone()[0])
        receivable=float(self.conn.execute("SELECT COALESCE(SUM(CASE WHEN costo-COALESCE((SELECT SUM(monto) FROM pagos p WHERE p.orden_id=o.id),0)>0 THEN costo-COALESCE((SELECT SUM(monto) FROM pagos p2 WHERE p2.orden_id=o.id),0) ELSE 0 END),0) FROM ordenes o").fetchone()[0])
        today_paid=float(self.conn.execute("SELECT COALESCE(SUM(monto),0) FROM pagos WHERE fecha=?",(today,)).fetchone()[0])
        month_paid=float(self.conn.execute("SELECT COALESCE(SUM(monto),0) FROM pagos WHERE substr(fecha,1,7)=?",(month,)).fetchone()[0])
        status_counts = {r[0]: r[1] for r in self.conn.execute("SELECT estado, COUNT(*) FROM ordenes GROUP BY estado").fetchall()}
        return {"orders":orders,"open_orders":open_orders,"clients":self.count('clientes'),"vehicles":self.count('vehiculos'),"today_paid":today_paid,"month_paid":month_paid,"paid_total":paid_total,"receivable":receivable,"status_counts":status_counts}

    def recent_payments(self, limit=8):
        rows=self.conn.execute("SELECT p.id,p.fecha,p.monto,p.metodo,o.id AS orden_id,c.nombre AS cliente FROM pagos p JOIN ordenes o ON o.id=p.orden_id JOIN clientes c ON c.id=o.cliente_id ORDER BY p.id DESC LIMIT ?",(limit,)).fetchall()
        return [dict(r) for r in rows]

    def recent_orders(self, limit=8) -> list[dict]:
        """Órdenes de trabajo más recientes, para la actividad del dashboard."""
        rows = self.conn.execute(
            "SELECT o.id, o.fecha, c.nombre AS cliente, "
            "TRIM(COALESCE(v.marca,'') || ' ' || COALESCE(v.modelo,'')) AS vehiculo, "
            "v.placas, o.estado, o.costo "
            "FROM ordenes o JOIN clientes c ON c.id = o.cliente_id "
            "LEFT JOIN vehiculos v ON v.id = o.vehiculo_id "
            "ORDER BY o.id DESC LIMIT ?",
            (limit,),
        ).fetchall()
        return [dict(r) for r in rows]

    # ---------- etiquetas ----------
    def _label_sql(self, table: str, alias: str = "t") -> str:
        if table == "clientes":
            return f"{alias}.nombre"
        if table == "proveedores":
            return f"{alias}.empresa"
        if table == "vehiculos":
            return (
                f"TRIM(COALESCE({alias}.marca, '') || ' ' || "
                f"COALESCE({alias}.modelo, '') || "
                f"CASE WHEN COALESCE({alias}.placas, '') <> '' THEN ' · ' || {alias}.placas ELSE '' END)"
            )
        return f"CAST({alias}.id AS TEXT)"

    def label_for(self, table: str, record_id: int | None) -> str:
        if not record_id:
            return ""
        row = self.conn.execute(
            f"SELECT {self._label_sql(table)} FROM {table} t WHERE t.id = ?",
            (record_id,),
        ).fetchone()
        return str(row[0]) if row and row[0] is not None else ""


    def order_record(self, order_id: int) -> dict | None:
        row = self.conn.execute("SELECT * FROM ordenes WHERE id = ?", (order_id,)).fetchone()
        return dict(row) if row else None

    def order_detail(self, order_id: int) -> dict | None:
        row = self.conn.execute("""
            SELECT o.id, o.fecha, o.fecha_cierre, o.servicio, o.estado, o.costo, o.notas,
                   c.nombre AS cliente, c.telefono AS cliente_telefono,
                   TRIM(COALESCE(v.marca,'') || ' ' || COALESCE(v.modelo,'')) AS vehiculo,
                   v.placas, v.kilometraje,
                   COALESCE((SELECT SUM(monto) FROM pagos p WHERE p.orden_id=o.id),0) AS pagado
            FROM ordenes o
            LEFT JOIN clientes c ON c.id=o.cliente_id
            LEFT JOIN vehiculos v ON v.id=o.vehiculo_id
            WHERE o.id=?
        """, (order_id,)).fetchone()
        return dict(row) if row else None

    def update_order_status(self, order_id: int, status: str) -> None:
        from datetime import date
        with self.conn:
            if status in ESTADOS_CERRADOS:
                self.conn.execute(
                    "UPDATE ordenes SET estado=?, fecha_cierre=? WHERE id=?",
                    (status, date.today().isoformat(), order_id),
                )
            else:
                # Si la orden se reabre, se limpia la fecha de cierre anterior.
                self.conn.execute(
                    "UPDATE ordenes SET estado=?, fecha_cierre='' WHERE id=?",
                    (status, order_id),
                )

    # ---------- consultas ----------
    def all(self, entity: Entity) -> list[dict]:
        select, joins = ["t.*"], []
        for i, f in enumerate(entity.fields):
            if f.kind == "ref":
                joins.append(f"LEFT JOIN {f.ref} r{i} ON r{i}.id = t.{f.key}")
                select.append(f"{self._label_sql(f.ref, f'r{i}')} AS {f.key}__label")
        sql = (
            f"SELECT {', '.join(select)} FROM {entity.table} t "
            f"{' '.join(joins)} ORDER BY t.id DESC"
        )
        return [dict(row) for row in self.conn.execute(sql)]

    def ref_options(self, table: str, client_id: int | None = None) -> list[tuple[int, str]]:
        sql = (
            f"SELECT id, {self._label_sql(table)} AS label FROM {table} t "
        )
        params = []
        if table == "vehiculos" and client_id:
            sql += " WHERE t.cliente_id = ? "
            params.append(client_id)
        sql += " ORDER BY label COLLATE NOCASE"
        rows = self.conn.execute(sql, params)
        return [(row[0], row[1]) for row in rows]

    # ---------- altas, cambios y bajas ----------
    def insert(self, entity: Entity, values: dict) -> int:
        keys = [f.key for f in entity.fields]
        placeholders = ", ".join("?" for _ in keys)
        with self.conn:
            cur = self.conn.execute(
                f"INSERT INTO {entity.table} ({', '.join(keys)}) VALUES ({placeholders})",
                [values[k] for k in keys],
            )
        return cur.lastrowid

    def update(self, entity: Entity, record_id: int, values: dict) -> None:
        keys = [f.key for f in entity.fields]
        assignments = ", ".join(f"{k} = ?" for k in keys)
        with self.conn:
            self.conn.execute(
                f"UPDATE {entity.table} SET {assignments} WHERE id = ?",
                [values[k] for k in keys] + [record_id],
            )

    def delete(self, entity: Entity, record_id: int) -> None:
        # Evita dejar vehículos o clientes sin relación con su historial.
        if entity.table == "vehiculos":
            used = self.conn.execute(
                "SELECT COUNT(*) FROM ordenes WHERE vehiculo_id = ?", (record_id,)
            ).fetchone()[0]
            if used:
                raise ValueError("No se puede eliminar: este vehículo tiene órdenes en su historial.")
        try:
            with self.conn:
                self.conn.execute(f"DELETE FROM {entity.table} WHERE id = ?", (record_id,))
        except sqlite3.IntegrityError:
            raise ValueError(
                f"No se puede eliminar: este {entity.singular} tiene registros asociados."
            ) from None

    # ---------- historial ----------
    def vehicle_history(self, vehicle_id: int) -> list[dict]:
        rows = self.conn.execute(
            "SELECT id, fecha, servicio, estado, costo, notas "
            "FROM ordenes WHERE vehiculo_id = ? ORDER BY fecha DESC, id DESC",
            (vehicle_id,),
        )
        return [dict(r) for r in rows]

    def client_history(self, client_id: int) -> list[dict]:
        rows = self.conn.execute(
            "SELECT o.id, o.fecha, o.servicio, o.estado, o.costo, "
            "TRIM(v.marca || ' ' || v.modelo) AS vehiculo, v.placas "
            "FROM ordenes o LEFT JOIN vehiculos v ON v.id = o.vehiculo_id "
            "WHERE o.cliente_id = ? ORDER BY o.fecha DESC, o.id DESC",
            (client_id,),
        )
        return [dict(r) for r in rows]

    def vehicle_count_for_client(self, client_id: int) -> int:
        return self.conn.execute(
            "SELECT COUNT(*) FROM vehiculos WHERE cliente_id = ?", (client_id,)
        ).fetchone()[0]

    # ---------- reportes ----------
    def count(self, table: str) -> int:
        return self.conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]

    def orders_by_status(self) -> list[tuple[str, int, float]]:
        rows = self.conn.execute(
            "SELECT estado, COUNT(*), COALESCE(SUM(costo), 0) FROM ordenes GROUP BY estado"
        )
        return [(r[0], r[1], r[2]) for r in rows]

    def finished_orders(self, date: str | None = None, query: str | None = None) -> list[dict]:
        """Órdenes de trabajo ya finalizadas, para el reporte de la pestaña Reportes.

        'date' filtra por fecha de cierre exacta (yyyy-MM-dd, la fecha en que la
        orden pasó a "Terminado") y 'query' busca en cliente, placas, vehículo
        o servicio.
        """
        sql = (
            "SELECT o.id, o.fecha, o.fecha_cierre, c.nombre AS cliente, "
            "TRIM(COALESCE(v.marca,'') || ' ' || COALESCE(v.modelo,'')) AS vehiculo, "
            "v.placas, o.servicio, o.costo, "
            "COALESCE((SELECT SUM(monto) FROM pagos p WHERE p.orden_id = o.id), 0) AS pagado "
            "FROM ordenes o "
            "JOIN clientes c ON c.id = o.cliente_id "
            "LEFT JOIN vehiculos v ON v.id = o.vehiculo_id "
            "WHERE o.estado = ? "
        )
        params: list = [ESTADO_COBRADO]
        if date:
            sql += "AND (CASE WHEN o.fecha_cierre <> '' THEN o.fecha_cierre ELSE o.fecha END) = ? "
            params.append(date)
        sql += "ORDER BY (CASE WHEN o.fecha_cierre <> '' THEN o.fecha_cierre ELSE o.fecha END) DESC, o.id DESC"

        results = []
        for row in self.conn.execute(sql, params).fetchall():
            record = dict(row)
            costo = float(record.get("costo") or 0)
            pagado = float(record.get("pagado") or 0)
            record["saldo"] = max(0.0, costo - pagado)
            results.append(record)

        if query:
            q = query.strip().lower()
            results = [
                r for r in results
                if q in " ".join(str(r.get(k) or "") for k in ("cliente", "placas", "vehiculo", "servicio")).lower()
            ]
        return results

    def collected_for_finished_orders(self, date: str | None = None) -> float:
        """Suma de lo realmente cobrado (pagos) en órdenes ya terminadas.

        Usa el mismo filtro de fecha de cierre que finished_orders, para que
        coincida con lo que se ve en el Dashboard.
        """
        sql = (
            "SELECT COALESCE(SUM(p.monto), 0) FROM pagos p "
            "JOIN ordenes o ON o.id = p.orden_id "
            "WHERE o.estado = ? "
        )
        params: list = [ESTADO_COBRADO]
        if date:
            sql += "AND (CASE WHEN o.fecha_cierre <> '' THEN o.fecha_cierre ELSE o.fecha END) = ? "
            params.append(date)
        return float(self.conn.execute(sql, params).fetchone()[0] or 0)

    def service_options(self) -> list[tuple[int, str, float]]:
        rows = self.conn.execute(
            "SELECT id, nombre, precio FROM servicios ORDER BY nombre COLLATE NOCASE"
        ).fetchall()
        return [(r[0], r[1], float(r[2] or 0)) for r in rows]

    # ---------- conceptos / servicios de una orden ----------
    def order_items(self, order_id: int) -> list[dict]:
        rows = self.conn.execute(
            "SELECT id, orden_id, servicio_id, descripcion, cantidad, precio_unitario "
            "FROM orden_conceptos WHERE orden_id = ? ORDER BY id",
            (order_id,),
        ).fetchall()
        out = []
        for r in rows:
            d = dict(r)
            d["subtotal"] = float(d["cantidad"] or 0) * float(d["precio_unitario"] or 0)
            out.append(d)
        return out

    def order_items_total(self, order_id: int) -> float:
        return sum(item["subtotal"] for item in self.order_items(order_id))

    def _sync_order_cost_from_items(self, order_id: int) -> None:
        """Si la orden tiene conceptos capturados, el costo total se calcula
        automáticamente a partir de ellos (cantidad × precio unitario)."""
        items = self.order_items(order_id)
        if not items:
            return
        total = sum(item["subtotal"] for item in items)
        with self.conn:
            self.conn.execute("UPDATE ordenes SET costo = ? WHERE id = ?", (total, order_id))

    def add_order_item(self, order_id: int, descripcion: str, cantidad: float,
                        precio_unitario: float, servicio_id: int | None = None) -> None:
        with self.conn:
            self.conn.execute(
                "INSERT INTO orden_conceptos (orden_id, servicio_id, descripcion, cantidad, precio_unitario) "
                "VALUES (?, ?, ?, ?, ?)",
                (order_id, servicio_id, descripcion, cantidad, precio_unitario),
            )
        self._sync_order_cost_from_items(order_id)

    def set_order_items(self, order_id: int, items: list[dict]) -> None:
        """Reemplaza todos los conceptos de una orden por la lista dada.

        Se usa al guardar el formulario de alta/edición de una orden, donde los
        conceptos se capturan en memoria y se guardan todos juntos al aceptar.
        """
        with self.conn:
            self.conn.execute("DELETE FROM orden_conceptos WHERE orden_id = ?", (order_id,))
            for it in items:
                self.conn.execute(
                    "INSERT INTO orden_conceptos (orden_id, servicio_id, descripcion, cantidad, precio_unitario) "
                    "VALUES (?, ?, ?, ?, ?)",
                    (order_id, it.get("servicio_id"), it["descripcion"], it["cantidad"], it["precio_unitario"]),
                )
        self._sync_order_cost_from_items(order_id)

    def update_order_item(self, item_id: int, descripcion: str, cantidad: float,
                           precio_unitario: float, servicio_id: int | None = None) -> None:
        row = self.conn.execute("SELECT orden_id FROM orden_conceptos WHERE id = ?", (item_id,)).fetchone()
        if not row:
            raise ValueError("El concepto ya no existe.")
        order_id = row[0]
        with self.conn:
            self.conn.execute(
                "UPDATE orden_conceptos SET servicio_id=?, descripcion=?, cantidad=?, precio_unitario=? WHERE id=?",
                (servicio_id, descripcion, cantidad, precio_unitario, item_id),
            )
        self._sync_order_cost_from_items(order_id)

    def delete_order_item(self, item_id: int) -> None:
        row = self.conn.execute("SELECT orden_id FROM orden_conceptos WHERE id = ?", (item_id,)).fetchone()
        if not row:
            return
        order_id = row[0]
        with self.conn:
            self.conn.execute("DELETE FROM orden_conceptos WHERE id = ?", (item_id,))
        self._sync_order_cost_from_items(order_id)

    # ---------- edición y borrado de pagos ----------
    def payments_for_order(self, order_id: int) -> list[dict]:
        rows = self.conn.execute(
            "SELECT id, orden_id, fecha, monto, metodo, referencia, notas "
            "FROM pagos WHERE orden_id = ? ORDER BY id DESC",
            (order_id,),
        ).fetchall()
        return [dict(r) for r in rows]

    def update_payment(self, payment_id: int, monto: float, metodo: str, fecha: str,
                        referencia: str = "", notas: str = "") -> None:
        row = self.conn.execute("SELECT orden_id, monto FROM pagos WHERE id = ?", (payment_id,)).fetchone()
        if not row:
            raise ValueError("El pago ya no existe.")
        order_id, old_monto = row[0], float(row[1] or 0)
        total = float(self.conn.execute("SELECT COALESCE(costo,0) FROM ordenes WHERE id = ?", (order_id,)).fetchone()[0] or 0)
        other_paid = self.order_paid(order_id) - old_monto
        max_allowed = max(0.0, total - other_paid)
        if monto <= 0 or monto > max_allowed + 0.005:
            raise ValueError(f"El monto supera el saldo disponible (${max_allowed:,.2f}).")
        with self.conn:
            self.conn.execute(
                "UPDATE pagos SET monto=?, metodo=?, fecha=?, referencia=?, notas=? WHERE id=?",
                (monto, metodo, fecha, referencia, notas, payment_id),
            )

    def delete_payment(self, payment_id: int) -> None:
        with self.conn:
            self.conn.execute("DELETE FROM pagos WHERE id = ?", (payment_id,))
