"""Vista general del historial de servicios."""
from PySide6.QtCore import QDate
from PySide6.QtWidgets import (
    QAbstractItemView, QComboBox, QHeaderView, QLabel, QLineEdit,
    QTableWidget, QTableWidgetItem, QVBoxLayout, QHBoxLayout, QWidget,
)

from app.schema import ESTADOS

DB_DATE = "yyyy-MM-dd"
SHOW_DATE = "dd/MM/yyyy"


class HistoryTab(QWidget):
    def __init__(self, db):
        super().__init__()
        self.db = db
        self.search = QLineEdit()
        self.search.setPlaceholderText("Buscar cliente, vehículo, placas o servicio…")
        self.search.textChanged.connect(self.refresh)

        self.state = QComboBox()
        self.state.addItem("Todos los estados")
        self.state.addItems(ESTADOS)
        self.state.currentTextChanged.connect(self.refresh)

        top = QHBoxLayout()
        top.addWidget(self.search, 1)
        top.addWidget(self.state)

        self.summary = QLabel()
        self.summary.setObjectName("sectionTitle")

        self.table = QTableWidget(0, 8)
        self.table.setHorizontalHeaderLabels(
            ["OT", "Fecha", "Cliente", "Vehículo", "Placas", "Servicio", "Estado", "Total"]
        )
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.NoSelection)
        self.table.setAlternatingRowColors(True)
        self.table.setShowGrid(False)
        self.table.verticalHeader().setVisible(False)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(12)
        layout.addLayout(top)
        layout.addWidget(self.summary)
        layout.addWidget(self.table)
        self.refresh()

    def refresh(self):
        query = self.search.text().strip().lower()
        state = self.state.currentText()
        rows = self.db.conn.execute(
            "SELECT o.id, o.fecha, c.nombre AS cliente, "
            "TRIM(v.marca || ' ' || v.modelo) AS vehiculo, v.placas, "
            "o.servicio, o.estado, o.costo "
            "FROM ordenes o "
            "JOIN clientes c ON c.id = o.cliente_id "
            "LEFT JOIN vehiculos v ON v.id = o.vehiculo_id "
            "ORDER BY o.fecha DESC, o.id DESC"
        ).fetchall()
        filtered = []
        for row in rows:
            values = [str(row[i] or "") for i in range(8)]
            if state != "Todos los estados" and row[6] != state:
                continue
            if query and query not in " ".join(values).lower():
                continue
            filtered.append(row)

        self.table.setRowCount(len(filtered))
        for r, row in enumerate(filtered):
            d = QDate.fromString(row[1] or "", DB_DATE)
            fecha = d.toString(SHOW_DATE) if d.isValid() else (row[1] or "—")
            values = (
                f"OT-{row[0]:05d}", fecha, row[2], row[3] or "—", row[4] or "—",
                row[5], row[6], f"${float(row[7] or 0):,.2f}",
            )
            for c, value in enumerate(values):
                self.table.setItem(r, c, QTableWidgetItem(str(value)))
        self.summary.setText(f"{len(filtered)} servicio(s) encontrado(s)")
