# Taller Mecánico - Clientes, Vehículos e Historial

Esta versión agrega:

- Clientes con historial de servicios.
- Catálogo de vehículos por cliente.
- Relación Cliente → Vehículo → Orden de trabajo.
- Historial por cliente y por vehículo.
- Pestaña general de historial con búsqueda y filtro por estado.
- Migración automática de una base anterior que guardaba vehículo y placas directamente en las órdenes.
- Compatibilidad con los módulos existentes de proveedores y reportes.

## Ejecutar

```bash
pip install -r requirements.txt
python main.py
```

La base de datos se crea en `data/taller.db`.
