"""Ventana principal del sistema del taller."""
from PySide6.QtWidgets import QMainWindow, QTabWidget

from app.crud import CrudTab
from app.history import HistoryTab
from app.payments import PaymentsTab
from app.dashboard import DashboardTab
from app.reports import ReportsTab
from app.schema import CLIENTES, ORDENES, PROVEEDORES, VEHICULOS


class MainWindow(QMainWindow):
    def __init__(self, db):
        super().__init__()
        self.setWindowTitle("Taller Mecánico")
        self.resize(1350, 780)

        pages = [
            (DashboardTab(db), "Dashboard"),
            (CrudTab(db, ORDENES), ORDENES.title),
            (CrudTab(db, CLIENTES, history_mode="client"), CLIENTES.title),
            (CrudTab(db, VEHICULOS, history_mode="vehicle"), VEHICULOS.title),
            (HistoryTab(db), "Historial"),
            (PaymentsTab(db), "Pagos"),
            (CrudTab(db, PROVEEDORES), PROVEEDORES.title),
            (ReportsTab(db), "Reportes"),
        ]
        self.tabs = QTabWidget()
        for page, title in pages:
            self.tabs.addTab(page, title)
        self.tabs.currentChanged.connect(self._on_tab_changed)
        self.setCentralWidget(self.tabs)

    def _on_tab_changed(self, index: int) -> None:
        page = self.tabs.widget(index)
        if hasattr(page, "refresh"):
            page.refresh()
