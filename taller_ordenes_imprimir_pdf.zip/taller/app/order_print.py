"""Impresión y exportación a PDF de órdenes de trabajo."""
from pathlib import Path

from PySide6.QtCore import QMarginsF
from PySide6.QtGui import QPageSize, QPageLayout, QTextDocument
from PySide6.QtPrintSupport import QPrinter, QPrintDialog
from PySide6.QtWidgets import QFileDialog, QMessageBox


class OrderPrintService:
    def __init__(self, parent, db, order_id: int):
        self.parent = parent
        self.db = db
        self.order_id = order_id

    def _data(self):
        row = self.db.order_detail(self.order_id)
        if not row:
            return None
        return row

    @staticmethod
    def _esc(value) -> str:
        import html
        return html.escape(str(value or "—"))

    def html(self) -> str:
        row = self._data()
        if not row:
            return ""
        total = float(row.get("costo") or 0)
        paid = float(row.get("pagado") or 0)
        balance = max(0, total - paid)
        payment_state = "PAGADO" if total > 0 and balance <= .005 else ("PAGO PARCIAL" if paid > 0 else "PENDIENTE")
        fecha = row.get("fecha") or ""
        try:
            from datetime import datetime
            fecha = datetime.strptime(fecha, "%Y-%m-%d").strftime("%d/%m/%Y")
        except ValueError:
            pass

        return f"""
        <html><head><meta charset='utf-8'><style>
        body {{ font-family: Arial, sans-serif; color:#202020; font-size:10pt; }}
        .header {{ border-bottom:3px solid #b00020; padding-bottom:10px; margin-bottom:14px; }}
        .brand {{ font-size:20pt; font-weight:bold; color:#b00020; }}
        .subtitle {{ color:#666; font-size:9pt; }}
        .ot {{ font-size:16pt; font-weight:bold; text-align:right; }}
        table {{ width:100%; border-collapse:collapse; }}
        td, th {{ border:1px solid #d5d5d5; padding:7px; vertical-align:top; }}
        th {{ background:#eeeeee; text-align:left; }}
        .section {{ background:#222; color:white; font-weight:bold; padding:7px; margin-top:13px; }}
        .money td {{ text-align:center; }}
        .money .value {{ font-size:13pt; font-weight:bold; }}
        .state {{ font-weight:bold; color:#b00020; }}
        .sign {{ height:70px; }}
        .small {{ color:#777; font-size:8pt; }}
        </style></head><body>
        <div class='header'>
          <table style='border:0'><tr><td style='border:0;padding:0'>
            <div class='brand'>ORDEN DE TRABAJO</div>
            <div class='subtitle'>Taller Mecánico · Documento para cliente</div>
          </td><td style='border:0;padding:0' class='ot'>OT-{self.order_id:05d}<br><span class='subtitle'>{self._esc(fecha)}</span></td></tr></table>
        </div>
        <div class='section'>CLIENTE Y VEHÍCULO</div>
        <table>
          <tr><th width='22%'>Cliente</th><td>{self._esc(row.get('cliente'))}</td><th width='18%'>Placas</th><td>{self._esc(row.get('placas') or 'Sin placas')}</td></tr>
          <tr><th>Vehículo</th><td>{self._esc(row.get('vehiculo') or 'Sin vehículo')}</td><th>Estado</th><td class='state'>{self._esc(row.get('estado'))}</td></tr>
        </table>
        <div class='section'>SERVICIO</div>
        <table><tr><th>Trabajo / servicio solicitado</th></tr><tr><td>{self._esc(row.get('servicio'))}</td></tr></table>
        <div class='section'>NOTAS / OBSERVACIONES</div>
        <table><tr><td class='sign'>{self._esc(row.get('notas') or 'Sin observaciones')}</td></tr></table>
        <div class='section'>RESUMEN DE PAGO</div>
        <table class='money'><tr><th>Total</th><th>Pagado</th><th>Saldo</th><th>Estado</th></tr>
          <tr><td class='value'>${total:,.2f}</td><td class='value'>${paid:,.2f}</td><td class='value'>${balance:,.2f}</td><td class='value'>{payment_state}</td></tr></table>
        <br><br>
        <table><tr><td style='border:0;text-align:center;width:45%'><div class='sign'></div>____________________________<br>Firma del cliente</td>
        <td style='border:0;width:10%'></td><td style='border:0;text-align:center;width:45%'><div class='sign'></div>____________________________<br>Firma / recepción del taller</td></tr></table>
        <p class='small'>Documento generado por el sistema de gestión del taller. OT-{self.order_id:05d}.</p>
        </body></html>
        """

    def _configured_printer(self):
        printer = QPrinter(QPrinter.PrinterMode.HighResolution)
        printer.setPageSize(QPageSize(QPageSize.PageSizeId.Letter))
        printer.setPageMargins(QMarginsF(12, 12, 12, 12), QPageLayout.Unit.Millimeter)
        return printer

    def print_order(self):
        if not self._data():
            return
        printer = self._configured_printer()
        dialog = QPrintDialog(printer, self.parent)
        dialog.setWindowTitle("Imprimir orden de trabajo")
        if dialog.exec():
            doc = QTextDocument()
            doc.setHtml(self.html())
            doc.print_(printer)

    def save_pdf(self):
        if not self._data():
            return
        default_name = f"OT-{self.order_id:05d}.pdf"
        path, _ = QFileDialog.getSaveFileName(
            self.parent, "Guardar orden como PDF", str(Path.home() / default_name), "PDF (*.pdf)"
        )
        if not path:
            return
        if not path.lower().endswith(".pdf"):
            path += ".pdf"
        printer = self._configured_printer()
        printer.setOutputFormat(QPrinter.OutputFormat.PdfFormat)
        printer.setOutputFileName(path)
        doc = QTextDocument()
        doc.setHtml(self.html())
        doc.print_(printer)
        QMessageBox.information(self.parent, "PDF creado", f"La orden OT-{self.order_id:05d} se guardó correctamente.\n\n{path}")
