"""Dashboard principal con indicadores operativos y financieros."""
from PySide6.QtWidgets import QFrame,QGridLayout,QHBoxLayout,QLabel,QTableWidget,QTableWidgetItem,QVBoxLayout,QWidget,QAbstractItemView,QHeaderView
from app.schema import ESTADOS, ESTADOS_CERRADOS

class DashboardTab(QWidget):
    def __init__(self,db):
        super().__init__(); self.db=db; self.cards={}
        grid=QGridLayout(); grid.setSpacing(14)
        specs=[('open','Órdenes abiertas'),('received','Recibidas'),('diagnosis','En diagnóstico'),('finishing','Terminando'),('receivable','Por cobrar'),('today','Cobrado hoy'),('month','Cobrado este mes')]
        for i,(key,label) in enumerate(specs):
            card,val=self._card(label); self.cards[key]=val; grid.addWidget(card,i//4,i%4)
        title=QLabel('Actividad reciente'); title.setObjectName('sectionTitle')
        self.table=QTableWidget(0,5); self.table.setHorizontalHeaderLabels(['Fecha','OT','Cliente','Método','Monto'])
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers); self.table.setSelectionMode(QAbstractItemView.SelectionMode.NoSelection); self.table.setAlternatingRowColors(True); self.table.setShowGrid(False); self.table.verticalHeader().setVisible(False); self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        box=QVBoxLayout(self); box.setContentsMargins(20,20,20,20); box.setSpacing(16); box.addLayout(grid); box.addWidget(title); box.addWidget(self.table)
        self.refresh()
    def _card(self,label):
        card=QFrame(); card.setObjectName('card'); val=QLabel('0'); val.setObjectName('cardValue'); cap=QLabel(label); cap.setObjectName('cardLabel'); l=QVBoxLayout(card); l.setContentsMargins(18,14,18,14); l.addWidget(cap); l.addWidget(val); return card,val
    def refresh(self):
        m=self.db.dashboard_metrics(); self.cards['open'].setText(str(m['open_orders'])); self.cards['received'].setText(str(m['status_counts'].get('Recibido',0))); self.cards['diagnosis'].setText(str(m['status_counts'].get('Diagnóstico',0))); self.cards['finishing'].setText(str(m['status_counts'].get('Terminando',0))); self.cards['receivable'].setText(f"${m['receivable']:,.2f}"); self.cards['today'].setText(f"${m['today_paid']:,.2f}"); self.cards['month'].setText(f"${m['month_paid']:,.2f}")
        rows=self.db.recent_payments(); self.table.setRowCount(len(rows))
        for i,r in enumerate(rows):
            vals=(r['fecha'],f"OT-{r['orden_id']:05d}",r['cliente'],r['metodo'],f"${r['monto']:,.2f}")
            for c,v in enumerate(vals): self.table.setItem(i,c,QTableWidgetItem(str(v)))
