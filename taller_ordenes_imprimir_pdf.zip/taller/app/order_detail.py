from PySide6.QtCore import Qt, QDate
from PySide6.QtWidgets import QDialog, QHBoxLayout, QLabel, QPushButton, QVBoxLayout, QFrame, QGridLayout, QMessageBox
from app.schema import ESTADOS
from app.status_flow import StatusStep

class OrderDetailDialog(QDialog):
    def __init__(self, parent, db, order_id: int):
        super().__init__(parent)
        self.db = db
        self.order_id = order_id
        self.setWindowTitle(f"Detalle de orden · OT-{order_id:05d}")
        self.resize(920, 620)
        self._build()
        self.refresh()

    def _build(self):
        self.title = QLabel()
        self.title.setObjectName("sectionTitle")
        self.subtitle = QLabel()
        self.subtitle.setStyleSheet("color:#8C8C8C;")

        flow = QHBoxLayout(); flow.setSpacing(8)
        self.steps = []
        for i, status in enumerate(ESTADOS):
            step = StatusStep(i, status)
            step.clicked.connect(lambda _=False, s=status: self._set_status(s))
            self.steps.append(step); flow.addWidget(step, 1)
            if i < len(ESTADOS)-1:
                arrow = QLabel("→"); arrow.setAlignment(Qt.AlignmentFlag.AlignCenter)
                arrow.setStyleSheet("color:#555;font-size:24px;font-weight:700;")
                flow.addWidget(arrow)

        self.info_frame = QFrame(); self.info_frame.setObjectName("card")
        grid = QGridLayout(self.info_frame); grid.setContentsMargins(18,16,18,16); grid.setHorizontalSpacing(30); grid.setVerticalSpacing(12)
        self.labels = {}
        fields = [("Cliente","cliente"),("Vehículo","vehiculo"),("Placas","placas"),("Fecha de ingreso","fecha"),("Servicio","servicio"),("Notas","notas")]
        for row,(caption,key) in enumerate(fields):
            cap=QLabel(caption); cap.setStyleSheet("color:#8C8C8C;font-size:12px;")
            val=QLabel(); val.setWordWrap(True); val.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
            self.labels[key]=val
            grid.addWidget(cap,row,0); grid.addWidget(val,row,1)
        self.labels["servicio"].setMinimumHeight(45)

        self.total=QLabel(); self.paid=QLabel(); self.balance=QLabel(); self.payment_state=QLabel()
        for w in (self.total,self.paid,self.balance,self.payment_state): w.setObjectName("sectionTitle")
        money=QHBoxLayout(); money.addWidget(self._money_card("Total",self.total)); money.addWidget(self._money_card("Pagado",self.paid)); money.addWidget(self._money_card("Saldo",self.balance)); money.addWidget(self._money_card("Estado",self.payment_state))

        self.edit_btn=QPushButton("Editar orden"); self.edit_btn.clicked.connect(self._edit)
        self.print_btn=QPushButton("Imprimir")
        self.print_btn.clicked.connect(self._print)
        self.pdf_btn=QPushButton("Guardar PDF")
        self.pdf_btn.setObjectName("primary")
        self.pdf_btn.clicked.connect(self._pdf)
        self.pay_btn=QPushButton("Registrar pago"); self.pay_btn.setObjectName("primary"); self.pay_btn.clicked.connect(self._pay)
        close=QPushButton("Cerrar"); close.clicked.connect(self.accept)
        buttons=QHBoxLayout(); buttons.addWidget(self.edit_btn); buttons.addWidget(self.print_btn); buttons.addWidget(self.pdf_btn); buttons.addWidget(self.pay_btn); buttons.addStretch(); buttons.addWidget(close)

        layout=QVBoxLayout(self); layout.setContentsMargins(24,22,24,20); layout.setSpacing(14)
        layout.addWidget(self.title); layout.addWidget(self.subtitle); layout.addLayout(flow); layout.addWidget(self.info_frame); layout.addLayout(money); layout.addLayout(buttons)

    def _money_card(self, caption, label):
        frame=QFrame(); frame.setObjectName("card"); lay=QVBoxLayout(frame); lay.setContentsMargins(14,10,14,10)
        c=QLabel(caption); c.setStyleSheet("color:#8C8C8C;font-size:12px;"); lay.addWidget(c); lay.addWidget(label); return frame

    def refresh(self):
        row=self.db.order_detail(self.order_id)
        if not row:
            self.reject(); return
        self.current=row.get("estado") or ESTADOS[0]
        self.title.setText(f"Orden de trabajo <b>OT-{self.order_id:05d}</b>")
        self.subtitle.setText(f"{row.get('cliente') or 'Sin cliente'} · {row.get('vehiculo') or 'Sin vehículo'}")
        self.labels["cliente"].setText(row.get("cliente") or "—")
        self.labels["vehiculo"].setText(row.get("vehiculo") or "—")
        self.labels["placas"].setText(row.get("placas") or "Sin placas")
        d=QDate.fromString(row.get("fecha") or "", "yyyy-MM-dd")
        self.labels["fecha"].setText(d.toString("dd/MM/yyyy") if d.isValid() else row.get("fecha") or "—")
        self.labels["servicio"].setText(row.get("servicio") or "—")
        self.labels["notas"].setText(row.get("notas") or "—")
        total=float(row.get("costo") or 0); paid=float(row.get("pagado") or 0); balance=max(0,total-paid)
        self.total.setText(f"${total:,.2f}"); self.paid.setText(f"${paid:,.2f}"); self.balance.setText(f"${balance:,.2f}")
        self.payment_state.setText("Pagado" if total>0 and balance<=.005 else ("Parcial" if paid>0 else "Pendiente"))
        self.pay_btn.setEnabled(balance>.005)
        for step in self.steps: step.setChecked(step.title==self.current)

    def _set_status(self,status):
        if status==self.current: return
        self.db.update_order_status(self.order_id,status); self.refresh()

    def _edit(self):
        from app.crud import RecordDialog
        from app.schema import ORDENES
        record=self.db.order_record(self.order_id)
        dlg=RecordDialog(self,self.db,ORDENES,record)
        if dlg.exec():
            try: self.db.update(ORDENES,self.order_id,dlg.result_values)
            except Exception as e: QMessageBox.critical(self,"Error",f"No se pudo actualizar la orden.\n\n{e}"); return
            self.refresh()

    def _print(self):
        from app.order_print import OrderPrintService
        OrderPrintService(self, self.db, self.order_id).print_order()

    def _pdf(self):
        from app.order_print import OrderPrintService
        OrderPrintService(self, self.db, self.order_id).save_pdf()

    def _pay(self):
        from app.payments import PaymentDialog
        dlg=PaymentDialog(self,self.db)
        idx=dlg.order.findData(self.order_id)
        if idx>=0: dlg.order.setCurrentIndex(idx)
        if dlg.exec() and dlg.result:
            try: self.db.add_payment(**dlg.result)
            except Exception as e: QMessageBox.critical(self,"Error",f"No se pudo registrar el pago.\n\n{e}"); return
            self.refresh()
