"""Estilo visual (rojo mate y negro). Cambia los colores aquí arriba."""
from string import Template

COLORS = {
    "BG": "#0B0B0B",           # fondo negro
    "SURFACE": "#151515",      # tablas y tarjetas
    "SURFACE_ALT": "#1E1E1E",  # campos, filas alternas, pestañas inactivas
    "BORDER": "#2A2A2A",
    "RED": "#A8232A",          # rojo mate
    "RED_HOVER": "#8A1C22",
    "TEXT": "#EDEDED",
    "MUTED": "#8C8C8C",
}

_QSS = Template(
    """
QWidget { background: $BG; color: $TEXT; font-family: "Segoe UI", "Helvetica Neue", sans-serif; font-size: 14px; }
QLabel { background: transparent; }

/* ---- Pestañas ---- */
QTabWidget::pane { border: 1px solid $BORDER; background: $BG; top: -1px; }
QTabBar { background: $BG; }
QTabBar::tab { background: $SURFACE_ALT; color: $MUTED; padding: 12px 30px; margin-right: 4px;
               border-top-left-radius: 8px; border-top-right-radius: 8px; }
QTabBar::tab:selected { background: $RED; color: #FFFFFF; font-weight: 600; }
QTabBar::tab:hover:!selected { background: $BORDER; color: $TEXT; }

/* ---- Botones ---- */
QPushButton { background: $SURFACE_ALT; color: $TEXT; border: 1px solid $BORDER;
              border-radius: 8px; padding: 9px 18px; }
QPushButton:hover { background: $BORDER; }
QPushButton:disabled { color: #555555; }
QPushButton#primary { background: $RED; color: #FFFFFF; border: none; font-weight: 600; }
QPushButton#primary:hover { background: $RED_HOVER; }

/* ---- Campos ---- */
QLineEdit, QPlainTextEdit, QComboBox, QDateEdit, QDoubleSpinBox {
    background: $SURFACE_ALT; border: 1px solid $BORDER; border-radius: 8px; padding: 8px;
    selection-background-color: $RED; }
QLineEdit:focus, QPlainTextEdit:focus, QComboBox:focus, QDateEdit:focus, QDoubleSpinBox:focus {
    border: 1px solid $RED; }
QComboBox QAbstractItemView { background: $SURFACE_ALT; selection-background-color: $RED; border: 1px solid $BORDER; }

/* ---- Tablas ---- */
QTableWidget { background: $SURFACE; alternate-background-color: $SURFACE_ALT;
               border: 1px solid $BORDER; border-radius: 8px; gridline-color: transparent;
               selection-background-color: $RED; selection-color: #FFFFFF; }
QTableWidget::item { padding: 6px; }
QHeaderView::section { background: $SURFACE_ALT; color: $MUTED; border: none; padding: 10px; font-weight: 600; }

/* ---- Tarjetas de reportes ---- */
QFrame#card { background: $SURFACE; border: 1px solid $BORDER; border-radius: 10px; }
QLabel#cardValue { color: $RED; font-size: 32px; font-weight: 700; }
QLabel#cardLabel { color: $MUTED; }
QLabel#sectionTitle { font-size: 16px; font-weight: 600; }

/* ---- Barras de desplazamiento ---- */
QScrollBar:vertical { background: $BG; width: 12px; }
QScrollBar::handle:vertical { background: $BORDER; border-radius: 6px; min-height: 30px; }
QScrollBar::add-line, QScrollBar::sub-line { height: 0; width: 0; }
"""
)

STYLESHEET = _QSS.substitute(COLORS)
