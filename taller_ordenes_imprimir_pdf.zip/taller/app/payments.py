"""Control de pagos de órdenes de trabajo."""
from PySide6.QtCore import QDate
from PySide6.QtWidgets import (
    QAbstractItemView, QComboBox, QDateEdit, QDialog, QDialogButtonBox,
    QDoubleSpinBox, QFormLayout, QHBoxLayout, QHeaderView, QLabel, QLineEdit,
    QMessageBox, QPlainTextEdit, QPushButton, QTableWidget, QTableWidgetItem,
    QVBoxLayout, QWidget,
)

DB_DATE = "yyyy-MM-dd"
SHOW_DATE = "dd/MM/yyyy"
METHODS = ("Efectivo", "Transferencia", "Tarjeta", "Depósito", "Otro")


class PaymentDialog(QDialog):
    def __init__(self, parent, db):
        super().__init__(parent)
        self.db = db
        self.result = None
        self.setWindowTitle("Registrar pago")
        self.setMinimumWidth(520)

        self.order = QComboBox()
        self.amount = QDoubleSpinBox()
        self.amount.setRange(0.01, 99_999_999)
        self.amount.setDecimals(2)
        self.amount.setPrefix("$ ")
        self.amount.setGroupSeparatorShown(True)
        self.method = QComboBox(); self.method.addItems(METHODS)
        self.date = QDateEdit(QDate.currentDate()); self.date.setCalendarPopup(True); self.date.setDisplayFormat(SHOW_DATE)
        self.reference = QLineEdit(); self.reference.setPlaceholderText("Folio, referencia o últimos 4 dígitos")
        self.notes = QPlainTextEdit(); self.notes.setFixedHeight(70)

        self.info = QLabel(); self.info.setObjectName("sectionTitle")
        self.order.currentIndexChanged.connect(self._order_changed)
        self._load_orders()

        form = QFormLayout(); form.setSpacing(12)
        form.addRow("Orden *", self.order)
        form.addRow("Saldo", self.info)
        form.addRow("Monto *", self.amount)
        form.addRow("Método", self.method)
        form.addRow("Fecha", self.date)
        form.addRow("Referencia", self.reference)
        form.addRow("Notas", self.notes)

        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        buttons.button(QDialogButtonBox.StandardButton.Save).setText("Registrar")
        buttons.button(QDialogButtonBox.StandardButton.Save).setObjectName("primary")
        buttons.button(QDialogButtonBox.StandardButton.Cancel).setText("Cancelar")
        buttons.accepted.connect(self._save); buttons.rejected.connect(self.reject)

        layout = QVBoxLayout(self); layout.setContentsMargins(24,24,24,20); layout.setSpacing(16)
        layout.addLayout(form); layout.addWidget(buttons)

    def _load_orders(self):
        rows = self.db.payment_order_options()
        for r in rows:
            self.order.addItem(r["label"], r["id"])
        self._order_changed()

    def _order_changed(self):
        oid = self.order.currentData()
        if not oid:
            self.info.setText("Sin órdenes disponibles")
            self.amount.setMaximum(0.01)
            return
        bal = self.db.order_balance(oid)
        self.info.setText(f"${bal:,.2f}")
        self.amount.setMaximum(max(0.01, bal))
        if bal > 0:
            self.amount.setValue(bal)

    def _save(self):
        oid = self.order.currentData()
        amount = self.amount.value()
        if not oid:
            QMessageBox.warning(self, "Falta información", "Selecciona una orden.")
            return
        balance = self.db.order_balance(oid)
        if amount <= 0 or amount > balance + 0.005:
            QMessageBox.warning(self, "Monto inválido", f"El pago debe ser mayor a cero y no superar el saldo de ${balance:,.2f}.")
            return
        self.result = {
            "orden_id": oid, "monto": amount, "metodo": self.method.currentText(),
            "fecha": self.date.date().toString(DB_DATE), "referencia": self.reference.text().strip(),
            "notas": self.notes.toPlainText().strip(),
        }
        self.accept()


class PaymentsTab(QWidget):
    def __init__(self, db):
        super().__init__(); self.db = db
        self.search = QLineEdit(); self.search.setPlaceholderText("Buscar cliente, vehículo, placas o número de OT…"); self.search.textChanged.connect(self.refresh)
        self.state = QComboBox(); self.state.addItems(("Todos", "Pendiente", "Parcial", "Pagado")); self.state.currentTextChanged.connect(self.refresh)
        self.add = QPushButton("＋ Registrar pago"); self.add.setObjectName("primary"); self.add.clicked.connect(self.add_payment)
        top = QHBoxLayout(); top.addWidget(self.search,1); top.addWidget(self.state); top.addWidget(self.add)

        self.summary = QLabel(); self.summary.setObjectName("sectionTitle")
        self.table = QTableWidget(0,9)
        self.table.setHorizontalHeaderLabels(["OT","Fecha","Cliente","Vehículo","Total","Pagado","Saldo","Estado","Método último pago"])
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers); self.table.setSelectionMode(QAbstractItemView.SelectionMode.NoSelection)
        self.table.setAlternatingRowColors(True); self.table.setShowGrid(False); self.table.verticalHeader().setVisible(False)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        layout=QVBoxLayout(self); layout.setContentsMargins(20,20,20,20); layout.setSpacing(12); layout.addLayout(top); layout.addWidget(self.summary); layout.addWidget(self.table)
        self.refresh()

    def add_payment(self):
        dlg=PaymentDialog(self,self.db)
        if dlg.exec() and dlg.result:
            try: self.db.add_payment(**dlg.result)
            except Exception as e: QMessageBox.critical(self,"Error",f"No se pudo registrar el pago.\n\n{e}"); return
            self.refresh()

    def refresh(self):
        q=self.search.text().strip().lower(); state=self.state.currentText()
        rows=self.db.payment_overview()
        filtered=[]
        for r in rows:
            hay=" ".join(str(r[k] or "") for k in ("id","fecha","cliente","vehiculo","placas","estado")) .lower()
            if q and q not in hay: continue
            if state!="Todos" and r["estado_pago"]!=state: continue
            filtered.append(r)
        self.table.setRowCount(len(filtered))
        for i,r in enumerate(filtered):
            vals=(r["id"],r["fecha"],r["cliente"],r["vehiculo"] or "—",f"${r['total']:,.2f}",f"${r['pagado']:,.2f}",f"${r['saldo']:,.2f}",r["estado_pago"],r["ultimo_metodo"] or "—")
            for c,v in enumerate(vals): self.table.setItem(i,c,QTableWidgetItem(str(v)))
        self.summary.setText(f"{len(filtered)} orden(es) · Por cobrar: ${sum(r['saldo'] for r in filtered):,.2f}")
