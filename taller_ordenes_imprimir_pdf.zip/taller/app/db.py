"""Base de datos SQLite y migraciones de versiones anteriores."""
import sqlite3
from pathlib import Path

from app.schema import ENTITIES, Entity

DB_PATH = Path(__file__).resolve().parent.parent / "data" / "taller.db"


class Database:
    def __init__(self, path: Path = DB_PATH):
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(path)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA foreign_keys = ON")
        self._create_tables()
        self._migrate_old_orders()
        self._migrate_order_statuses()
        self._create_payments_table()

    # ---------- estructura ----------
    def _create_tables(self) -> None:
        for entity in ENTITIES.values():
            self._create_table(entity)

    def _create_table(self, entity: Entity) -> None:
        columns = ["id INTEGER PRIMARY KEY AUTOINCREMENT"]
        for f in entity.fields:
            if f.kind == "ref":
                # required se refleja en la tabla nueva; las migraciones antiguas
                # conservan sus columnas originales para no perder información.
                null = " NOT NULL" if f.required else ""
                columns.append(f"{f.key} INTEGER{null} REFERENCES {f.ref}(id)")
            elif f.kind == "number":
                columns.append(f"{f.key} REAL NOT NULL DEFAULT 0")
            else:
                columns.append(f"{f.key} TEXT NOT NULL DEFAULT ''")
        with self.conn:
            self.conn.execute(f"CREATE TABLE IF NOT EXISTS {entity.table} ({', '.join(columns)})")

    def _columns(self, table: str) -> set[str]:
        return {r[1] for r in self.conn.execute(f"PRAGMA table_info({table})")}

    def _add_column_if_missing(self, table: str, definition: str, name: str) -> None:
        if name not in self._columns(table):
            with self.conn:
                self.conn.execute(f"ALTER TABLE {table} ADD COLUMN {definition}")

    def _migrate_old_orders(self) -> None:
        """Actualiza una base anterior que guardaba vehículo/placas como texto.

        Se crean vehículos a partir de las órdenes existentes y cada orden queda
        vinculada al vehículo correspondiente. Las columnas antiguas se conservan
        para que una actualización nunca borre datos.
        """
        order_cols = self._columns("ordenes")
        if "vehiculo_id" not in order_cols:
            self._add_column_if_missing("ordenes", "vehiculo_id INTEGER", "vehiculo_id")
        if "notas" not in order_cols:
            self._add_column_if_missing("ordenes", "notas TEXT NOT NULL DEFAULT ''", "notas")

        # Bases nuevas ya usan vehiculo_id; no hay nada más que migrar.
        old_cols = {"vehiculo", "placas"}.issubset(order_cols)
        if not old_cols:
            return

        rows = self.conn.execute(
            "SELECT id, cliente_id, vehiculo, placas FROM ordenes "
            "WHERE (vehiculo_id IS NULL OR vehiculo_id = 0) AND cliente_id IS NOT NULL"
        ).fetchall()
        with self.conn:
            for row in rows:
                vehiculo = (row[2] or "").strip()
                placas = (row[3] or "").strip()
                if not vehiculo and not placas:
                    continue
                # Intentamos separar una descripción antigua del vehículo en marca/modelo.
                parts = vehiculo.split(None, 1)
                marca = parts[0] if parts else "Sin especificar"
                modelo = parts[1] if len(parts) > 1 else "Sin especificar"
                existing = self.conn.execute(
                    "SELECT id FROM vehiculos WHERE cliente_id = ? AND placas = ? "
                    "AND marca = ? AND modelo = ? LIMIT 1",
                    (row[1], placas, marca, modelo),
                ).fetchone()
                if existing:
                    vehicle_id = existing[0]
                else:
                    cur = self.conn.execute(
                        "INSERT INTO vehiculos "
                        "(cliente_id, marca, modelo, placas) VALUES (?, ?, ?, ?)",
                        (row[1], marca, modelo, placas),
                    )
                    vehicle_id = cur.lastrowid
                self.conn.execute(
                    "UPDATE ordenes SET vehiculo_id = ? WHERE id = ?",
                    (vehicle_id, row[0]),
                )


    def _migrate_order_statuses(self) -> None:
        """Normaliza estados de versiones anteriores a los 3 estados actuales."""
        mapping = {
            "En diagnóstico": "Diagnóstico",
            "En reparación": "Terminando",
            "Esperando refacción": "Terminando",
            "Terminado": "Terminando",
            "Entregado": "Terminando",
        }
        with self.conn:
            for old, new in mapping.items():
                self.conn.execute("UPDATE ordenes SET estado = ? WHERE estado = ?", (new, old))
            self.conn.execute("UPDATE ordenes SET estado = 'Recibido' WHERE estado IS NULL OR TRIM(estado) = ''")

    def _create_payments_table(self) -> None:
        with self.conn:
            self.conn.execute("""
                CREATE TABLE IF NOT EXISTS pagos (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    orden_id INTEGER NOT NULL REFERENCES ordenes(id) ON DELETE RESTRICT,
                    fecha TEXT NOT NULL DEFAULT '',
                    monto REAL NOT NULL DEFAULT 0,
                    metodo TEXT NOT NULL DEFAULT 'Efectivo',
                    referencia TEXT NOT NULL DEFAULT '',
                    notas TEXT NOT NULL DEFAULT ''
                )
            """)

    def order_paid(self, order_id: int) -> float:
        return float(self.conn.execute("SELECT COALESCE(SUM(monto),0) FROM pagos WHERE orden_id = ?", (order_id,)).fetchone()[0])

    def order_balance(self, order_id: int) -> float:
        row = self.conn.execute("SELECT COALESCE(costo,0) FROM ordenes WHERE id = ?", (order_id,)).fetchone()
        total = float(row[0] or 0) if row else 0.0
        return max(0.0, total - self.order_paid(order_id))

    def payment_order_options(self) -> list[dict]:
        rows = self.conn.execute("""
            SELECT o.id, o.fecha, c.nombre AS cliente, TRIM(COALESCE(v.marca,'') || ' ' || COALESCE(v.modelo,'')) AS vehiculo, v.placas, COALESCE(o.costo,0) AS total
            FROM ordenes o JOIN clientes c ON c.id=o.cliente_id LEFT JOIN vehiculos v ON v.id=o.vehiculo_id
            ORDER BY o.id DESC
        """).fetchall()
        out=[]
        for r in rows:
            bal=self.order_balance(r[0])
            if bal > 0.005:
                label=f"OT-{r[0]:05d} · {r[2]} · {r[3] or 'Vehículo'} · Saldo ${bal:,.2f}"
                out.append({"id":r[0],"label":label})
        return out

    def add_payment(self, orden_id: int, monto: float, metodo: str, fecha: str, referencia: str='', notas: str='') -> None:
        balance=self.order_balance(orden_id)
        if monto <= 0 or monto > balance + 0.005:
            raise ValueError(f"El monto supera el saldo disponible (${balance:,.2f}).")
        with self.conn:
            self.conn.execute("INSERT INTO pagos (orden_id,fecha,monto,metodo,referencia,notas) VALUES (?,?,?,?,?,?)", (orden_id,fecha,monto,metodo,referencia,notas))

    def payment_overview(self) -> list[dict]:
        rows=self.conn.execute("""
            SELECT o.id,o.fecha,c.nombre AS cliente,TRIM(COALESCE(v.marca,'') || ' ' || COALESCE(v.modelo,'')) AS vehiculo,v.placas,
                   COALESCE(o.costo,0) AS total,COALESCE(SUM(p.monto),0) AS pagado,
                   (SELECT metodo FROM pagos p2 WHERE p2.orden_id=o.id ORDER BY p2.id DESC LIMIT 1) AS ultimo_metodo
            FROM ordenes o JOIN clientes c ON c.id=o.cliente_id LEFT JOIN vehiculos v ON v.id=o.vehiculo_id
            LEFT JOIN pagos p ON p.orden_id=o.id
            GROUP BY o.id ORDER BY o.id DESC
        """).fetchall()
        out=[]
        for r in rows:
            total=float(r[5] or 0); paid=float(r[6] or 0); balance=max(0,total-paid)
            status='Pagado' if total>0 and balance<=0.005 else ('Parcial' if paid>0 else 'Pendiente')
            out.append({"id":r[0],"fecha":r[1],"cliente":r[2],"vehiculo":r[3],"placas":r[4],"total":total,"pagado":paid,"saldo":balance,"estado_pago":status,"ultimo_metodo":r[7]})
        return out

    def dashboard_metrics(self) -> dict:
        from datetime import date
        today=date.today().isoformat(); month=today[:7]
        orders=self.conn.execute("SELECT COUNT(*) FROM ordenes").fetchone()[0]
        open_orders=self.conn.execute("SELECT COUNT(*) FROM ordenes WHERE estado != 'Terminando'").fetchone()[0]
        paid_total=float(self.conn.execute("SELECT COALESCE(SUM(monto),0) FROM pagos").fetchone()[0])
        receivable=float(self.conn.execute("SELECT COALESCE(SUM(CASE WHEN costo-COALESCE((SELECT SUM(monto) FROM pagos p WHERE p.orden_id=o.id),0)>0 THEN costo-COALESCE((SELECT SUM(monto) FROM pagos p2 WHERE p2.orden_id=o.id),0) ELSE 0 END),0) FROM ordenes o").fetchone()[0])
        today_paid=float(self.conn.execute("SELECT COALESCE(SUM(monto),0) FROM pagos WHERE fecha=?",(today,)).fetchone()[0])
        month_paid=float(self.conn.execute("SELECT COALESCE(SUM(monto),0) FROM pagos WHERE substr(fecha,1,7)=?",(month,)).fetchone()[0])
        status_counts = {r[0]: r[1] for r in self.conn.execute("SELECT estado, COUNT(*) FROM ordenes GROUP BY estado").fetchall()}
        return {"orders":orders,"open_orders":open_orders,"clients":self.count('clientes'),"vehicles":self.count('vehiculos'),"today_paid":today_paid,"month_paid":month_paid,"paid_total":paid_total,"receivable":receivable,"status_counts":status_counts}

    def recent_payments(self, limit=8):
        rows=self.conn.execute("SELECT p.id,p.fecha,p.monto,p.metodo,o.id AS orden_id,c.nombre AS cliente FROM pagos p JOIN ordenes o ON o.id=p.orden_id JOIN clientes c ON c.id=o.cliente_id ORDER BY p.id DESC LIMIT ?",(limit,)).fetchall()
        return [dict(r) for r in rows]

    # ---------- etiquetas ----------
    def _label_sql(self, table: str, alias: str = "t") -> str:
        if table == "clientes":
            return f"{alias}.nombre"
        if table == "proveedores":
            return f"{alias}.empresa"
        if table == "vehiculos":
            return (
                f"TRIM(COALESCE({alias}.marca, '') || ' ' || "
                f"COALESCE({alias}.modelo, '') || "
                f"CASE WHEN COALESCE({alias}.placas, '') <> '' THEN ' · ' || {alias}.placas ELSE '' END)"
            )
        return f"CAST({alias}.id AS TEXT)"

    def label_for(self, table: str, record_id: int | None) -> str:
        if not record_id:
            return ""
        row = self.conn.execute(
            f"SELECT {self._label_sql(table)} FROM {table} t WHERE t.id = ?",
            (record_id,),
        ).fetchone()
        return str(row[0]) if row and row[0] is not None else ""


    def order_record(self, order_id: int) -> dict | None:
        row = self.conn.execute("SELECT * FROM ordenes WHERE id = ?", (order_id,)).fetchone()
        return dict(row) if row else None

    def order_detail(self, order_id: int) -> dict | None:
        row = self.conn.execute("""
            SELECT o.id, o.fecha, o.servicio, o.estado, o.costo, o.notas,
                   c.nombre AS cliente,
                   TRIM(COALESCE(v.marca,'') || ' ' || COALESCE(v.modelo,'')) AS vehiculo,
                   v.placas, COALESCE((SELECT SUM(monto) FROM pagos p WHERE p.orden_id=o.id),0) AS pagado
            FROM ordenes o
            LEFT JOIN clientes c ON c.id=o.cliente_id
            LEFT JOIN vehiculos v ON v.id=o.vehiculo_id
            WHERE o.id=?
        """, (order_id,)).fetchone()
        return dict(row) if row else None

    def update_order_status(self, order_id: int, status: str) -> None:
        with self.conn:
            self.conn.execute("UPDATE ordenes SET estado=? WHERE id=?", (status, order_id))

    # ---------- consultas ----------
    def all(self, entity: Entity) -> list[dict]:
        select, joins = ["t.*"], []
        for i, f in enumerate(entity.fields):
            if f.kind == "ref":
                joins.append(f"LEFT JOIN {f.ref} r{i} ON r{i}.id = t.{f.key}")
                select.append(f"{self._label_sql(f.ref, f'r{i}')} AS {f.key}__label")
        sql = (
            f"SELECT {', '.join(select)} FROM {entity.table} t "
            f"{' '.join(joins)} ORDER BY t.id DESC"
        )
        return [dict(row) for row in self.conn.execute(sql)]

    def ref_options(self, table: str, client_id: int | None = None) -> list[tuple[int, str]]:
        sql = (
            f"SELECT id, {self._label_sql(table)} AS label FROM {table} t "
        )
        params = []
        if table == "vehiculos" and client_id:
            sql += " WHERE t.cliente_id = ? "
            params.append(client_id)
        sql += " ORDER BY label COLLATE NOCASE"
        rows = self.conn.execute(sql, params)
        return [(row[0], row[1]) for row in rows]

    # ---------- altas, cambios y bajas ----------
    def insert(self, entity: Entity, values: dict) -> None:
        keys = [f.key for f in entity.fields]
        placeholders = ", ".join("?" for _ in keys)
        with self.conn:
            self.conn.execute(
                f"INSERT INTO {entity.table} ({', '.join(keys)}) VALUES ({placeholders})",
                [values[k] for k in keys],
            )

    def update(self, entity: Entity, record_id: int, values: dict) -> None:
        keys = [f.key for f in entity.fields]
        assignments = ", ".join(f"{k} = ?" for k in keys)
        with self.conn:
            self.conn.execute(
                f"UPDATE {entity.table} SET {assignments} WHERE id = ?",
                [values[k] for k in keys] + [record_id],
            )

    def delete(self, entity: Entity, record_id: int) -> None:
        # Evita dejar vehículos o clientes sin relación con su historial.
        if entity.table == "vehiculos":
            used = self.conn.execute(
                "SELECT COUNT(*) FROM ordenes WHERE vehiculo_id = ?", (record_id,)
            ).fetchone()[0]
            if used:
                raise ValueError("No se puede eliminar: este vehículo tiene órdenes en su historial.")
        try:
            with self.conn:
                self.conn.execute(f"DELETE FROM {entity.table} WHERE id = ?", (record_id,))
        except sqlite3.IntegrityError:
            raise ValueError(
                f"No se puede eliminar: este {entity.singular} tiene registros asociados."
            ) from None

    # ---------- historial ----------
    def vehicle_history(self, vehicle_id: int) -> list[dict]:
        rows = self.conn.execute(
            "SELECT id, fecha, servicio, estado, costo, notas "
            "FROM ordenes WHERE vehiculo_id = ? ORDER BY fecha DESC, id DESC",
            (vehicle_id,),
        )
        return [dict(r) for r in rows]

    def client_history(self, client_id: int) -> list[dict]:
        rows = self.conn.execute(
            "SELECT o.id, o.fecha, o.servicio, o.estado, o.costo, "
            "TRIM(v.marca || ' ' || v.modelo) AS vehiculo, v.placas "
            "FROM ordenes o LEFT JOIN vehiculos v ON v.id = o.vehiculo_id "
            "WHERE o.cliente_id = ? ORDER BY o.fecha DESC, o.id DESC",
            (client_id,),
        )
        return [dict(r) for r in rows]

    def vehicle_count_for_client(self, client_id: int) -> int:
        return self.conn.execute(
            "SELECT COUNT(*) FROM vehiculos WHERE cliente_id = ?", (client_id,)
        ).fetchone()[0]

    # ---------- reportes ----------
    def count(self, table: str) -> int:
        return self.conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]

    def orders_by_status(self) -> list[tuple[str, int, float]]:
        rows = self.conn.execute(
            "SELECT estado, COUNT(*), COALESCE(SUM(costo), 0) FROM ordenes GROUP BY estado"
        )
        return [(r[0], r[1], r[2]) for r in rows]
