from PySide6.QtCore import Qt
from PySide6.QtWidgets import QDialog, QHBoxLayout, QLabel, QPushButton, QVBoxLayout, QDialogButtonBox, QWidget

from app.schema import ESTADOS


class StatusStep(QPushButton):
    def __init__(self, index: int, title: str, parent=None):
        super().__init__(parent)
        self.index = index
        self.title = title
        self.setCheckable(True)
        self.setMinimumHeight(76)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setText(f"{index + 1}\n{title}")
        self.setStyleSheet("""
            QPushButton { border: 1px solid #2A2A2A; border-radius: 12px; background: #1E1E1E;
                          color: #8C8C8C; font-size: 14px; font-weight: 600; padding: 8px 18px; }
            QPushButton:hover { border: 1px solid #A8232A; color: #EDEDED; }
            QPushButton:checked { background: #A8232A; color: white; border: 1px solid #A8232A; }
        """)


class StatusFlowDialog(QDialog):
    """Selector visual de las tres etapas de una orden."""
    def __init__(self, parent, current_status: str, order_id: int):
        super().__init__(parent)
        self.selected_status = current_status if current_status in ESTADOS else ESTADOS[0]
        self.setWindowTitle(f"Flujo de orden · OT-{order_id:05d}")
        self.setMinimumWidth(760)

        title = QLabel(f"Orden de trabajo <b>OT-{order_id:05d}</b>")
        title.setObjectName("sectionTitle")
        subtitle = QLabel("Selecciona la etapa actual de la orden y actualízala desde aquí.")
        subtitle.setStyleSheet("color: #8C8C8C;")

        flow = QHBoxLayout()
        flow.setSpacing(8)
        self.steps = []
        for i, status in enumerate(ESTADOS):
            step = StatusStep(i, status)
            step.clicked.connect(lambda _checked=False, value=status: self._select(value))
            self.steps.append(step)
            flow.addWidget(step, 1)
            if i < len(ESTADOS) - 1:
                arrow = QLabel("→")
                arrow.setAlignment(Qt.AlignmentFlag.AlignCenter)
                arrow.setStyleSheet("color: #555555; font-size: 24px; font-weight: 700;")
                flow.addWidget(arrow)

        self.current = QLabel()
        self.current.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.current.setStyleSheet("color: #EDEDED; font-size: 16px; font-weight: 600; padding: 10px;")

        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        buttons.button(QDialogButtonBox.StandardButton.Save).setText("Actualizar estado")
        buttons.button(QDialogButtonBox.StandardButton.Cancel).setText("Cancelar")
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(26, 24, 26, 22)
        layout.setSpacing(12)
        layout.addWidget(title)
        layout.addWidget(subtitle)
        layout.addSpacing(8)
        layout.addLayout(flow)
        layout.addWidget(self.current)
        layout.addWidget(buttons)
        self._refresh_visual()

    def _select(self, status: str):
        self.selected_status = status
        self._refresh_visual()

    def _refresh_visual(self):
        for step in self.steps:
            step.setChecked(step.title == self.selected_status)
        self.current.setText(f"Estado seleccionado:  {self.selected_status}")
