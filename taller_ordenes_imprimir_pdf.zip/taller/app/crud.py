"""Componentes reutilizables de altas, edición, bajas e historial."""
from PySide6.QtCore import QDate
from PySide6.QtWidgets import (
    QAbstractItemView, QComboBox, QDateEdit, QDialog, QDialogButtonBox,
    QDoubleSpinBox, QFormLayout, QHBoxLayout, QHeaderView, QLabel, QLineEdit,
    QMessageBox, QPlainTextEdit, QPushButton, QTableWidget, QTableWidgetItem,
    QVBoxLayout, QWidget,
)

from app.schema import ENTITIES, Entity, Field, ESTADOS
from app.status_flow import StatusFlowDialog
from app.order_detail import OrderDetailDialog

DB_DATE = "yyyy-MM-dd"
SHOW_DATE = "dd/MM/yyyy"


class RecordDialog(QDialog):
    def __init__(self, parent, db, entity: Entity, record: dict | None = None):
        super().__init__(parent)
        self.db, self.entity = db, entity
        self.result_values: dict = {}
        verb = "Editar" if record else "Dar de alta"
        self.setWindowTitle(f"{verb} {entity.singular}")
        self.setMinimumWidth(500)

        form = QFormLayout()
        form.setSpacing(12)
        self.inputs: dict[str, QWidget] = {}
        for f in entity.fields:
            widget = self._make_input(f)
            self.inputs[f.key] = widget
            form.addRow(f.label + (" *" if f.required else ""), widget)
        self._setup_vehicle_dependency()
        if record:
            self._load(record)

        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel
        )
        save = buttons.button(QDialogButtonBox.StandardButton.Save)
        save.setText("Guardar")
        save.setObjectName("primary")
        buttons.button(QDialogButtonBox.StandardButton.Cancel).setText("Cancelar")
        buttons.accepted.connect(self._validate_and_accept)
        buttons.rejected.connect(self.reject)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 20)
        layout.setSpacing(16)
        layout.addLayout(form)
        layout.addWidget(buttons)

    def _make_input(self, f: Field) -> QWidget:
        if f.kind == "multiline":
            w = QPlainTextEdit()
            w.setFixedHeight(90)
            return w
        if f.kind == "number":
            w = QDoubleSpinBox()
            w.setRange(0, 99_999_999)
            w.setDecimals(2)
            w.setPrefix("$ ") if "costo" in f.key else None
            w.setGroupSeparatorShown(True)
            return w
        if f.kind == "date":
            w = QDateEdit(QDate.currentDate())
            w.setCalendarPopup(True)
            w.setDisplayFormat(SHOW_DATE)
            return w
        if f.kind == "choice":
            w = QComboBox()
            w.addItems(f.options)
            return w
        if f.kind == "ref":
            w = QComboBox()
            for record_id, label in self.db.ref_options(f.ref):
                w.addItem(label, record_id)
            return w
        return QLineEdit()

    def _setup_vehicle_dependency(self) -> None:
        # En una orden solo deben aparecer los vehículos del cliente seleccionado.
        if "cliente_id" not in self.inputs or "vehiculo_id" not in self.inputs:
            return
        client = self.inputs["cliente_id"]
        vehicle = self.inputs["vehiculo_id"]

        def reload_vehicles(client_id):
            current = vehicle.currentData()
            vehicle.blockSignals(True)
            vehicle.clear()
            for record_id, label in self.db.ref_options("vehiculos", client_id=client_id):
                vehicle.addItem(label, record_id)
            if current is not None:
                idx = vehicle.findData(current)
                if idx >= 0:
                    vehicle.setCurrentIndex(idx)
            vehicle.blockSignals(False)

        client.currentIndexChanged.connect(lambda _index: reload_vehicles(client.currentData()))
        reload_vehicles(client.currentData())

    def _load(self, record: dict) -> None:
        for f in self.entity.fields:
            w, value = self.inputs[f.key], record.get(f.key)
            if f.kind == "multiline":
                w.setPlainText(value or "")
            elif f.kind == "number":
                w.setValue(float(value or 0))
            elif f.kind == "date":
                date = QDate.fromString(value or "", DB_DATE)
                if date.isValid():
                    w.setDate(date)
            elif f.kind == "choice":
                w.setCurrentText(value or "")
            elif f.kind == "ref":
                idx = w.findData(value)
                if idx >= 0:
                    w.setCurrentIndex(idx)
            else:
                w.setText(str(value or ""))

    def _values(self) -> dict:
        values = {}
        for f in self.entity.fields:
            w = self.inputs[f.key]
            if f.kind == "multiline":
                values[f.key] = w.toPlainText().strip()
            elif f.kind == "number":
                values[f.key] = w.value()
            elif f.kind == "date":
                values[f.key] = w.date().toString(DB_DATE)
            elif f.kind == "choice":
                values[f.key] = w.currentText()
            elif f.kind == "ref":
                values[f.key] = w.currentData()
            else:
                values[f.key] = w.text().strip()
        return values

    def _validate_and_accept(self) -> None:
        values = self._values()
        for f in self.entity.fields:
            if f.required and values[f.key] in ("", None):
                if f.kind == "ref":
                    msg = f"Primero da de alta al menos un registro en «{ENTITIES[f.ref].title}»."
                else:
                    msg = f"El campo «{f.label}» es obligatorio."
                QMessageBox.warning(self, "Falta información", msg)
                return
        self.result_values = values
        self.accept()


class HistoryDialog(QDialog):
    """Historial de órdenes de un cliente o vehículo."""
    def __init__(self, parent, db, *, client_id=None, vehicle_id=None, title="Historial"):
        super().__init__(parent)
        self.db = db
        self.client_id = client_id
        self.vehicle_id = vehicle_id
        self.setWindowTitle(title)
        self.resize(850, 480)

        self.info = QLabel()
        self.info.setObjectName("sectionTitle")
        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(
            ["OT", "Fecha", "Vehículo", "Placas", "Estado", "Total"]
        )
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.NoSelection)
        self.table.setAlternatingRowColors(True)
        self.table.setShowGrid(False)
        self.table.verticalHeader().setVisible(False)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)

        close = QPushButton("Cerrar")
        close.clicked.connect(self.accept)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(12)
        layout.addWidget(self.info)
        layout.addWidget(self.table)
        layout.addWidget(close)
        self.refresh()

    def refresh(self):
        if self.vehicle_id:
            vehicle = self.db.conn.execute(
                "SELECT marca, modelo, placas FROM vehiculos WHERE id = ?", (self.vehicle_id,)
            ).fetchone()
            rows = self.db.vehicle_history(self.vehicle_id)
            name = " ".join(x for x in (vehicle[0], vehicle[1]) if x) if vehicle else "Vehículo"
            self.info.setText(f"Historial de {name} · {vehicle[2] if vehicle and vehicle[2] else 'Sin placas'}")
        else:
            client = self.db.conn.execute(
                "SELECT nombre FROM clientes WHERE id = ?", (self.client_id,)
            ).fetchone()
            rows = self.db.client_history(self.client_id)
            self.info.setText(f"Historial de {client[0] if client else 'Cliente'}")

        self.table.setRowCount(len(rows))
        for r, row in enumerate(rows):
            if self.vehicle_id:
                values = (
                    row["id"],
                    self._date(row["fecha"]),
                    "",
                    "",
                    row["estado"],
                    f"${row['costo']:,.2f}",
                )
            else:
                values = (
                    row["id"],
                    self._date(row["fecha"]),
                    row.get("vehiculo") or "—",
                    row.get("placas") or "—",
                    row["estado"],
                    f"${row['costo']:,.2f}",
                )
            for c, value in enumerate(values):
                self.table.setItem(r, c, QTableWidgetItem(str(value)))

    @staticmethod
    def _date(value):
        date = QDate.fromString(value or "", DB_DATE)
        return date.toString(SHOW_DATE) if date.isValid() else value or ""


class CrudTab(QWidget):
    def __init__(self, db, entity: Entity, history_mode: str | None = None):
        super().__init__()
        self.db, self.entity = db, entity
        self.history_mode = history_mode
        self.visible_fields = [f for f in entity.fields if f.in_table]
        self.rows: list[dict] = []

        self.search = QLineEdit()
        self.search.setPlaceholderText(f"Buscar en {entity.title.lower()}…")
        self.search.textChanged.connect(self._apply_filter)

        self.add_btn = QPushButton(f"＋  Dar de alta {entity.singular}")
        self.add_btn.setObjectName("primary")
        self.add_btn.clicked.connect(self.add_record)
        self.edit_btn = QPushButton("Editar")
        self.edit_btn.clicked.connect(self.edit_record)
        self.status_btn = QPushButton("Cambiar estado")
        self.status_btn.clicked.connect(self.change_status)
        self.detail_btn = QPushButton("Ver orden")
        self.detail_btn.clicked.connect(self.show_detail)
        self.history_btn = QPushButton("Ver historial")
        self.history_btn.clicked.connect(self.show_history)
        self.delete_btn = QPushButton("Eliminar")
        self.delete_btn.clicked.connect(self.delete_record)

        top = QHBoxLayout()
        top.setSpacing(10)
        top.addWidget(self.search, 1)
        top.addWidget(self.add_btn)
        top.addWidget(self.edit_btn)
        if entity.table == "ordenes":
            top.addWidget(self.status_btn)
            top.addWidget(self.detail_btn)
        if history_mode:
            top.addWidget(self.history_btn)
        top.addWidget(self.delete_btn)

        self.table = QTableWidget(0, len(self.visible_fields) + 1)
        self.table.setHorizontalHeaderLabels(["No."] + [f.label for f in self.visible_fields])
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.table.setAlternatingRowColors(True)
        self.table.setShowGrid(False)
        self.table.verticalHeader().setVisible(False)
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        self.table.itemSelectionChanged.connect(self._update_buttons)
        self.table.doubleClicked.connect(self._double_click)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(14)
        layout.addLayout(top)
        layout.addWidget(self.table)
        self.refresh()

    def refresh(self) -> None:
        self.rows = self.db.all(self.entity)
        self.table.setRowCount(len(self.rows))
        for r, record in enumerate(self.rows):
            self.table.setItem(r, 0, QTableWidgetItem(str(record["id"])))
            for c, f in enumerate(self.visible_fields, start=1):
                self.table.setItem(r, c, QTableWidgetItem(self._display(record, f)))
        self.table.resizeColumnsToContents()
        self._apply_filter()
        self._update_buttons()

    @staticmethod
    def _display(record: dict, f: Field) -> str:
        value = record.get(f.key)
        if f.kind == "date":
            date = QDate.fromString(value or "", DB_DATE)
            return date.toString(SHOW_DATE) if date.isValid() else (value or "")
        if f.kind == "number":
            return f"${float(value or 0):,.2f}"
        if f.kind == "ref":
            return record.get(f"{f.key}__label") or "—"
        if f.kind == "multiline":
            line = " ".join((value or "").split())
            return line if len(line) <= 60 else line[:57] + "…"
        return str(value or "")

    def _apply_filter(self) -> None:
        text = self.search.text().strip().lower()
        for r in range(self.table.rowCount()):
            haystack = " ".join(
                self.table.item(r, c).text().lower() for c in range(self.table.columnCount())
            )
            self.table.setRowHidden(r, text not in haystack)

    def _selected(self) -> dict | None:
        row = self.table.currentRow()
        return self.rows[row] if 0 <= row < len(self.rows) else None

    def _update_buttons(self) -> None:
        has_selection = self._selected() is not None
        self.edit_btn.setEnabled(has_selection)
        self.delete_btn.setEnabled(has_selection)
        if hasattr(self, "status_btn"):
            self.status_btn.setEnabled(has_selection)
        if hasattr(self, "detail_btn"):
            self.detail_btn.setEnabled(has_selection)
        if self.history_mode:
            self.history_btn.setEnabled(has_selection)

    def add_record(self) -> None:
        dialog = RecordDialog(self, self.db, self.entity)
        if dialog.exec():
            try:
                self.db.insert(self.entity, dialog.result_values)
            except Exception as error:
                QMessageBox.critical(self, "Error", f"No se pudo guardar el registro.\n\n{error}")
                return
            self.refresh()

    def edit_record(self) -> None:
        record = self._selected()
        if record is None:
            return
        dialog = RecordDialog(self, self.db, self.entity, record)
        if dialog.exec():
            try:
                self.db.update(self.entity, record["id"], dialog.result_values)
            except Exception as error:
                QMessageBox.critical(self, "Error", f"No se pudo actualizar el registro.\n\n{error}")
                return
            self.refresh()

    def _double_click(self, _index) -> None:
        if self.entity.table == "ordenes":
            self.show_detail()
        else:
            self.edit_record()

    def show_detail(self) -> None:
        record = self._selected()
        if record is None or self.entity.table != "ordenes":
            return
        dialog = OrderDetailDialog(self, self.db, record["id"])
        dialog.exec()
        self.refresh()

    def change_status(self) -> None:
        record = self._selected()
        if record is None or self.entity.table != "ordenes":
            return
        dialog = StatusFlowDialog(
            self, record.get("estado") or ESTADOS[0], record["id"]
        )
        if dialog.exec():
            try:
                values = {f.key: record.get(f.key) for f in self.entity.fields}
                values["estado"] = dialog.selected_status
                self.db.update(self.entity, record["id"], values)
            except Exception as error:
                QMessageBox.critical(self, "Error", f"No se pudo actualizar el estado.\n\n{error}")
                return
            self.refresh()

    def show_history(self) -> None:
        record = self._selected()
        if not record:
            return
        if self.history_mode == "client":
            dialog = HistoryDialog(
                self, self.db, client_id=record["id"],
                title=f"Historial · {record.get('nombre', 'Cliente')}"
            )
        else:
            dialog = HistoryDialog(
                self, self.db, vehicle_id=record["id"],
                title="Historial del vehículo"
            )
        dialog.exec()

    def delete_record(self) -> None:
        record = self._selected()
        if record is None:
            return
        answer = QMessageBox.question(
            self, "Eliminar", f"¿Eliminar este {self.entity.singular}? No se puede deshacer."
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        try:
            self.db.delete(self.entity, record["id"])
        except ValueError as error:
            QMessageBox.warning(self, "No se puede eliminar", str(error))
            return
        self.refresh()
