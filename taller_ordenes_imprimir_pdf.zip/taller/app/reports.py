"""Pestaña de reportes: tarjetas de resumen y órdenes por estado."""
from PySide6.QtWidgets import (
    QAbstractItemView, QFrame, QHBoxLayout, QHeaderView, QLabel,
    QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget,
)

from app.schema import ESTADO_COBRADO, ESTADOS, ESTADOS_CERRADOS


class ReportsTab(QWidget):
    def __init__(self, db):
        super().__init__()
        self.db = db

        self.cards = {}
        cards_row = QHBoxLayout()
        cards_row.setSpacing(14)
        for key, label in (
            ("abiertas", "Órdenes abiertas"),
            ("clientes", "Clientes"),
            ("proveedores", "Proveedores"),
            ("ingresos", "Ingresos (órdenes entregadas)"),
        ):
            card, value_label = self._make_card(label)
            self.cards[key] = value_label
            cards_row.addWidget(card)

        title = QLabel("Órdenes por estado")
        title.setObjectName("sectionTitle")

        self.table = QTableWidget(0, 3)
        self.table.setHorizontalHeaderLabels(["Estado", "Órdenes", "Monto"])
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.NoSelection)
        self.table.setAlternatingRowColors(True)
        self.table.setShowGrid(False)
        self.table.verticalHeader().setVisible(False)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(16)
        layout.addLayout(cards_row)
        layout.addWidget(title)
        layout.addWidget(self.table)

        self.refresh()

    @staticmethod
    def _make_card(label: str):
        card = QFrame()
        card.setObjectName("card")
        value = QLabel("0")
        value.setObjectName("cardValue")
        caption = QLabel(label)
        caption.setObjectName("cardLabel")
        box = QVBoxLayout(card)
        box.setContentsMargins(18, 14, 18, 14)
        box.addWidget(caption)
        box.addWidget(value)
        return card, value

    def refresh(self) -> None:
        by_status = {estado: (n, total) for estado, n, total in self.db.orders_by_status()}

        abiertas = sum(n for estado, (n, _) in by_status.items() if estado not in ESTADOS_CERRADOS)
        ingresos = by_status.get(ESTADO_COBRADO, (0, 0.0))[1]

        self.cards["abiertas"].setText(str(abiertas))
        self.cards["clientes"].setText(str(self.db.count("clientes")))
        self.cards["proveedores"].setText(str(self.db.count("proveedores")))
        self.cards["ingresos"].setText(f"${ingresos:,.2f}")

        self.table.setRowCount(len(ESTADOS))
        for r, estado in enumerate(ESTADOS):
            n, total = by_status.get(estado, (0, 0.0))
            for c, text in enumerate((estado, str(n), f"${total:,.2f}")):
                self.table.setItem(r, c, QTableWidgetItem(text))
