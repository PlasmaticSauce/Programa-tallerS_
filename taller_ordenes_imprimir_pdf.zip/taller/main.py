"""Punto de entrada. Ejecuta con:  python main.py"""
import sys

from PySide6.QtWidgets import QApplication

from app.db import Database
from app.style import STYLESHEET
from app.window import MainWindow


def main() -> None:
    app = QApplication(sys.argv)
    app.setStyle("Fusion")          # base neutra sobre la que se aplica nuestro estilo
    app.setStyleSheet(STYLESHEET)
    window = MainWindow(Database())
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
