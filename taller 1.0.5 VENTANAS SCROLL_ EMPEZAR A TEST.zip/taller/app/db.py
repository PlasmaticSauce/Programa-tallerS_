"""Base de datos SQLite. Crea las tablas a partir de schema.py."""
import os
import shutil
import sqlite3
import sys
import uuid
from datetime import datetime
from pathlib import Path

from app.schema import ENTITIES, ORDENES, PRODUCTOS, Entity, normalize_plate

APP_FOLDER = "TallerMecanico"


def app_data_dir() -> Path:
    """Carpeta donde vive TODO lo del programa (base de datos, imágenes, reportes...).

    - Ya empaquetado como .exe: junto a Documentos/AppData del usuario, para que
      sobreviva a reinstalar o actualizar el programa.
    - Corriendo con "python main.py" (como ahora, en desarrollo): una carpeta
      "data" dentro del proyecto, para no ensuciar tu perfil de Windows mientras
      pruebas cambios.
    """
    if getattr(sys, "frozen", False):
        if sys.platform == "win32":
            base = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local"))
        elif sys.platform == "darwin":
            base = Path.home() / "Library" / "Application Support"
        else:
            base = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share"))
        return base / APP_FOLDER
    return Path(__file__).resolve().parent.parent / "data"


DB_PATH = app_data_dir() / "taller.db"


class Database:
    def __init__(self, path: Path = DB_PATH):
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        self.data_dir = path.parent
        self.product_images_dir = path.parent / "imagenes_productos"
        self.images_dir = path.parent / "imagenes"   # aquí se copian las fotos adjuntas
        self.conn = sqlite3.connect(path)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA foreign_keys = ON")
        for entity in ENTITIES.values():
            self._create_table(entity)
        self._create_images_table()
        self._create_settings_table()
        self._create_movements_table()
        self._create_saved_reports_table()

    # ---------- estructura ----------
    def _create_table(self, entity: Entity) -> None:
        columns = ["id INTEGER PRIMARY KEY AUTOINCREMENT"]
        for f in entity.fields:
            if f.kind == "ref":
                columns.append(f"{f.key} INTEGER NOT NULL REFERENCES {f.ref}(id)")
            elif f.kind == "number":
                columns.append(f"{f.key} REAL NOT NULL DEFAULT 0")
            elif f.kind == "integer":
                columns.append(f"{f.key} INTEGER NOT NULL DEFAULT 0")
            elif f.unique:
                columns.append(f"{f.key} TEXT COLLATE NOCASE NOT NULL DEFAULT '' UNIQUE")
            else:
                columns.append(f"{f.key} TEXT NOT NULL DEFAULT ''")
        with self.conn:
            self.conn.execute(
                f"CREATE TABLE IF NOT EXISTS {entity.table} ({', '.join(columns)})"
            )

    def _create_images_table(self) -> None:
        with self.conn:
            self.conn.execute(
                """
                CREATE TABLE IF NOT EXISTS orden_imagenes (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    orden_id INTEGER NOT NULL REFERENCES ordenes(id) ON DELETE CASCADE,
                    archivo TEXT NOT NULL
                )
                """
            )

    def _create_movements_table(self) -> None:
        with self.conn:
            self.conn.execute(
                """
                CREATE TABLE IF NOT EXISTS movimientos (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    fecha TEXT NOT NULL,
                    producto_id INTEGER NOT NULL REFERENCES productos(id) ON DELETE CASCADE,
                    tipo TEXT NOT NULL CHECK (tipo IN ('alta', 'baja')),
                    cantidad INTEGER NOT NULL,
                    motivo TEXT NOT NULL DEFAULT '',
                    proveedor_id INTEGER REFERENCES proveedores(id)
                )
                """
            )
            try:  # migración: bases creadas antes de agregar la columna proveedor_id
                self.conn.execute("ALTER TABLE movimientos ADD COLUMN proveedor_id INTEGER REFERENCES proveedores(id)")
            except sqlite3.OperationalError:
                pass

    def _create_saved_reports_table(self) -> None:
        with self.conn:
            self.conn.execute(
                """
                CREATE TABLE IF NOT EXISTS reportes_guardados (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    creado TEXT NOT NULL,
                    titulo TEXT NOT NULL,
                    filtros TEXT NOT NULL DEFAULT '',
                    filas INTEGER NOT NULL DEFAULT 0,
                    archivo TEXT NOT NULL
                )
                """
            )

    def _create_settings_table(self) -> None:
        with self.conn:
            self.conn.execute(
                "CREATE TABLE IF NOT EXISTS ajustes (clave TEXT PRIMARY KEY, valor TEXT NOT NULL)"
            )

    # ---------- consultas ----------
    def all(self, entity: Entity) -> list[dict]:
        """Todos los registros, del más nuevo al más viejo.
        Para campos 'ref' agrega '<campo>__label' con el nombre legible."""
        select, joins = ["t.*"], []
        for i, f in enumerate(entity.fields):
            if f.kind == "ref":
                label_col = ENTITIES[f.ref].fields[0].key
                joins.append(f"LEFT JOIN {f.ref} r{i} ON r{i}.id = t.{f.key}")
                select.append(f"r{i}.{label_col} AS {f.key}__label")
        sql = (
            f"SELECT {', '.join(select)} FROM {entity.table} t "
            f"{' '.join(joins)} ORDER BY t.id DESC"
        )
        return [dict(row) for row in self.conn.execute(sql)]

    def ref_options(self, table: str) -> list[tuple[int, str]]:
        """Lista (id, nombre) para llenar un combo de selección."""
        label_col = ENTITIES[table].fields[0].key
        rows = self.conn.execute(
            f"SELECT id, {label_col} FROM {table} ORDER BY {label_col} COLLATE NOCASE"
        )
        return [(row[0], row[1]) for row in rows]

    # ---------- altas, cambios y bajas ----------
    def insert(self, entity: Entity, values: dict) -> int:
        """Guarda un registro nuevo y devuelve su id."""
        keys = [f.key for f in entity.fields]
        placeholders = ", ".join("?" for _ in keys)
        try:
            with self.conn:
                cursor = self.conn.execute(
                    f"INSERT INTO {entity.table} ({', '.join(keys)}) VALUES ({placeholders})",
                    [values[k] for k in keys],
                )
        except sqlite3.IntegrityError:
            raise ValueError("Ya existe un registro con ese valor único (por ejemplo, el código).") from None
        return cursor.lastrowid

    def update(self, entity: Entity, record_id: int, values: dict) -> None:
        keys = [f.key for f in entity.fields]
        assignments = ", ".join(f"{k} = ?" for k in keys)
        try:
            with self.conn:
                self.conn.execute(
                    f"UPDATE {entity.table} SET {assignments} WHERE id = ?",
                    [values[k] for k in keys] + [record_id],
                )
        except sqlite3.IntegrityError:
            raise ValueError("Ya existe un registro con ese valor único (por ejemplo, el código).") from None

    def delete(self, entity: Entity, record_id: int) -> None:
        # Antes de borrar, anotamos las fotos del registro para quitarlas del disco después.
        photo_dir, photo_files = self.images_dir, []
        if entity.table == "ordenes":
            photo_files = [
                row[0]
                for row in self.conn.execute(
                    "SELECT archivo FROM orden_imagenes WHERE orden_id = ?", (record_id,)
                )
            ]
        elif entity.table == "productos":
            row = self.conn.execute("SELECT imagen FROM productos WHERE id = ?", (record_id,)).fetchone()
            photo_dir, photo_files = self.product_images_dir, [row[0]] if row and row[0] else []
        try:
            with self.conn:
                self.conn.execute(f"DELETE FROM {entity.table} WHERE id = ?", (record_id,))
        except sqlite3.IntegrityError:
            raise ValueError(
                f"No se puede eliminar: este {entity.singular} tiene órdenes asociadas."
            ) from None
        for name in photo_files:
            (photo_dir / name).unlink(missing_ok=True)

    def value_exists(self, entity: Entity, key: str, value, exclude_id: int | None = None) -> bool:
        """¿Ya hay otro registro con ese valor? (sin distinguir mayúsculas)"""
        row = self.conn.execute(
            f"SELECT 1 FROM {entity.table} WHERE {key} = ? COLLATE NOCASE AND id != ?",
            (value, exclude_id or 0),
        ).fetchone()
        return row is not None

    # ---------- órdenes: folio, placas y visitas ----------
    def next_order_id(self) -> int:
        """Número que tendrá la siguiente orden (para mostrar el folio antes de guardar)."""
        row = self.conn.execute(
            "SELECT seq FROM sqlite_sequence WHERE name = 'ordenes'"
        ).fetchone()
        return (row[0] if row else 0) + 1

    def orders_by_plate(self, plate: str) -> list[dict]:
        """Órdenes anteriores con esas placas (la más reciente primero)."""
        target = normalize_plate(plate)
        if not target:
            return []
        return [o for o in self.all(ORDENES) if normalize_plate(o["placas"]) == target]

    # ---------- imágenes de las órdenes ----------
    def images_for(self, order_id: int) -> list[dict]:
        rows = self.conn.execute(
            "SELECT id, archivo FROM orden_imagenes WHERE orden_id = ? ORDER BY id", (order_id,)
        )
        return [
            {"id": r["id"], "path": str(self.images_dir / r["archivo"])} for r in rows
        ]

    def image_counts(self) -> dict[int, int]:
        rows = self.conn.execute(
            "SELECT orden_id, COUNT(*) FROM orden_imagenes GROUP BY orden_id"
        )
        return {r[0]: r[1] for r in rows}

    def add_image(self, order_id: int, source_path: str) -> None:
        """Copia la imagen a data/imagenes y la enlaza a la orden."""
        self.images_dir.mkdir(parents=True, exist_ok=True)
        name = f"{uuid.uuid4().hex}{Path(source_path).suffix.lower()}"
        shutil.copy2(source_path, self.images_dir / name)
        with self.conn:
            self.conn.execute(
                "INSERT INTO orden_imagenes (orden_id, archivo) VALUES (?, ?)", (order_id, name)
            )

    def remove_image(self, image_id: int) -> None:
        row = self.conn.execute(
            "SELECT archivo FROM orden_imagenes WHERE id = ?", (image_id,)
        ).fetchone()
        with self.conn:
            self.conn.execute("DELETE FROM orden_imagenes WHERE id = ?", (image_id,))
        if row:
            (self.images_dir / row[0]).unlink(missing_ok=True)

    def get_record(self, entity: Entity, record_id: int) -> dict | None:
        row = self.conn.execute(
            f"SELECT * FROM {entity.table} WHERE id = ?", (record_id,)
        ).fetchone()
        return dict(row) if row else None

    def set_order_status(self, order_id: int, estado: str) -> None:
        with self.conn:
            self.conn.execute("UPDATE ordenes SET estado = ? WHERE id = ?", (estado, order_id))

    # ---------- ajustes (mensajes de WhatsApp, etc.) ----------
    def get_setting(self, key: str, default: str = "") -> str:
        row = self.conn.execute("SELECT valor FROM ajustes WHERE clave = ?", (key,)).fetchone()
        return row[0] if row else default

    def set_setting(self, key: str, value: str) -> None:
        with self.conn:
            self.conn.execute(
                "INSERT INTO ajustes (clave, valor) VALUES (?, ?) "
                "ON CONFLICT(clave) DO UPDATE SET valor = excluded.valor",
                (key, value),
            )

    # ---------- almacén ----------
    def find_product_by_code(self, code: str) -> dict | None:
        row = self.conn.execute(
            "SELECT * FROM productos WHERE codigo = ? COLLATE NOCASE", (code.strip(),)
        ).fetchone()
        return dict(row) if row else None

    def find_products_by_name(self, text: str) -> list[dict]:
        rows = self.conn.execute(
            "SELECT * FROM productos WHERE nombre LIKE ? ORDER BY nombre COLLATE NOCASE",
            (f"%{text.strip()}%",),
        )
        return [dict(r) for r in rows]

    def apply_movements(
        self, items: list[tuple[int, int]], tipo: str, motivo: str, proveedor_id: int | None = None
    ) -> None:
        """Aplica altas (suma) o bajas (resta) de varios productos de un solo golpe.
        Si algo falla (por ejemplo, no hay existencia suficiente), no se aplica NADA.
        proveedor_id es opcional y solo tiene sentido en altas (de quién se compró)."""
        sign = 1 if tipo == "alta" else -1
        now = datetime.now().isoformat(timespec="seconds")
        with self.conn:
            for product_id, qty in items:
                row = self.conn.execute(
                    "SELECT nombre, existencia FROM productos WHERE id = ?", (product_id,)
                ).fetchone()
                if row is None:
                    raise ValueError("Uno de los productos ya no existe.")
                new_stock = row["existencia"] + sign * qty
                if new_stock < 0:
                    raise ValueError(
                        f"Existencia insuficiente de «{row['nombre']}»: "
                        f"hay {row['existencia']} y se intentan dar de baja {qty}."
                    )
                self.conn.execute(
                    "UPDATE productos SET existencia = ? WHERE id = ?", (new_stock, product_id)
                )
                self.conn.execute(
                    "INSERT INTO movimientos (fecha, producto_id, tipo, cantidad, motivo, proveedor_id) "
                    "VALUES (?, ?, ?, ?, ?, ?)",
                    (now, product_id, tipo, qty, motivo, proveedor_id if tipo == "alta" else None),
                )

    def store_product_image(self, source_path: str) -> str:
        self.product_images_dir.mkdir(parents=True, exist_ok=True)
        name = f"{uuid.uuid4().hex}{Path(source_path).suffix.lower()}"
        shutil.copy2(source_path, self.product_images_dir / name)
        return name

    def product_image_path(self, name: str) -> str:
        return str(self.product_images_dir / name)

    def delete_product_image(self, name: str) -> None:
        (self.product_images_dir / name).unlink(missing_ok=True)

    def movements(self) -> list[dict]:
        """Todos los movimientos de almacén con los datos del producto y el proveedor (si aplica)."""
        rows = self.conn.execute(
            "SELECT m.fecha, m.tipo, m.cantidad, m.motivo, p.codigo, p.nombre, p.categoria, "
            "prov.empresa AS proveedor "
            "FROM movimientos m JOIN productos p ON p.id = m.producto_id "
            "LEFT JOIN proveedores prov ON prov.id = m.proveedor_id "
            "ORDER BY m.fecha, m.id"
        )
        return [dict(r) for r in rows]

    # ---------- reportes guardados ----------
    def add_saved_report(self, title: str, filters: str, rows: int, path: str) -> None:
        with self.conn:
            self.conn.execute(
                "INSERT INTO reportes_guardados (creado, titulo, filtros, filas, archivo) VALUES (?, ?, ?, ?, ?)",
                (datetime.now().isoformat(timespec="seconds"), title, filters, rows, path),
            )

    def list_saved_reports(self) -> list[dict]:
        rows = self.conn.execute("SELECT * FROM reportes_guardados ORDER BY id DESC")
        return [dict(r) for r in rows]

    def delete_saved_report(self, report_id: int) -> None:
        with self.conn:
            self.conn.execute("DELETE FROM reportes_guardados WHERE id = ?", (report_id,))

    # ---------- respaldo ----------
    def backup(self, dest: Path) -> None:
        """Copia completa e íntegra de la base de datos a 'dest' (aunque el programa esté en uso)."""
        dest = Path(dest)
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.unlink(missing_ok=True)   # VACUUM INTO exige que el archivo destino no exista
        with self.conn:
            self.conn.execute("VACUUM INTO ?", (str(dest),))

    # ---------- reportes ----------
    def count(self, table: str) -> int:
        return self.conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]

    def orders_by_status(self) -> list[tuple[str, int, float]]:
        rows = self.conn.execute(
            "SELECT estado, COUNT(*), COALESCE(SUM(costo), 0) FROM ordenes GROUP BY estado"
        )
        return [(r[0], r[1], r[2]) for r in rows]
