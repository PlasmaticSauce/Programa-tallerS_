"""Impresión y PDF de órdenes de trabajo.

TODO EL DISEÑO DEL DOCUMENTO ESTÁ EN build_html(). Cuando tengas el diseño final
del PDF, solo hay que reescribir esa función: imprimir y descargar PDF ya
funcionan y usan el mismo documento.
"""
from datetime import date
from html import escape

from PySide6.QtCore import QMarginsF, QUrl
from PySide6.QtGui import QPageLayout, QPageSize, QTextDocument
from PySide6.QtPrintSupport import QPrintDialog, QPrinter

from app.schema import format_folio


def _fecha(value: str) -> str:
    try:
        return date.fromisoformat(value).strftime("%d/%m/%Y")
    except ValueError:
        return value


def build_html(orders: list[dict], db) -> str:
    """DISEÑO PROVISIONAL: una orden por página. Se reemplazará por el diseño final."""
    parts = ['<html><body style="font-family: Arial; font-size: 11pt; color: #000000;">']
    for i, o in enumerate(orders):
        page_break = ' style="page-break-before: always;"' if i else ""
        parts.append(f"<h1{page_break}>Orden de trabajo {format_folio(o['id'])}</h1>")
        parts.append('<table width="100%" border="1" cellspacing="0" cellpadding="6">')
        vehiculo = o["vehiculo"]
        if o["anio"]:
            vehiculo += f" ({o['anio']})"
        saldo = o["costo"] - o["anticipo"]
        for label, value in (
            ("Fecha de ingreso", _fecha(o["fecha"])),
            ("Cliente", o.get("cliente_id__label") or "—"),
            ("Vehículo", vehiculo),
            ("Placas", o["placas"] or "—"),
            ("Kilometraje", f"{o['kilometraje']:,} km" if o["kilometraje"] else "—"),
            ("Mecánico asignado", o["mecanico"] or "—"),
            ("Fecha prometida de entrega", _fecha(o["fecha_promesa"]) if o["fecha_promesa"] else "—"),
            ("Estado", o["estado"]),
            ("Costo total", f"${o['costo']:,.2f}"),
            ("Anticipo pagado", f"${o['anticipo']:,.2f}"),
            ("Saldo pendiente", f"${saldo:,.2f}"),
        ):
            parts.append(
                f'<tr><td width="28%"><b>{label}</b></td><td>{escape(str(value))}</td></tr>'
            )
        parts.append("</table>")
        if o["notas"]:
            parts.append("<h3>Notas internas</h3>")
            parts.append(f"<p>{escape(o['notas']).replace(chr(10), '<br>')}</p>")
        parts.append("<h3>Servicio a realizar</h3>")
        parts.append(f"<p>{escape(o['servicio']).replace(chr(10), '<br>')}</p>")

        images = db.images_for(o["id"])
        if images:
            parts.append("<h3>Imágenes</h3><p>")
            for image in images:
                url = QUrl.fromLocalFile(image["path"]).toString()
                parts.append(f'<img src="{url}" width="200"> &nbsp;')
            parts.append("</p>")
    parts.append("</body></html>")
    return "".join(parts)


def _document(orders: list[dict], db) -> QTextDocument:
    doc = QTextDocument()
    doc.setHtml(build_html(orders, db))
    return doc


def _printer() -> QPrinter:
    printer = QPrinter(QPrinter.PrinterMode.HighResolution)
    layout = QPageLayout(
        QPageSize(QPageSize.PageSizeId.Letter),
        QPageLayout.Orientation.Portrait,
        QMarginsF(15, 15, 15, 15),
        QPageLayout.Unit.Millimeter,
    )
    printer.setPageLayout(layout)
    return printer


def export_pdf(orders: list[dict], db, path: str) -> None:
    printer = _printer()
    printer.setOutputFormat(QPrinter.OutputFormat.PdfFormat)
    printer.setOutputFileName(path)
    _document(orders, db).print_(printer)


def print_orders(orders: list[dict], db, parent) -> bool:
    """Abre el cuadro de impresión de Windows. Devuelve False si se cancela."""
    printer = _printer()
    dialog = QPrintDialog(printer, parent)
    if not dialog.exec():   # 0 = cancelado
        return False
    _document(orders, db).print_(printer)
    return True
