"""WhatsApp: mensajes preconfigurados, teléfonos y enlaces (solo lógica, sin ventanas).

Cómo funciona ahora: el programa abre el chat del cliente en WhatsApp (app de
escritorio o WhatsApp Web, con la cuenta de WhatsApp Business ya iniciada) con
el mensaje escrito. La persona solo presiona Enviar.
"""
import re
from datetime import date
from urllib.parse import quote

from app.schema import format_folio

DEFAULT_COUNTRY = "52"            # México; se cambia en "Mensajes…"
DEFAULT_SHOP = "Taller Mecánico"

# Textos iniciales. Se pueden editar desde el botón "Mensajes…" de la pestaña Órdenes.
DEFAULT_MESSAGES = {
    "orden": (
        "Hola {cliente}, le compartimos su orden de trabajo {folio} de {taller}. "
        "Vehículo: {vehiculo} ({placas}). Cualquier duda con gusto le atendemos."
    ),
    "Recibido": (
        "Hola {cliente}, recibimos su {vehiculo} (placas {placas}) en {taller}. "
        "Su orden es la {folio}. Le mantendremos informado."
    ),
    "En diagnóstico": (
        "Hola {cliente}, su {vehiculo} ({folio}) ya está en diagnóstico. "
        "En cuanto tengamos el resultado le avisamos."
    ),
    "En reparación": (
        "Hola {cliente}, ya comenzamos la reparación de su {vehiculo} ({folio}). "
        "Le avisaremos cuando esté listo."
    ),
    "Esperando refacción": (
        "Hola {cliente}, su {vehiculo} ({folio}) está en espera de una pieza. "
        "Le avisamos en cuanto llegue para continuar con la reparación."
    ),
    "Terminado": (
        "Hola {cliente}, su {vehiculo} ({folio}) ya está listo. "
        "Puede pasar a recogerlo a {taller}."
    ),
    "Entregado": (
        "Hola {cliente}, gracias por confiar en {taller}. "
        "Su {vehiculo} ({folio}) fue entregado. ¡Que tenga excelente día!"
    ),
}
FALLBACK_STATUS_MESSAGE = "Hola {cliente}, el estatus de su {vehiculo} ({folio}) es: {estado}."

# Datos que se pueden usar dentro de un mensaje, escribiéndolos entre llaves.
PLACEHOLDERS = {
    "{cliente}": "nombre del cliente",
    "{folio}": "folio de la orden",
    "{vehiculo}": "vehículo",
    "{placas}": "placas",
    "{estado}": "estatus actual",
    "{costo}": "costo total",
    "{anticipo}": "anticipo pagado",
    "{saldo}": "saldo pendiente",
    "{mecanico}": "mecánico asignado",
    "{fecha_entrega}": "fecha prometida de entrega",
    "{fecha}": "fecha de ingreso",
    "{taller}": "nombre del taller",
}


def get_message(db, key: str) -> str:
    default = DEFAULT_MESSAGES.get(key, FALLBACK_STATUS_MESSAGE)
    return db.get_setting(f"msg_{key}", default)


def save_message(db, key: str, text: str) -> None:
    db.set_setting(f"msg_{key}", text)


def render_message(template: str, values: dict) -> str:
    """Cambia {cliente}, {folio}... por sus datos. Lo desconocido se deja tal cual."""
    return re.sub(r"\{(\w+)\}", lambda m: str(values.get(m.group(1), m.group(0))), template)


def _fmt_date(value: str) -> str:
    try:
        return date.fromisoformat(value).strftime("%d/%m/%Y")
    except ValueError:
        return value


def build_values(record: dict, client: dict | None, db) -> dict:
    saldo = record["costo"] - record["anticipo"]
    return {
        "cliente": client["nombre"] if client else "cliente",
        "folio": format_folio(record["id"]),
        "vehiculo": record["vehiculo"],
        "placas": record["placas"] or "sin placas",
        "estado": record["estado"],
        "costo": f"${record['costo']:,.2f}",
        "anticipo": f"${record['anticipo']:,.2f}",
        "saldo": f"${saldo:,.2f}",
        "mecanico": record["mecanico"] or "nuestro equipo",
        "fecha_entrega": _fmt_date(record["fecha_promesa"]) if record["fecha_promesa"] else "por confirmar",
        "fecha": _fmt_date(record["fecha"]),
        "taller": db.get_setting("wa_taller", DEFAULT_SHOP),
    }


def normalize_phone(raw: str, country: str = DEFAULT_COUNTRY) -> str:
    """Deja solo el número internacional (sin +, espacios ni guiones). '' si no es válido.
    Ejemplos (país 52): '55 1234 5678' -> '525512345678'."""
    digits = re.sub(r"\D", "", raw or "")
    if digits.startswith("00"):
        digits = digits[2:]
    if len(digits) == 10:                       # número local sin código de país
        digits = country + digits
    if country == "52" and digits.startswith("521") and len(digits) == 13:
        digits = "52" + digits[3:]              # formato antiguo de celulares mexicanos
    return digits if 11 <= len(digits) <= 15 else ""


def chat_url(phone: str, text: str) -> str:
    return f"https://wa.me/{phone}?text={quote(text, safe='')}"
