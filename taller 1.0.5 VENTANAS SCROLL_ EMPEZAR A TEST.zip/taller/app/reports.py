"""Pestaña de Reportes: Resumen, reportes de Órdenes / Clientes / Almacén con filtros,
exportación a Excel e historial de reportes guardados."""
from datetime import datetime
from pathlib import Path

from PySide6.QtCore import QDate, Qt, QUrl
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import (
    QAbstractItemView, QCheckBox, QComboBox, QDateEdit, QFileDialog, QFrame,
    QGridLayout, QHBoxLayout, QHeaderView, QLabel, QLineEdit, QMessageBox,
    QPushButton, QTableWidget, QTableWidgetItem, QTabWidget, QVBoxLayout, QWidget,
)

from app import excel, reports_pdf
from app.reports_data import Filters, ReportData, build_report, format_cell
from app.schema import ESTADO_COBRADO, ESTADOS, ESTADOS_CERRADOS

MAX_COL_WIDTH = 320


def _make_table(headers: list[str], selectable: bool = False) -> QTableWidget:
    table = QTableWidget(0, len(headers))
    table.setHorizontalHeaderLabels(headers)
    table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
    table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
    table.setSelectionMode(
        QAbstractItemView.SelectionMode.SingleSelection if selectable
        else QAbstractItemView.SelectionMode.NoSelection
    )
    table.setAlternatingRowColors(True)
    table.setShowGrid(False)
    table.verticalHeader().setVisible(False)
    table.horizontalHeader().setStretchLastSection(True)
    table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
    return table


def _fit_columns(table: QTableWidget) -> None:
    table.resizeColumnsToContents()
    for c in range(table.columnCount()):
        if table.columnWidth(c) > MAX_COL_WIDTH:
            table.setColumnWidth(c, MAX_COL_WIDTH)


# =====================================================================
#  Sub-pestaña: Resumen (lo que ya existía)
# =====================================================================
class SummaryPage(QWidget):
    def __init__(self, db):
        super().__init__()
        self.db = db

        self.cards = {}
        cards_row = QHBoxLayout()
        cards_row.setSpacing(14)
        for key, label in (
            ("abiertas", "Órdenes abiertas"),
            ("clientes", "Clientes"),
            ("proveedores", "Proveedores"),
            ("ingresos", "Ingresos (órdenes entregadas)"),
        ):
            card, value_label = self._make_card(label)
            self.cards[key] = value_label
            cards_row.addWidget(card)

        title = QLabel("Órdenes por estado")
        title.setObjectName("sectionTitle")
        self.table = _make_table(["Estado", "Órdenes", "Monto"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 16, 0, 0)
        layout.setSpacing(16)
        layout.addLayout(cards_row)
        layout.addWidget(title)
        layout.addWidget(self.table)
        self.refresh()

    @staticmethod
    def _make_card(label: str):
        card = QFrame()
        card.setObjectName("card")
        value = QLabel("0")
        value.setObjectName("cardValue")
        caption = QLabel(label)
        caption.setObjectName("cardLabel")
        box = QVBoxLayout(card)
        box.setContentsMargins(18, 14, 18, 14)
        box.addWidget(caption)
        box.addWidget(value)
        return card, value

    def refresh(self) -> None:
        by_status = {estado: (n, total) for estado, n, total in self.db.orders_by_status()}
        abiertas = sum(n for estado, (n, _) in by_status.items() if estado not in ESTADOS_CERRADOS)
        ingresos = by_status.get(ESTADO_COBRADO, (0, 0.0))[1]

        self.cards["abiertas"].setText(str(abiertas))
        self.cards["clientes"].setText(str(self.db.count("clientes")))
        self.cards["proveedores"].setText(str(self.db.count("proveedores")))
        self.cards["ingresos"].setText(f"${ingresos:,.2f}")

        self.table.setRowCount(len(ESTADOS))
        for r, estado in enumerate(ESTADOS):
            n, total = by_status.get(estado, (0, 0.0))
            for c, text in enumerate((estado, str(n), f"${total:,.2f}")):
                self.table.setItem(r, c, QTableWidgetItem(text))


# =====================================================================
#  Sub-pestañas: reportes de Órdenes / Clientes / Almacén
# =====================================================================
class ReportPage(QWidget):
    FILE_PREFIX = {"ordenes": "Ordenes", "clientes": "Clientes", "almacen": "Almacen"}

    def __init__(self, db, kind: str, on_saved):
        super().__init__()
        self.db, self.kind, self.on_saved = db, kind, on_saved
        self.current: ReportData | None = None

        # ---------- panel de filtros ----------
        today = QDate.currentDate()
        self.use_dates = QCheckBox("Filtrar por fecha")
        self.date_from = QDateEdit(QDate(today.year(), today.month(), 1))
        self.date_to = QDateEdit(today)
        for edit in (self.date_from, self.date_to):
            edit.setCalendarPopup(True)
            edit.setDisplayFormat("dd/MM/yyyy")
            edit.setEnabled(False)
        self.use_dates.toggled.connect(self._update_enabled)

        grid = QGridLayout()
        grid.setHorizontalSpacing(12)
        grid.setVerticalSpacing(10)
        grid.addWidget(self.use_dates, 0, 0)
        grid.addWidget(QLabel("Desde"), 0, 1, Qt.AlignmentFlag.AlignRight)
        grid.addWidget(self.date_from, 0, 2)
        grid.addWidget(QLabel("Hasta"), 0, 3, Qt.AlignmentFlag.AlignRight)
        grid.addWidget(self.date_to, 0, 4)

        self.folios = self.plates = self.text = None
        self.estado = self.contenido = self.tipo = None
        if kind in ("ordenes", "clientes"):
            self.folios = QLineEdit()
            self.folios.setPlaceholderText("Ej. SJ-001, SJ-005")
            self.plates = QLineEdit()
            self.plates.setPlaceholderText("Ej. ABC-123, XYZ-987")
            self.estado = QComboBox()
            self.estado.addItem("Todos", "")
            for estado in ESTADOS:
                self.estado.addItem(estado, estado)
            grid.addWidget(QLabel("Orden(es)"), 1, 0)
            grid.addWidget(self.folios, 1, 1, 1, 2)
            grid.addWidget(QLabel("Placas"), 1, 3, Qt.AlignmentFlag.AlignRight)
            grid.addWidget(self.plates, 1, 4)
            grid.addWidget(QLabel("Estado"), 2, 0)
            grid.addWidget(self.estado, 2, 1, 1, 2)
            if kind == "clientes":
                self.text = QLineEdit()
                self.text.setPlaceholderText("Nombre, teléfono o correo")
                grid.addWidget(QLabel("Cliente"), 2, 3, Qt.AlignmentFlag.AlignRight)
                grid.addWidget(self.text, 2, 4)
        else:  # almacén
            self.contenido = QComboBox()
            self.contenido.addItem("Existencias actuales", "existencias")
            self.contenido.addItem("Movimientos (altas y bajas)", "movimientos")
            self.contenido.currentIndexChanged.connect(self._update_enabled)
            self.tipo = QComboBox()
            self.tipo.addItem("Altas y bajas", "")
            self.tipo.addItem("Solo altas", "alta")
            self.tipo.addItem("Solo bajas", "baja")
            self.text = QLineEdit()
            self.text.setPlaceholderText("Nombre, código o categoría")
            grid.addWidget(QLabel("Contenido"), 1, 0)
            grid.addWidget(self.contenido, 1, 1, 1, 2)
            grid.addWidget(QLabel("Tipo"), 1, 3, Qt.AlignmentFlag.AlignRight)
            grid.addWidget(self.tipo, 1, 4)
            grid.addWidget(QLabel("Producto"), 2, 0)
            grid.addWidget(self.text, 2, 1, 1, 4)
        grid.setColumnStretch(2, 1)
        grid.setColumnStretch(4, 1)

        card = QFrame()
        card.setObjectName("card")
        card_layout = QVBoxLayout(card)
        card_layout.setContentsMargins(16, 14, 16, 14)
        card_layout.addLayout(grid)

        # ---------- botones ----------
        generate_btn = QPushButton("Generar reporte")
        generate_btn.setObjectName("primary")
        generate_btn.clicked.connect(lambda: self._generate())
        clear_btn = QPushButton("Limpiar filtros")
        clear_btn.clicked.connect(self._clear_filters)
        self.export_btn = QPushButton("Exportar a Excel")
        self.export_btn.clicked.connect(self.export_excel)
        self.export_pdf_btn = QPushButton("Exportar a PDF")
        self.export_pdf_btn.clicked.connect(self.export_pdf)
        self.summary = QLabel("")
        self.summary.setObjectName("cardLabel")

        buttons = QHBoxLayout()
        buttons.setSpacing(10)
        buttons.addWidget(generate_btn)
        buttons.addWidget(clear_btn)
        buttons.addWidget(self.summary, 1)
        buttons.addWidget(self.export_btn)
        buttons.addWidget(self.export_pdf_btn)

        self.table = _make_table([""])

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 16, 0, 0)
        layout.setSpacing(12)
        layout.addWidget(card)
        layout.addLayout(buttons)
        layout.addWidget(self.table, 1)

        self._update_enabled()
        self._generate(silent=True)

    # ----- filtros -----
    def _update_enabled(self) -> None:
        is_movements = self.kind != "almacen" or self.contenido.currentData() == "movimientos"
        self.use_dates.setEnabled(is_movements)   # las existencias son "de hoy": sin fechas
        dates_on = is_movements and self.use_dates.isChecked()
        self.date_from.setEnabled(dates_on)
        self.date_to.setEnabled(dates_on)
        if self.tipo is not None:
            self.tipo.setEnabled(is_movements)

    def _clear_filters(self) -> None:
        self.use_dates.setChecked(False)
        for widget in (self.folios, self.plates, self.text):
            if widget is not None:
                widget.clear()
        for combo in (self.estado, self.tipo, self.contenido):
            if combo is not None:
                combo.setCurrentIndex(0)
        self._generate()

    def _collect(self, silent: bool) -> Filters | None:
        f = Filters()
        f.use_dates = self.use_dates.isEnabled() and self.use_dates.isChecked()
        f.date_from = self.date_from.date().toPython()
        f.date_to = self.date_to.date().toPython()
        if f.use_dates and f.date_from > f.date_to:
            if not silent:
                QMessageBox.warning(self, "Fechas", "La fecha «Desde» no puede ser posterior a «Hasta».")
            return None
        if self.folios is not None:
            f.folios, f.plates = self.folios.text(), self.plates.text()
            f.estado = self.estado.currentData()
        if self.text is not None:
            f.text = self.text.text()
        if self.contenido is not None:
            f.contenido, f.tipo = self.contenido.currentData(), self.tipo.currentData()
        return f

    # ----- generar y mostrar -----
    def refresh(self) -> None:
        self._generate(silent=True)

    def _generate(self, silent: bool = False) -> ReportData | None:
        filters = self._collect(silent)
        if filters is None:
            return None
        report = build_report(self.db, self.kind, filters)
        self.current = report
        self._show(report)
        return report

    def _show(self, report: ReportData) -> None:
        self.table.setColumnCount(len(report.headers))
        self.table.setHorizontalHeaderLabels(report.headers)
        self.table.setRowCount(len(report.rows))
        right = Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter
        for r, row in enumerate(report.rows):
            for c, (value, fmt) in enumerate(zip(row, report.formats)):
                item = QTableWidgetItem(format_cell(value, fmt))
                if fmt in ("money", "int"):
                    item.setTextAlignment(right)
                self.table.setItem(r, c, item)
        _fit_columns(self.table)

        parts = [f"{len(report.rows)} fila(s)"]
        for c in report.sum_columns:
            total = sum(row[c] for row in report.rows)
            parts.append(f"{report.headers[c]}: {format_cell(total, report.formats[c])}")
        self.summary.setText("   ·   ".join(parts))
        self.export_btn.setEnabled(bool(report.rows))
        self.export_pdf_btn.setEnabled(bool(report.rows))

    # ----- exportar -----
    def _export(self, extension: str, filter_text: str, writer) -> None:
        report = self._generate()
        if report is None:
            return
        if not report.rows:
            QMessageBox.information(self, "Sin datos", "No hay datos para exportar con esos filtros.")
            return

        folder = self.db.data_dir / "reportes"
        folder.mkdir(parents=True, exist_ok=True)
        default = folder / f"{self.FILE_PREFIX[self.kind]}_{datetime.now():%Y-%m-%d_%H%M}.{extension}"
        path, _ = QFileDialog.getSaveFileName(self, f"Guardar reporte en {extension.upper()}", str(default), filter_text)
        if not path:
            return
        if not path.lower().endswith(f".{extension}"):
            path += f".{extension}"
        try:
            writer(report, path)
        except ImportError:
            QMessageBox.warning(
                self, "Falta openpyxl",
                "Para exportar a Excel instala la librería con:\n\npython -m pip install openpyxl",
            )
            return
        except OSError as error:   # p. ej. el archivo está abierto en otro programa
            QMessageBox.warning(self, "No se pudo guardar", f"{error}\n\nSi el archivo está abierto, ciérralo.")
            return

        self.db.add_saved_report(report.title, report.filters_text, len(report.rows), path)
        self.on_saved()
        answer = QMessageBox.question(self, "Reporte guardado", f"Se guardó en:\n{path}\n\n¿Abrirlo ahora?")
        if answer == QMessageBox.StandardButton.Yes:
            QDesktopServices.openUrl(QUrl.fromLocalFile(path))

    def export_excel(self) -> None:
        self._export("xlsx", "Excel (*.xlsx)", excel.export_report)

    def export_pdf(self) -> None:
        self._export("pdf", "PDF (*.pdf)", reports_pdf.export_report_pdf)


# =====================================================================
#  Sub-pestaña: Reportes guardados
# =====================================================================
class SavedReportsPage(QWidget):
    def __init__(self, db):
        super().__init__()
        self.db = db
        self.rows: list[dict] = []

        self.table = _make_table(["Fecha", "Reporte", "Filtros", "Filas", "Archivo"], selectable=True)
        self.table.itemSelectionChanged.connect(self._update_buttons)
        self.table.doubleClicked.connect(lambda _index: self.open_file())

        self.open_btn = QPushButton("Abrir en Excel")
        self.open_btn.setObjectName("primary")
        self.open_btn.clicked.connect(self.open_file)
        self.folder_btn = QPushButton("Mostrar carpeta")
        self.folder_btn.clicked.connect(self.open_folder)
        self.remove_btn = QPushButton("Quitar de la lista")
        self.remove_btn.setToolTip("Solo quita el registro; el archivo Excel no se borra")
        self.remove_btn.clicked.connect(self.remove_record)

        buttons = QHBoxLayout()
        buttons.setSpacing(10)
        buttons.addWidget(self.open_btn)
        buttons.addWidget(self.folder_btn)
        buttons.addWidget(self.remove_btn)
        buttons.addStretch()

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 16, 0, 0)
        layout.setSpacing(12)
        layout.addLayout(buttons)
        layout.addWidget(self.table, 1)
        self.refresh()

    def refresh(self) -> None:
        self.rows = self.db.list_saved_reports()
        self.table.setRowCount(len(self.rows))
        for r, rec in enumerate(self.rows):
            created = datetime.fromisoformat(rec["creado"]).strftime("%d/%m/%Y %H:%M")
            values = [created, rec["titulo"], rec["filtros"], str(rec["filas"]), rec["archivo"]]
            for c, text in enumerate(values):
                self.table.setItem(r, c, QTableWidgetItem(text))
        _fit_columns(self.table)
        self._update_buttons()

    def _selected(self) -> dict | None:
        row = self.table.currentRow()
        return self.rows[row] if 0 <= row < len(self.rows) else None

    def _update_buttons(self) -> None:
        enabled = self._selected() is not None
        for button in (self.open_btn, self.folder_btn, self.remove_btn):
            button.setEnabled(enabled)

    def open_file(self) -> None:
        rec = self._selected()
        if rec is None:
            return
        if not Path(rec["archivo"]).exists():
            QMessageBox.warning(self, "Archivo no encontrado",
                                f"Ya no existe el archivo:\n{rec['archivo']}\n\n(¿Lo moviste o borraste?)")
            return
        QDesktopServices.openUrl(QUrl.fromLocalFile(rec["archivo"]))

    def open_folder(self) -> None:
        rec = self._selected()
        if rec is not None:
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(Path(rec["archivo"]).parent)))

    def remove_record(self) -> None:
        rec = self._selected()
        if rec is None:
            return
        answer = QMessageBox.question(
            self, "Quitar de la lista", "¿Quitar este reporte de la lista?\nEl archivo Excel no se borra."
        )
        if answer == QMessageBox.StandardButton.Yes:
            self.db.delete_saved_report(rec["id"])
            self.refresh()


# =====================================================================
#  Pestaña principal de Reportes
# =====================================================================
class ReportsTab(QWidget):
    def __init__(self, db):
        super().__init__()
        self.saved = SavedReportsPage(db)
        self.pages = [
            (SummaryPage(db), "Resumen"),
            (ReportPage(db, "ordenes", self.saved.refresh), "Órdenes"),
            (ReportPage(db, "clientes", self.saved.refresh), "Clientes"),
            (ReportPage(db, "almacen", self.saved.refresh), "Almacén"),
            (self.saved, "Reportes guardados"),
        ]
        self.subtabs = QTabWidget()
        self.subtabs.setObjectName("subtabs")
        for page, title in self.pages:
            self.subtabs.addTab(page, title)
        self.subtabs.currentChanged.connect(lambda index: self.pages[index][0].refresh())

        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 12, 20, 20)
        layout.addWidget(self.subtabs)

    def refresh(self) -> None:
        self.pages[self.subtabs.currentIndex()][0].refresh()
