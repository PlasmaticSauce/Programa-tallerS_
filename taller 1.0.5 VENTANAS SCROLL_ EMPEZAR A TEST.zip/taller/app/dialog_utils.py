"""Utilidades para que los formularios (Orden, Producto, Alta/Baja, Mensajes...)
siempre quepan en la pantalla: se pueden mover, agrandar, achicar y maximizar,
y si el contenido no cabe aparece una barra de desplazamiento en vez de recortarse."""
from PySide6.QtCore import Qt
from PySide6.QtGui import QGuiApplication
from PySide6.QtWidgets import QDialog, QFrame, QScrollArea, QWidget

MARGIN = 60          # aire respecto al borde de la pantalla
MIN_WIDTH = 380
MIN_HEIGHT = 320


def fit_to_screen(dialog: QDialog, width: int, height: int) -> None:
    """Hace que la ventana se pueda mover, maximizar y redimensionar, y que su
    tamaño inicial nunca sea más grande que la pantalla del usuario."""
    dialog.setWindowFlag(Qt.WindowType.WindowMaximizeButtonHint, True)
    dialog.setWindowFlag(Qt.WindowType.WindowMinimizeButtonHint, True)
    dialog.setMinimumSize(MIN_WIDTH, MIN_HEIGHT)

    screen = QGuiApplication.primaryScreen()
    if screen is not None:
        available = screen.availableGeometry()
        width = min(width, max(available.width() - MARGIN, MIN_WIDTH))
        height = min(height, max(available.height() - MARGIN, MIN_HEIGHT))
        dialog.resize(width, height)
        dialog.move(available.center().x() - width // 2, available.center().y() - height // 2)
    else:
        dialog.resize(width, height)


def scrollable(inner: QWidget) -> QScrollArea:
    """Envuelve un widget en un área con scroll, para cuando el contenido no
    quepa en pantallas chicas. Se ve igual que sin scroll cuando sí cabe."""
    scroll = QScrollArea()
    scroll.setWidgetResizable(True)
    scroll.setFrameShape(QFrame.Shape.NoFrame)
    scroll.setWidget(inner)
    return scroll
