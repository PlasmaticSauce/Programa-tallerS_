"""Datos de los reportes (sin ventanas): aplica los filtros y arma las tablas
que se ven en pantalla y se exportan a Excel."""
import re
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import date, datetime

from app.schema import CLIENTES, ORDENES, PRODUCTOS, format_folio, normalize_plate


@dataclass
class Filters:
    use_dates: bool = False
    date_from: date | None = None
    date_to: date | None = None
    folios: str = ""          # "SJ-001, SJ-005"
    plates: str = ""          # "ABC-123, XYZ 9"
    estado: str = ""          # "" = todos
    text: str = ""            # cliente (reporte de clientes) o producto (almacén)
    contenido: str = "existencias"   # almacén: "existencias" | "movimientos"
    tipo: str = ""            # almacén / movimientos: "" | "alta" | "baja"


@dataclass
class ReportData:
    kind: str                 # "ordenes" | "clientes" | "almacen"
    title: str
    sheet_name: str
    headers: list[str]
    rows: list[list]
    formats: list[str]        # por columna: text | date | datetime | money | int
    sum_columns: list[int] = field(default_factory=list)
    filters_text: str = ""


# ---------------------------------------------------------------- utilidades
def _to_date(iso: str) -> date | None:
    try:
        return date.fromisoformat(iso[:10])
    except ValueError:
        return None


def _in_range(day: date | None, f: Filters) -> bool:
    if not f.use_dates:
        return True
    return day is not None and f.date_from <= day <= f.date_to


def _folio_ids(text: str) -> set[int]:
    """'SJ-001, 5' -> {1, 5}"""
    ids = set()
    for token in re.split(r"[,;\s]+", text.strip()):
        digits = re.sub(r"\D", "", token)
        if digits:
            ids.add(int(digits))
    return ids


def _plate_tokens(text: str) -> list[str]:
    tokens = (normalize_plate(t) for t in re.split(r"[,;]+", text))
    return [t for t in tokens if t]


def format_cell(value, fmt: str) -> str:
    """Cómo se ve cada valor en la tabla de la pantalla."""
    if value is None or value == "":
        return ""
    if fmt == "date":
        return value.strftime("%d/%m/%Y")
    if fmt == "datetime":
        return value.strftime("%d/%m/%Y %H:%M")
    if fmt == "money":
        return f"${value:,.2f}"
    return str(value)


def _describe(f: Filters, extra: list[str] | None = None) -> str:
    parts = list(extra or [])
    if f.use_dates:
        parts.append(f"fechas del {f.date_from:%d/%m/%Y} al {f.date_to:%d/%m/%Y}")
    if f.folios.strip():
        parts.append(f"folios: {f.folios.strip()}")
    if f.plates.strip():
        parts.append(f"placas: {f.plates.strip()}")
    if f.estado:
        parts.append(f"estado: {f.estado}")
    if f.text.strip():
        parts.append(f"búsqueda: {f.text.strip()}")
    return "; ".join(parts) or "sin filtros"


def _order_matcher(f: Filters):
    folio_ids, plates = _folio_ids(f.folios), _plate_tokens(f.plates)

    def matches(order: dict) -> bool:
        if not _in_range(_to_date(order["fecha"]), f):
            return False
        if folio_ids and order["id"] not in folio_ids:
            return False
        if plates:
            plate = normalize_plate(order["placas"])
            if not any(token in plate for token in plates):
                return False
        return not f.estado or order["estado"] == f.estado

    active = bool(f.use_dates or folio_ids or plates or f.estado)
    return matches, active


# ---------------------------------------------------------------- reportes
def orders_report(db, f: Filters) -> ReportData:
    matches, _ = _order_matcher(f)
    orders = sorted((o for o in db.all(ORDENES) if matches(o)), key=lambda o: o["id"])
    rows = [
        [format_folio(o["id"]), _to_date(o["fecha"]), o["placas"], o.get("cliente_id__label") or "",
         o["vehiculo"], o["mecanico"], o["estado"], o["costo"], o["anticipo"], o["costo"] - o["anticipo"]]
        for o in orders
    ]
    return ReportData(
        kind="ordenes", title="Reporte de órdenes de trabajo", sheet_name="Órdenes",
        headers=["Folio", "Fecha de ingreso", "Placas", "Cliente", "Vehículo", "Mecánico",
                 "Estado", "Costo", "Anticipo", "Saldo pendiente"],
        rows=rows,
        formats=["text", "date", "text", "text", "text", "text", "text", "money", "money", "money"],
        sum_columns=[7, 8, 9], filters_text=_describe(f),
    )


def clients_report(db, f: Filters) -> ReportData:
    matches, order_filters_active = _order_matcher(f)
    by_client = defaultdict(list)
    for order in db.all(ORDENES):
        if matches(order):
            by_client[order["cliente_id"]].append(order)

    text = f.text.strip().lower()
    rows = []
    for client in sorted(db.all(CLIENTES), key=lambda c: c["nombre"].lower()):
        if text and text not in f"{client['nombre']} {client['telefono']} {client['correo']}".lower():
            continue
        orders = by_client.get(client["id"], [])
        if order_filters_active and not orders:
            continue   # con filtros de órdenes solo aparecen los clientes que las tienen
        days = [d for d in (_to_date(o["fecha"]) for o in orders) if d]
        # Placas sin repetir ("ABC-123" y "ABC123" son la misma)
        plates = sorted({normalize_plate(o["placas"]): o["placas"] for o in orders if o["placas"]}.values())
        rows.append([
            client["nombre"], client["telefono"], client["correo"], client["direccion"],
            len(orders), max(days) if days else None, ", ".join(plates),
            sum(o["costo"] for o in orders), sum(o["costo"] - o["anticipo"] for o in orders),
        ])
    return ReportData(
        kind="clientes", title="Reporte de clientes", sheet_name="Clientes",
        headers=["Cliente", "Teléfono", "Correo", "Dirección", "Órdenes", "Última visita",
                 "Placas", "Monto de órdenes", "Saldo pendiente"],
        rows=rows,
        formats=["text", "text", "text", "text", "int", "date", "text", "money", "money"],
        sum_columns=[4, 7, 8], filters_text=_describe(f),
    )


def warehouse_report(db, f: Filters) -> ReportData:
    text = f.text.strip().lower()

    if f.contenido == "movimientos":
        rows = []
        for m in db.movements():
            moment = datetime.fromisoformat(m["fecha"])
            if not _in_range(moment.date(), f):
                continue
            if f.tipo and m["tipo"] != f.tipo:
                continue
            if text and text not in f"{m['codigo']} {m['nombre']} {m['categoria']}".lower():
                continue
            rows.append([moment, "Alta" if m["tipo"] == "alta" else "Baja", m["codigo"],
                         m["nombre"], m["categoria"], m["cantidad"], m["proveedor"] or "", m["motivo"]])
        extra = ["movimientos"] + ([f"tipo: {'altas' if f.tipo == 'alta' else 'bajas'}"] if f.tipo else [])
        return ReportData(
            kind="almacen", title="Reporte de almacén — movimientos", sheet_name="Almacén - Movimientos",
            headers=["Fecha y hora", "Tipo", "Código", "Producto", "Categoría", "Cantidad", "Proveedor", "Motivo"],
            rows=rows, formats=["datetime", "text", "text", "text", "text", "int", "text", "text"],
            filters_text=_describe(f, extra),
        )

    products = sorted(db.all(PRODUCTOS), key=lambda p: p["nombre"].lower())
    rows = [
        [p["codigo"], p["nombre"], p["categoria"], p["existencia"]]
        for p in products
        if not text or text in f"{p['codigo']} {p['nombre']} {p['categoria']}".lower()
    ]
    # En existencias las fechas no aplican (es una foto del inventario de hoy).
    no_dates = Filters(text=f.text)
    return ReportData(
        kind="almacen", title="Reporte de almacén — existencias", sheet_name="Almacén - Existencias",
        headers=["Código", "Producto", "Categoría", "Existencia"],
        rows=rows, formats=["text", "text", "text", "int"], sum_columns=[3],
        filters_text=_describe(no_dates, ["existencias al " + date.today().strftime("%d/%m/%Y")]),
    )


def build_report(db, kind: str, f: Filters) -> ReportData:
    return {"ordenes": orders_report, "clientes": clients_report, "almacen": warehouse_report}[kind](db, f)
