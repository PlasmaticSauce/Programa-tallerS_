"""Pestaña de Almacén: catálogo de productos con imagen, Alta (entrada) con
pistola de escáner o manual, Baja (salida) y buscador con autocompletado."""
from pathlib import Path

from PySide6.QtCore import QSize, Qt, QStringListModel, QTimer
from PySide6.QtGui import QIcon, QPixmap
from PySide6.QtWidgets import (
    QAbstractItemView, QApplication, QComboBox, QCompleter, QDialog, QHBoxLayout,
    QHeaderView, QLabel, QLineEdit, QMessageBox, QPushButton, QSpinBox,
    QTableWidget, QTableWidgetItem, QVBoxLayout,
)

from app.crud import CrudTab, RecordDialog
from app.dialog_utils import fit_to_screen
from app.schema import PRODUCTOS, PROVEEDORES
from app.style import COLORS

THUMB = 48   # tamaño de las miniaturas en las tablas

# Motivos que se pueden elegir al registrar el movimiento
MOTIVOS = {
    "alta": ["Compra / entrada de mercancía", "Devolución de cliente", "Ajuste de inventario"],
    "baja": ["Uso en orden de trabajo", "Merma / dañado", "Devolución a proveedor", "Ajuste de inventario"],
}

_ICON_CACHE: dict[str, QIcon | None] = {}


def product_icon(db, filename: str) -> QIcon | None:
    """Miniatura del producto (se guarda en memoria para no releer el archivo)."""
    if not filename:
        return None
    path = db.product_image_path(filename)
    if path not in _ICON_CACHE:
        pixmap = QPixmap(path)
        _ICON_CACHE[path] = (
            None if pixmap.isNull() else QIcon(pixmap.scaled(
                THUMB, THUMB, Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation))
        )
    return _ICON_CACHE[path]


def _store_image(db, values: dict, old: str = "") -> dict:
    """Si se eligió una imagen nueva la copia a la carpeta del programa; si se quitó, la borra."""
    values = dict(values)
    new = values.get("imagen", "")
    if new and Path(new).is_absolute():          # imagen nueva elegida desde el disco
        values["imagen"] = db.store_product_image(new)
        if old:
            db.delete_product_image(old)
    elif not new and old:                        # la quitaron
        db.delete_product_image(old)
    return values


# =====================================================================
#  Formulario de producto
# =====================================================================
class ProductDialog(RecordDialog):
    def __init__(self, parent, db, record: dict | None = None, code: str = "", lock_stock: bool = False):
        super().__init__(parent, db, PRODUCTOS, record)
        fit_to_screen(self, 620, 660)
        stock = self.inputs["existencia"]
        label = self.form.labelForField(stock)
        if record:
            label.setText("Existencia actual")
            stock.setEnabled(False)
            stock.setToolTip("La existencia cambia con los botones Alta y Baja")
        else:
            label.setText("Existencia inicial")
            if lock_stock:
                stock.setEnabled(False)
                stock.setToolTip("La cantidad se registra en la lista de Alta")
            if code:
                self.inputs["codigo"].setText(code)
        self.inputs["codigo"].setFocus()   # así se puede escanear el código directamente


def create_product(parent, db, code: str = "", lock_stock: bool = False) -> dict | None:
    """Abre el formulario de producto nuevo. Devuelve el producto creado (o None si se canceló)."""
    dialog = ProductDialog(parent, db, None, code=code, lock_stock=lock_stock)
    if not dialog.exec():
        return None
    values = _store_image(db, dialog.result_values)
    initial = values["existencia"]
    values["existencia"] = 0
    try:
        product_id = db.insert(PRODUCTOS, values)
    except ValueError as error:
        QMessageBox.warning(parent, "No se pudo guardar", str(error))
        return None
    if initial > 0:
        db.apply_movements([(product_id, initial)], "alta", "Existencia inicial")
    return db.get_record(PRODUCTOS, product_id)


# =====================================================================
#  Ventana de Alta / Baja de existencias
# =====================================================================
class StockDialog(QDialog):
    def __init__(self, parent, db, mode: str):
        super().__init__(parent)
        self.db, self.mode = db, mode
        title = "Alta de mercancía (entrada)" if mode == "alta" else "Baja de mercancía (salida)"
        self.setWindowTitle(title)
        fit_to_screen(self, 900, 680)

        heading = QLabel(title)
        heading.setObjectName("sectionTitle")

        # --- escáner ---
        self.scan_input = QLineEdit()
        self.scan_input.setPlaceholderText("Haz clic aquí y escanea el código con la pistola…")
        self.scan_input.returnPressed.connect(self._on_scan)   # la pistola termina con Enter

        # --- manual (con autocompletado) ---
        self.manual_input = QLineEdit()
        self.manual_input.setPlaceholderText("Manual: escribe el nombre o el código y elige de la lista…")
        entries = [f"{p['codigo']} — {p['nombre']}" for p in db.all(PRODUCTOS)]
        self._completer_model = QStringListModel(sorted(entries))
        completer = QCompleter(self._completer_model, self)
        completer.setCaseSensitivity(Qt.CaseSensitivity.CaseInsensitive)
        completer.setFilterMode(Qt.MatchFlag.MatchContains)
        self.manual_input.setCompleter(completer)
        add_btn = QPushButton("Agregar")
        add_btn.setAutoDefault(False)
        add_btn.clicked.connect(self._on_manual_add)

        self.status = QLabel("")
        self.status.setWordWrap(True)

        # --- lista de la sesión ---
        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(["Imagen", "Código", "Producto", "Existencia actual", "Cantidad"])
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.table.setAlternatingRowColors(True)
        self.table.setShowGrid(False)
        self.table.verticalHeader().setVisible(False)
        self.table.verticalHeader().setDefaultSectionSize(THUMB + 12)
        self.table.setIconSize(QSize(THUMB, THUMB))
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)

        # --- pie ---
        self.reason = QComboBox()
        self.reason.addItems(MOTIVOS[mode])
        self.provider = None
        if mode == "alta":
            self.provider = QComboBox()
            self.provider.addItem("Sin especificar", None)
            for pid, name in db.ref_options("proveedores"):
                self.provider.addItem(name, pid)
        remove_btn = QPushButton("Quitar seleccionado")
        remove_btn.setAutoDefault(False)
        remove_btn.clicked.connect(self._remove_selected)
        cancel_btn = QPushButton("Cancelar")
        cancel_btn.setAutoDefault(False)
        cancel_btn.clicked.connect(self.reject)
        confirm_btn = QPushButton("Confirmar alta" if mode == "alta" else "Confirmar baja")
        confirm_btn.setObjectName("primary")
        confirm_btn.setAutoDefault(False)
        confirm_btn.clicked.connect(self._confirm)

        scan_row = QHBoxLayout()
        scan_row.addWidget(QLabel("Escáner"))
        scan_row.addWidget(self.scan_input, 1)
        manual_row = QHBoxLayout()
        manual_row.addWidget(QLabel("Manual"))
        manual_row.addWidget(self.manual_input, 1)
        manual_row.addWidget(add_btn)

        bottom = QHBoxLayout()
        bottom.setSpacing(10)
        bottom.addWidget(QLabel("Motivo"))
        bottom.addWidget(self.reason)
        if self.provider is not None:
            bottom.addWidget(QLabel("Proveedor"))
            bottom.addWidget(self.provider)
        bottom.addWidget(remove_btn)
        if mode == "alta":
            new_btn = QPushButton("Registrar producto nuevo…")
            new_btn.setAutoDefault(False)
            new_btn.clicked.connect(self._register_new)
            bottom.addWidget(new_btn)
        bottom.addStretch()
        bottom.addWidget(cancel_btn)
        bottom.addWidget(confirm_btn)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 20)
        layout.setSpacing(12)
        layout.addWidget(heading)
        layout.addLayout(scan_row)
        layout.addLayout(manual_row)
        layout.addWidget(self.status)
        layout.addWidget(self.table, 1)
        layout.addLayout(bottom)

        QTimer.singleShot(0, self.scan_input.setFocus)   # listo para escanear al abrir

    # ----- mensajes -----
    def _say(self, text: str, error: bool = False) -> None:
        self.status.setStyleSheet(f"color: {COLORS['ERROR']};" if error else "")
        self.status.setText(text)
        if error:
            QApplication.beep()

    # ----- lista de productos de la sesión -----
    def _row_of(self, product_id: int) -> int | None:
        for r in range(self.table.rowCount()):
            if self.table.item(r, 1).data(Qt.ItemDataRole.UserRole) == product_id:
                return r
        return None

    def _add_product(self, product: dict) -> None:
        """Agrega el producto a la lista, o suma 1 si ya estaba (así funciona el escaneo repetido)."""
        name = product["nombre"]
        row = self._row_of(product["id"])
        if row is not None:
            spin = self.table.cellWidget(row, 4)
            if spin.value() >= spin.maximum():
                self._say(f"Solo hay {spin.maximum()} en existencia de «{name}».", error=True)
                return
            spin.setValue(spin.value() + 1)
        else:
            if self.mode == "baja" and product["existencia"] <= 0:
                self._say(f"No hay existencia de «{name}».", error=True)
                return
            row = self.table.rowCount()
            self.table.insertRow(row)
            icon_item = QTableWidgetItem()
            icon = product_icon(self.db, product["imagen"])
            if icon:
                icon_item.setIcon(icon)
            code_item = QTableWidgetItem(product["codigo"])
            code_item.setData(Qt.ItemDataRole.UserRole, product["id"])
            self.table.setItem(row, 0, icon_item)
            self.table.setItem(row, 1, code_item)
            self.table.setItem(row, 2, QTableWidgetItem(name))
            self.table.setItem(row, 3, QTableWidgetItem(str(product["existencia"])))
            spin = QSpinBox()
            spin.setMinimum(1)
            spin.setMaximum(product["existencia"] if self.mode == "baja" else 1_000_000)
            spin.setValue(1)
            self.table.setCellWidget(row, 4, spin)
            self.table.resizeColumnToContents(0)
            self.table.resizeColumnToContents(1)
            self.table.resizeColumnToContents(3)
        self._say(f"✓ {name} — cantidad: {spin.value()}")

    def _remove_selected(self) -> None:
        row = self.table.currentRow()
        if row >= 0:
            self.table.removeRow(row)

    # ----- escáner -----
    def _on_scan(self) -> None:
        code = self.scan_input.text().strip()
        self.scan_input.clear()
        self.scan_input.setFocus()          # se queda listo para el siguiente escaneo
        if not code:
            return
        product = self.db.find_product_by_code(code)
        if product is not None:
            self._add_product(product)
        elif self.mode == "alta":
            self._offer_register(code)
        else:
            self._say(f"El código {code} no está registrado en el almacén.", error=True)

    def _offer_register(self, code: str) -> None:
        answer = QMessageBox.question(
            self, "Producto nuevo", f"El código {code} no está registrado.\n¿Registrar el producto ahora?"
        )
        if answer == QMessageBox.StandardButton.Yes:
            product = create_product(self, self.db, code, lock_stock=True)
            if product:
                self._add_product(product)
        self.scan_input.setFocus()

    def _register_new(self) -> None:
        product = create_product(self, self.db, "", lock_stock=True)
        if product:
            self._add_product(product)

    # ----- manual -----
    def _on_manual_add(self) -> None:
        text = self.manual_input.text().strip()
        if not text:
            return
        product = self.db.find_product_by_code(text.split(" — ")[0])
        if product is None:
            matches = self.db.find_products_by_name(text)
            exact = [m for m in matches if m["nombre"].lower() == text.lower()]
            matches = exact or matches
            if len(matches) > 1:
                self._say(f"Hay {len(matches)} productos parecidos; elige uno de la lista de sugerencias.", error=True)
                return
            if not matches:
                extra = " Usa «Registrar producto nuevo…» si es la primera vez." if self.mode == "alta" else ""
                self._say(f"No se encontró «{text}».{extra}", error=True)
                return
            product = matches[0]
        self.manual_input.clear()
        self._add_product(product)

    # ----- confirmar -----
    def _confirm(self) -> None:
        items = [
            (self.table.item(r, 1).data(Qt.ItemDataRole.UserRole), self.table.cellWidget(r, 4).value())
            for r in range(self.table.rowCount())
        ]
        if not items:
            self._say("Agrega al menos un producto a la lista.", error=True)
            return
        proveedor_id = self.provider.currentData() if self.provider is not None else None
        try:
            self.db.apply_movements(items, self.mode, self.reason.currentText(), proveedor_id)
        except ValueError as error:
            QMessageBox.warning(self, "No se pudo registrar", str(error))
            return
        self.accept()


# =====================================================================
#  Pestaña de almacén
# =====================================================================
class WarehouseTab(CrudTab):
    def __init__(self, db):
        super().__init__(db, PRODUCTOS)

    def _build_extra_toolbar(self):
        # Botones Alta / Baja junto al buscador; "Nuevo producto" pasa a botón normal.
        self.add_btn.setText("Nuevo producto")
        self.add_btn.setObjectName("")
        self.alta_btn = QPushButton("＋  Alta")
        self.alta_btn.setObjectName("primary")
        self.alta_btn.setToolTip("Entrada de mercancía: escáner o manual")
        self.alta_btn.clicked.connect(lambda: self.open_stock("alta"))
        self.baja_btn = QPushButton("－  Baja")
        self.baja_btn.setToolTip("Salida de mercancía")
        self.baja_btn.clicked.connect(lambda: self.open_stock("baja"))
        self.top_row.insertWidget(1, self.alta_btn)
        self.top_row.insertWidget(2, self.baja_btn)

        # Autocompletado del buscador: nombres, códigos y categorías
        self._suggestions = QStringListModel()
        completer = QCompleter(self._suggestions, self)
        completer.setCaseSensitivity(Qt.CaseSensitivity.CaseInsensitive)
        completer.setFilterMode(Qt.MatchFlag.MatchContains)
        self.search.setCompleter(completer)
        self.search.setPlaceholderText("Buscar producto por nombre, código o categoría…")

        # Miniaturas más grandes en la tabla
        self.table.setIconSize(QSize(THUMB, THUMB))
        self.table.verticalHeader().setDefaultSectionSize(THUMB + 12)
        return None

    # ----- columna de imagen -----
    def _leading_headers(self) -> list[str]:
        return ["Imagen"]

    def _leading_items(self, record: dict) -> list[QTableWidgetItem]:
        item = QTableWidgetItem()
        icon = product_icon(self.db, record["imagen"])
        if icon:
            item.setIcon(icon)
        else:
            item.setText("—")
        return [item]

    def _prepare(self, rows: list[dict]) -> None:
        words = {w for p in rows for w in (p["nombre"], p["codigo"], p["categoria"]) if w}
        self._suggestions.setStringList(sorted(words))

    # ----- acciones -----
    def open_stock(self, mode: str) -> None:
        StockDialog(self, self.db, mode).exec()
        self.refresh()

    def add_record(self) -> None:
        if create_product(self, self.db) is not None:
            self.refresh()

    def _make_dialog(self, record: dict | None) -> RecordDialog:
        return ProductDialog(self, self.db, record)

    def _save_edit(self, record: dict, dialog: RecordDialog) -> None:
        values = _store_image(self.db, dialog.result_values, record["imagen"])
        values["existencia"] = record["existencia"]   # la existencia solo cambia con Alta y Baja
        self.db.update(PRODUCTOS, record["id"], values)
