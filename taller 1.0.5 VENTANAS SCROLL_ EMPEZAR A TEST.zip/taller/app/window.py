"""Ventana principal con las 4 pestañas."""
from datetime import datetime

from PySide6.QtCore import QUrl
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import QFileDialog, QMainWindow, QMessageBox, QTabWidget

from app.crud import CrudTab
from app.orders import OrdersTab
from app.reports import ReportsTab
from app.schema import CLIENTES, ORDENES, PRODUCTOS, PROVEEDORES
from app.warehouse import WarehouseTab


class MainWindow(QMainWindow):
    def __init__(self, db):
        super().__init__()
        self.setWindowTitle("Taller Mecánico")
        self.resize(1200, 720)

        # Para agregar una pestaña nueva: crear su página y añadirla a esta lista.
        pages = [
            (OrdersTab(db), ORDENES.title),
            (CrudTab(db, CLIENTES), CLIENTES.title),
            (CrudTab(db, PROVEEDORES), PROVEEDORES.title),
            (WarehouseTab(db), PRODUCTOS.title),
            (ReportsTab(db), "Reportes"),
        ]
        self.tabs = QTabWidget()
        for page, title in pages:
            self.tabs.addTab(page, title)
        self.tabs.currentChanged.connect(self._on_tab_changed)
        self.setCentralWidget(self.tabs)

        self.db = db
        menu = self.menuBar().addMenu("Archivo")
        menu.addAction("Respaldar datos…", self.backup_data)
        menu.addAction("Abrir carpeta de datos", self.open_data_folder)

    def _on_tab_changed(self, index: int) -> None:
        # Al cambiar de pestaña se recargan los datos (por si se editó algo en otra).
        self.tabs.widget(index).refresh()

    def backup_data(self) -> None:
        default = self.db.data_dir / "respaldos" / f"respaldo_{datetime.now():%Y-%m-%d_%H%M}.db"
        path, _ = QFileDialog.getSaveFileName(self, "Guardar respaldo", str(default), "Base de datos (*.db)")
        if not path:
            return
        try:
            self.db.backup(path)
        except OSError as error:
            QMessageBox.warning(self, "No se pudo respaldar", str(error))
            return
        QMessageBox.information(self, "Respaldo listo", f"Se guardó en:\n{path}")

    def open_data_folder(self) -> None:
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(self.db.data_dir)))
