"""Pestaña de Órdenes de trabajo: folio SJ-001, selección para imprimir/PDF,
imágenes adjuntas, autorrelleno por placas y contador de visitas."""
from collections import Counter
from datetime import date
from pathlib import Path

from PySide6.QtCore import QMimeData, QSize, Qt, QUrl
from PySide6.QtGui import QDesktopServices, QIcon, QPixmap
from PySide6.QtWidgets import (
    QApplication, QCheckBox, QFileDialog, QHBoxLayout, QLabel, QListView, QListWidget,
    QListWidgetItem, QMessageBox, QPushButton, QTableWidgetItem, QVBoxLayout, QWidget,
)

from app import pdf, whatsapp
from app.crud import CrudTab, RecordDialog
from app.dialog_utils import fit_to_screen
from app.schema import CLIENTES, ESTADOS, ORDENES, format_folio, normalize_plate
from app.whatsapp_dialog import MessagesDialog

THUMB = 96
IMAGE_FILTER = "Imágenes (*.png *.jpg *.jpeg *.bmp *.gif *.webp)"


# =====================================================================
#  Formulario de orden (extiende el formulario genérico)
# =====================================================================
class OrderDialog(RecordDialog):
    def __init__(self, parent, db, record: dict | None = None):
        super().__init__(parent, db, ORDENES, record)
        fit_to_screen(self, 700, 780)   # más ancho: lleva la lista de imágenes
        self.new_image_paths: list[str] = []     # imágenes por copiar al guardar
        self.removed_image_ids: list[int] = []   # imágenes por borrar al guardar
        self._autofill_note = ""

        # Folio arriba del formulario
        folio = format_folio(record["id"] if record else db.next_order_id())
        title = QLabel(f"Folio: {folio}")
        title.setObjectName("sectionTitle")
        self.layout_main.insertWidget(0, title)

        # Aviso de placas, justo debajo del campo Placas
        self.plate_info = QLabel("")
        self.plate_info.setObjectName("cardLabel")
        self.plate_info.setWordWrap(True)
        plate_row = [f.key for f in ORDENES.fields].index("placas")
        self.form.insertRow(plate_row + 1, "", self.plate_info)

        # Sección de imágenes (dentro del área con scroll, junto con el resto del formulario)
        self.content_layout.addWidget(self._build_images_box())
        if record:
            for image in db.images_for(record["id"]):
                self._add_thumb(image["path"], ("old", image["id"], image["path"]), "Foto")

        plate_input = self.inputs["placas"]
        plate_input.textChanged.connect(self._on_plate_typed)
        plate_input.editingFinished.connect(self._autofill)
        self._update_plate_info()

    def _validate_and_accept(self) -> None:
        values = self._values()
        if values["anticipo"] > values["costo"]:
            QMessageBox.warning(
                self, "Anticipo inválido",
                "El anticipo no puede ser mayor al costo total.",
            )
            return
        super()._validate_and_accept()

    # ----- placas: aviso de visitas y autorrelleno -----
    def _previous_orders(self, plate: str) -> list[dict]:
        own_id = self.record["id"] if self.record else None
        return [o for o in self.db.orders_by_plate(plate) if o["id"] != own_id]

    def _on_plate_typed(self) -> None:
        self._autofill_note = ""
        self._update_plate_info()

    def _update_plate_info(self) -> None:
        plate = self.inputs["placas"].text()
        if not normalize_plate(plate):
            self.plate_info.setText("")
            return
        previous = self._previous_orders(plate)
        if previous:
            text = (
                f"Vehículo registrado · otras visitas con estas placas: {len(previous)} "
                f"· última orden {format_folio(previous[0]['id'])}"
            )
        else:
            text = "Sin otras visitas con estas placas (primera vez en el taller)"
        self.plate_info.setText(f"{text}. {self._autofill_note}".strip())

    def _autofill(self) -> None:
        """Al terminar de escribir las placas, rellena cliente y vehículo de la última visita."""
        if self.record is not None:   # solo en órdenes nuevas; al editar no se pisan datos
            return
        previous = self.db.orders_by_plate(self.inputs["placas"].text())
        if not previous:
            return
        last = previous[0]
        client_combo = self.inputs["cliente_id"]
        client_combo.setCurrentIndex(max(client_combo.findData(last["cliente_id"]), 0))
        self.inputs["vehiculo"].setText(last["vehiculo"])
        self._autofill_note = "Datos rellenados de la última visita; puedes cambiarlos."
        self._update_plate_info()

    def _values(self) -> dict:
        values = super()._values()
        values["placas"] = values["placas"].upper()
        return values

    # ----- imágenes -----
    def _build_images_box(self) -> QWidget:
        box = QWidget()
        lay = QVBoxLayout(box)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(8)
        lay.addWidget(QLabel("Imágenes adjuntas (doble clic para abrir)"))

        self.image_list = QListWidget()
        self.image_list.setViewMode(QListView.ViewMode.IconMode)
        self.image_list.setIconSize(QSize(THUMB, THUMB))
        self.image_list.setResizeMode(QListView.ResizeMode.Adjust)
        self.image_list.setMovement(QListView.Movement.Static)
        self.image_list.setFixedHeight(140)
        self.image_list.itemDoubleClicked.connect(self._open_image)
        lay.addWidget(self.image_list)

        attach = QPushButton("Adjuntar imágenes…")
        attach.setAutoDefault(False)
        attach.clicked.connect(self._attach)
        remove = QPushButton("Quitar seleccionada")
        remove.setAutoDefault(False)
        remove.clicked.connect(self._remove_selected)
        row = QHBoxLayout()
        row.addWidget(attach)
        row.addWidget(remove)
        row.addStretch()
        lay.addLayout(row)
        return box

    def _add_thumb(self, path: str, data: tuple, label: str) -> bool:
        pixmap = QPixmap(path)
        if pixmap.isNull():
            QMessageBox.warning(self, "Imagen no válida", f"No se pudo abrir:\n{path}")
            return False
        thumb = pixmap.scaled(
            THUMB, THUMB, Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation,
        )
        item = QListWidgetItem(QIcon(thumb), label)
        item.setData(Qt.ItemDataRole.UserRole, data)
        self.image_list.addItem(item)
        return True

    def _attach(self) -> None:
        paths, _ = QFileDialog.getOpenFileNames(self, "Adjuntar imágenes", "", IMAGE_FILTER)
        for path in paths:
            if self._add_thumb(path, ("new", path, path), Path(path).name[:16]):
                self.new_image_paths.append(path)

    def _remove_selected(self) -> None:
        for item in self.image_list.selectedItems():
            kind, ref, _path = item.data(Qt.ItemDataRole.UserRole)
            if kind == "new":
                self.new_image_paths.remove(ref)
            else:
                self.removed_image_ids.append(ref)
            self.image_list.takeItem(self.image_list.row(item))

    def _open_image(self, item: QListWidgetItem) -> None:
        path = item.data(Qt.ItemDataRole.UserRole)[2]
        QDesktopServices.openUrl(QUrl.fromLocalFile(path))


# =====================================================================
#  Pestaña de órdenes
# =====================================================================
class OrdersTab(CrudTab):
    check_column = 0   # la columna 0 tiene las casillas ✓

    def __init__(self, db):
        super().__init__(db, ORDENES)

    # ----- columnas extra -----
    def _leading_headers(self) -> list[str]:
        return ["", "Folio"]

    def _trailing_headers(self) -> list[str]:
        return ["Visitas", "Fotos", "Saldo"]

    def _leading_items(self, record: dict) -> list[QTableWidgetItem]:
        check = QTableWidgetItem()
        check.setFlags(
            Qt.ItemFlag.ItemIsUserCheckable | Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable
        )
        was_checked = record["id"] in self._checked_ids
        check.setCheckState(Qt.CheckState.Checked if was_checked else Qt.CheckState.Unchecked)
        return [check, QTableWidgetItem(format_folio(record["id"]))]

    def _trailing_items(self, record: dict) -> list[QTableWidgetItem]:
        visits = self._visits.get(record["id"], 0)
        photos = self._photos.get(record["id"], 0)
        saldo = record["costo"] - record["anticipo"]
        saldo_item = QTableWidgetItem(f"${saldo:,.2f}")
        if saldo > 0:
            saldo_item.setForeground(Qt.GlobalColor.red)
        return [QTableWidgetItem(str(visits) if visits else "—"),
                QTableWidgetItem(str(photos) if photos else "—"), saldo_item]

    def _prepare(self, rows: list[dict]) -> None:
        # Visitas = cuántas órdenes hay con las mismas placas (contando la propia).
        counts = Counter(normalize_plate(r["placas"]) for r in rows if normalize_plate(r["placas"]))
        self._visits = {r["id"]: counts.get(normalize_plate(r["placas"]), 0) for r in rows}
        self._photos = self.db.image_counts()

    # ----- barra de selección / imprimir / PDF -----
    def _build_extra_toolbar(self):
        self._checked_ids: set[int] = set()
        self._visits: dict[int, int] = {}
        self._photos: dict[int, int] = {}

        self.select_all = QCheckBox("Seleccionar todas")
        self.select_all.clicked.connect(self._toggle_all)
        self.selected_label = QLabel("0 seleccionadas")
        self.selected_label.setObjectName("cardLabel")
        self.print_btn = QPushButton("Imprimir")
        self.print_btn.clicked.connect(self.print_selected)
        self.pdf_btn = QPushButton("Descargar PDF")
        self.pdf_btn.clicked.connect(self.save_pdf)
        self.table.itemChanged.connect(self._on_item_changed)

        row = QHBoxLayout()
        row.setSpacing(12)
        row.addWidget(self.select_all)
        row.addWidget(self.selected_label)
        row.addStretch()
        row.addWidget(self.print_btn)
        row.addWidget(self.pdf_btn)

        # Segunda fila: WhatsApp (actúa sobre la orden que esté resaltada en la tabla)
        self.wa_send_btn = QPushButton("Enviar orden (PDF)")
        self.wa_send_btn.setToolTip("Genera el PDF de la orden y abre el chat del cliente en WhatsApp")
        self.wa_send_btn.clicked.connect(self.send_order_whatsapp)
        self._whatsapp_buttons = [self.wa_send_btn]
        wa_row = QHBoxLayout()
        wa_row.setSpacing(8)
        wa_label = QLabel("WhatsApp:")
        wa_label.setObjectName("cardLabel")
        wa_row.addWidget(wa_label)
        wa_row.addWidget(self.wa_send_btn)
        for estado in ESTADOS:
            button = QPushButton(estado)
            button.setObjectName("status")
            button.setToolTip("Cambia el estatus de la orden seleccionada y avisa al cliente")
            button.clicked.connect(lambda _checked=False, e=estado: self.send_status_whatsapp(e))
            self._whatsapp_buttons.append(button)
            wa_row.addWidget(button)
        wa_row.addStretch()
        messages_btn = QPushButton("Mensajes…")
        messages_btn.setToolTip("Editar los mensajes preconfigurados de WhatsApp")
        messages_btn.clicked.connect(self.edit_messages)
        wa_row.addWidget(messages_btn)

        box = QVBoxLayout()
        box.setSpacing(10)
        box.addLayout(row)
        box.addLayout(wa_row)
        return box

    def _update_buttons(self) -> None:
        super()._update_buttons()
        enabled = self._selected() is not None
        for button in self._whatsapp_buttons:   # WhatsApp necesita una orden resaltada
            button.setEnabled(enabled)

    def refresh(self) -> None:
        # Recuerda qué órdenes estaban marcadas, para no perder la selección al recargar.
        self._checked_ids = {r["id"] for r in self._checked(include_hidden=True)}
        super().refresh()

    def _checked(self, include_hidden: bool = False) -> list[dict]:
        records = []
        for r in range(self.table.rowCount()):
            item = self.table.item(r, 0)
            if item is None or item.checkState() != Qt.CheckState.Checked:
                continue
            if not include_hidden and self.table.isRowHidden(r):
                continue
            records.append(self.rows[r])
        return records

    def _on_item_changed(self, item: QTableWidgetItem) -> None:
        if item.column() == 0:
            self._update_selection_ui()

    def _after_filter(self) -> None:
        self._update_selection_ui()

    def _toggle_all(self, checked: bool) -> None:
        state = Qt.CheckState.Checked if checked else Qt.CheckState.Unchecked
        self.table.blockSignals(True)
        for r in range(self.table.rowCount()):
            if not self.table.isRowHidden(r):
                self.table.item(r, 0).setCheckState(state)
        self.table.blockSignals(False)
        self._update_selection_ui()

    def _update_selection_ui(self) -> None:
        checked = len(self._checked())
        visible = sum(1 for r in range(self.table.rowCount()) if not self.table.isRowHidden(r))
        self.selected_label.setText(f"{checked} seleccionada(s)")
        self.print_btn.setEnabled(checked > 0)
        self.pdf_btn.setEnabled(checked > 0)
        self.select_all.blockSignals(True)
        self.select_all.setChecked(visible > 0 and checked == visible)
        self.select_all.blockSignals(False)

    # ----- imprimir y PDF -----
    def _checked_sorted(self) -> list[dict]:
        return sorted(self._checked(), key=lambda r: r["id"])

    def print_selected(self) -> None:
        records = self._checked_sorted()
        if records:
            pdf.print_orders(records, self.db, self)

    def save_pdf(self) -> None:
        records = self._checked_sorted()
        if not records:
            return
        if len(records) == 1:
            default = format_folio(records[0]["id"])
        else:
            default = f"Ordenes_{date.today():%Y-%m-%d}"
        path, _ = QFileDialog.getSaveFileName(self, "Guardar PDF", f"{default}.pdf", "PDF (*.pdf)")
        if not path:
            return
        if not path.lower().endswith(".pdf"):
            path += ".pdf"
        try:
            pdf.export_pdf(records, self.db, path)
        except OSError as error:
            QMessageBox.warning(self, "No se pudo guardar", str(error))
            return
        QMessageBox.information(self, "PDF guardado", f"Se guardó en:\n{path}")

    # ----- formulario e imágenes al guardar -----
    def _make_dialog(self, record: dict | None) -> RecordDialog:
        return OrderDialog(self, self.db, record)

    def _save_new(self, dialog: OrderDialog) -> None:
        order_id = self.db.insert(ORDENES, dialog.result_values)
        self._apply_images(order_id, dialog)

    def _save_edit(self, record: dict, dialog: OrderDialog) -> None:
        self.db.update(ORDENES, record["id"], dialog.result_values)
        self._apply_images(record["id"], dialog)

    def _apply_images(self, order_id: int, dialog: OrderDialog) -> None:
        for image_id in dialog.removed_image_ids:
            self.db.remove_image(image_id)
        for path in dialog.new_image_paths:
            self.db.add_image(order_id, path)

    # ----- WhatsApp -----
    def _whatsapp_target(self, record: dict):
        """Devuelve (cliente, teléfono) o None si el cliente no tiene un teléfono válido."""
        client = self.db.get_record(CLIENTES, record["cliente_id"])
        country = self.db.get_setting("wa_pais", whatsapp.DEFAULT_COUNTRY)
        phone = whatsapp.normalize_phone(client["telefono"], country) if client else ""
        if not phone:
            name = client["nombre"] if client else "El cliente"
            QMessageBox.warning(
                self, "Falta el teléfono",
                f"{name} no tiene un teléfono válido para WhatsApp.\n"
                "Edítalo en la pestaña Clientes (ejemplo: 55 1234 5678).",
            )
            return None
        return client, phone

    def _open_whatsapp(self, phone: str, text: str) -> None:
        QDesktopServices.openUrl(QUrl(whatsapp.chat_url(phone, text)))

    def _reselect(self, order_id: int) -> None:
        for r, record in enumerate(self.rows):
            if record["id"] == order_id:
                self.table.selectRow(r)
                return

    def send_order_whatsapp(self) -> None:
        record = self._selected()
        if record is None:
            return
        target = self._whatsapp_target(record)
        if target is None:
            return
        client, phone = target

        folder = self.db.data_dir / "pdf_enviados"
        folder.mkdir(parents=True, exist_ok=True)
        path = folder / f"{format_folio(record['id'])}.pdf"
        try:
            pdf.export_pdf([record], self.db, str(path))
        except OSError as error:
            QMessageBox.warning(self, "No se pudo crear el PDF", str(error))
            return

        # Deja el PDF "copiado" para pegarlo en el chat con Ctrl+V.
        mime = QMimeData()
        mime.setUrls([QUrl.fromLocalFile(str(path))])
        QApplication.clipboard().setMimeData(mime)

        template = whatsapp.get_message(self.db, "orden")
        text = whatsapp.render_message(template, whatsapp.build_values(record, client, self.db))
        QMessageBox.information(
            self, "Enviar orden por WhatsApp",
            "Se abrirá WhatsApp con el mensaje listo.\n\n"
            f"El PDF ({path.name}) ya está copiado: en el chat presiona Ctrl+V para "
            "adjuntarlo y luego Enviar.\n\n"
            f"Si no se adjunta, búscalo en:\n{path}",
        )
        self._open_whatsapp(phone, text)

    def send_status_whatsapp(self, estado: str) -> None:
        record = self._selected()
        if record is None:
            return
        target = self._whatsapp_target(record)
        if target is None:
            return
        client, phone = target
        answer = QMessageBox.question(
            self, "Enviar estatus",
            f"¿Marcar la orden {format_folio(record['id'])} como «{estado}» "
            f"y avisar a {client['nombre']} por WhatsApp?",
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        self.db.set_order_status(record["id"], estado)
        updated = {**record, "estado": estado}
        self.refresh()
        self._reselect(record["id"])
        template = whatsapp.get_message(self.db, estado)
        text = whatsapp.render_message(template, whatsapp.build_values(updated, client, self.db))
        self._open_whatsapp(phone, text)

    def edit_messages(self) -> None:
        MessagesDialog(self, self.db).exec()
