"""Exportar un reporte a Excel (.xlsx) con el estilo del programa."""
from datetime import datetime

from app.reports_data import ReportData, format_cell

NUMBER_FORMATS = {"date": "DD/MM/YYYY", "datetime": "DD/MM/YYYY HH:MM", "money": "$#,##0.00", "int": "0"}
FONT = "Arial"
RED = "A8232A"          # mismo rojo mate del programa


def export_report(report: ReportData, path: str) -> None:
    # openpyxl se importa aquí para que el programa abra aunque aún no esté instalado.
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    from openpyxl.utils import get_column_letter
    from openpyxl.worksheet.properties import PageSetupProperties

    wb = Workbook()
    ws = wb.active
    ws.title = report.sheet_name[:31]
    n_cols = len(report.headers)
    header_row = 5
    first, last = header_row + 1, header_row + len(report.rows)

    # --- encabezado del documento ---
    ws["A1"] = report.title
    ws["A1"].font = Font(name=FONT, size=14, bold=True, color=RED)
    ws["A2"] = f"Filtros: {report.filters_text}"
    ws["A3"] = f"Generado: {datetime.now():%d/%m/%Y %H:%M}"
    for ref in ("A2", "A3"):
        ws[ref].font = Font(name=FONT, size=10, color="555555")

    # --- títulos de columnas ---
    for c, header in enumerate(report.headers, start=1):
        cell = ws.cell(header_row, c, header)
        cell.font = Font(name=FONT, bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor=RED)
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

    # --- filas ---
    widths = [len(h) for h in report.headers]
    for r, row in enumerate(report.rows, start=first):
        for c, (value, fmt) in enumerate(zip(row, report.formats), start=1):
            cell = ws.cell(r, c, value)
            cell.font = Font(name=FONT, size=10)
            if fmt in NUMBER_FORMATS:
                cell.number_format = NUMBER_FORMATS[fmt]
                cell.alignment = Alignment(horizontal="right", vertical="top")
            else:
                cell.alignment = Alignment(vertical="top", wrap_text=True)
            widths[c - 1] = max(widths[c - 1], len(format_cell(value, fmt)))

    # --- fila de totales (con fórmulas, para que se recalculen si se filtra en Excel) ---
    if report.rows and report.sum_columns:
        total_row = last + 1
        top = Border(top=Side(style="thin"))
        ws.cell(total_row, 1, "TOTAL").font = Font(name=FONT, bold=True)
        for c in report.sum_columns:
            letter = get_column_letter(c + 1)
            cell = ws.cell(total_row, c + 1, f"=SUBTOTAL(109,{letter}{first}:{letter}{last})")
            cell.font = Font(name=FONT, bold=True)
            cell.number_format = NUMBER_FORMATS[report.formats[c]]
            cell.alignment = Alignment(horizontal="right")
        for c in range(1, n_cols + 1):
            ws.cell(total_row, c).border = top

    # --- comodidades ---
    for c, width in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(c)].width = min(max(width + 3, 12), 48)
    if report.rows:
        ws.auto_filter.ref = f"A{header_row}:{get_column_letter(n_cols)}{last}"
    ws.freeze_panes = ws.cell(first, 1)
    ws.page_setup.orientation = "landscape"
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr = PageSetupProperties(fitToPage=True)

    wb.save(path)
