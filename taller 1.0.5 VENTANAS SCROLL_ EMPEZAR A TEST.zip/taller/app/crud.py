"""Pestaña reutilizable: tabla + buscador + botones Dar de alta / Editar / Eliminar.

Sirve para Clientes y Proveedores tal cual. La pestaña de Órdenes (orders.py)
hereda de aquí y agrega sus extras usando los métodos "gancho" marcados abajo.
"""
from pathlib import Path

from PySide6.QtCore import QDate, Qt
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import (
    QAbstractItemView, QComboBox, QDateEdit, QDialog, QDialogButtonBox,
    QDoubleSpinBox, QFileDialog, QFormLayout, QHBoxLayout, QHeaderView, QLabel,
    QLineEdit, QMessageBox, QPlainTextEdit, QPushButton, QSpinBox, QTableWidget,
    QTableWidgetItem, QVBoxLayout, QWidget,
)

from app.dialog_utils import fit_to_screen, scrollable
from app.schema import ENTITIES, Entity, Field

DB_DATE = "yyyy-MM-dd"       # como se guarda en la base de datos
SHOW_DATE = "dd/MM/yyyy"     # como lo ve el usuario
IMAGE_FILTER = "Imágenes (*.png *.jpg *.jpeg *.bmp *.gif *.webp)"


class ImagePicker(QWidget):
    """Elegir UNA imagen con vista previa.
    value() devuelve el nombre ya guardado, o la ruta completa si se eligió una nueva."""

    def __init__(self, db):
        super().__init__()
        self.db = db
        self._value = ""
        self.preview = QLabel("Sin imagen")
        self.preview.setObjectName("preview")
        self.preview.setFixedSize(120, 120)
        self.preview.setAlignment(Qt.AlignmentFlag.AlignCenter)
        choose = QPushButton("Elegir imagen…")
        choose.setAutoDefault(False)
        choose.clicked.connect(self._choose)
        clear = QPushButton("Quitar")
        clear.setAutoDefault(False)
        clear.clicked.connect(self._clear)
        buttons = QVBoxLayout()
        buttons.addWidget(choose)
        buttons.addWidget(clear)
        buttons.addStretch()
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self.preview)
        layout.addLayout(buttons)
        layout.addStretch()

    def value(self) -> str:
        return self._value

    def set_value(self, value: str) -> None:
        self._value = value
        self._refresh()

    def _choose(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Elegir imagen", "", IMAGE_FILTER)
        if path:
            self._value = path
            self._refresh()

    def _clear(self) -> None:
        self._value = ""
        self._refresh()

    def _refresh(self) -> None:
        if not self._value:
            self.preview.setPixmap(QPixmap())
            self.preview.setText("Sin imagen")
            return
        path = self._value if Path(self._value).is_absolute() else self.db.product_image_path(self._value)
        pixmap = QPixmap(path)
        if pixmap.isNull():
            self.preview.setText("No se pudo abrir")
            return
        self.preview.setPixmap(
            pixmap.scaled(116, 116, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
        )


# =====================================================================
#  Formulario (sirve para dar de alta y para editar)
# =====================================================================
class RecordDialog(QDialog):
    def __init__(self, parent, db, entity: Entity, record: dict | None = None):
        super().__init__(parent)
        self.db, self.entity, self.record = db, entity, record
        self.result_values: dict = {}
        verb = "Editar" if record else "Dar de alta"
        self.setWindowTitle(f"{verb} {entity.singular}")

        self.form = QFormLayout()
        self.form.setSpacing(12)
        self.inputs: dict[str, QWidget] = {}
        for f in entity.fields:
            widget = self._make_input(f)
            self.inputs[f.key] = widget
            self.form.addRow(f.label + (" *" if f.required else ""), widget)
        if record:
            self._load(record)

        # Todo lo que va dentro del área con scroll (el formulario, y lo que agreguen
        # las pestañas hijas con self.content_layout.addWidget(...) o addLayout(...)).
        content = QWidget()
        self.content_layout = QVBoxLayout(content)
        self.content_layout.setContentsMargins(0, 0, 0, 0)
        self.content_layout.setSpacing(16)
        self.content_layout.addLayout(self.form)

        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel
        )
        save = buttons.button(QDialogButtonBox.StandardButton.Save)
        cancel = buttons.button(QDialogButtonBox.StandardButton.Cancel)
        save.setText("Guardar")
        save.setObjectName("primary")
        cancel.setText("Cancelar")
        # Sin botón "por defecto": así presionar Enter en un campo no guarda por accidente.
        save.setAutoDefault(False)
        cancel.setAutoDefault(False)
        buttons.accepted.connect(self._validate_and_accept)
        buttons.rejected.connect(self.reject)

        # layout_main: [(lo que inserten las hijas arriba, ej. el folio,) contenido con
        # scroll, botones]. Los botones de Guardar/Cancelar siempre quedan visibles.
        self.layout_main = QVBoxLayout(self)
        self.layout_main.setContentsMargins(24, 20, 24, 20)
        self.layout_main.setSpacing(14)
        self.layout_main.addWidget(scrollable(content), 1)
        self.layout_main.addWidget(buttons)
        fit_to_screen(self, 620, 720)

    # ----- creación de cada tipo de campo -----
    def _make_input(self, f: Field) -> QWidget:
        if f.kind == "multiline":
            w = QPlainTextEdit()
            w.setFixedHeight(90)
            return w
        if f.kind == "number":
            w = QDoubleSpinBox()
            w.setRange(0, 99_999_999)
            w.setDecimals(2)
            w.setPrefix("$ ")
            w.setGroupSeparatorShown(True)
            return w
        if f.kind == "integer":
            w = QSpinBox()
            w.setRange(0, 1_000_000)
            return w
        if f.kind == "image":
            return ImagePicker(self.db)
        if f.kind == "date":
            w = QDateEdit(QDate.currentDate())
            w.setCalendarPopup(True)
            w.setDisplayFormat(SHOW_DATE)
            return w
        if f.kind == "choice":
            w = QComboBox()
            w.addItems(f.options)
            return w
        if f.kind == "ref":
            w = QComboBox()
            for record_id, label in self.db.ref_options(f.ref):
                w.addItem(label, record_id)
            return w
        return QLineEdit()

    # ----- llenar el formulario al editar -----
    def _load(self, record: dict) -> None:
        for f in self.entity.fields:
            w, value = self.inputs[f.key], record[f.key]
            if f.kind == "multiline":
                w.setPlainText(value)
            elif f.kind == "number":
                w.setValue(value)
            elif f.kind == "integer":
                w.setValue(int(value))
            elif f.kind == "image":
                w.set_value(value)
            elif f.kind == "date":
                date = QDate.fromString(value, DB_DATE)
                if date.isValid():
                    w.setDate(date)
            elif f.kind == "choice":
                w.setCurrentText(value)
            elif f.kind == "ref":
                w.setCurrentIndex(max(w.findData(value), 0))
            else:
                w.setText(value)

    # ----- leer el formulario -----
    def _values(self) -> dict:
        values = {}
        for f in self.entity.fields:
            w = self.inputs[f.key]
            if f.kind == "multiline":
                values[f.key] = w.toPlainText().strip()
            elif f.kind in ("number", "integer", "image"):
                values[f.key] = w.value()
            elif f.kind == "date":
                values[f.key] = w.date().toString(DB_DATE)
            elif f.kind == "choice":
                values[f.key] = w.currentText()
            elif f.kind == "ref":
                values[f.key] = w.currentData()
            else:
                values[f.key] = w.text().strip()
        return values

    def _validate_and_accept(self) -> None:
        values = self._values()
        for f in self.entity.fields:
            if not f.required or values[f.key] not in ("", None):
                continue
            if f.kind == "ref":
                msg = f"Primero da de alta al menos un registro en «{ENTITIES[f.ref].title}»."
            else:
                msg = f"El campo «{f.label}» es obligatorio."
            QMessageBox.warning(self, "Falta información", msg)
            return
        own_id = self.record["id"] if self.record else None
        for f in self.entity.fields:
            if f.unique and self.db.value_exists(self.entity, f.key, values[f.key], own_id):
                QMessageBox.warning(
                    self, "Dato repetido",
                    f"Ya existe otro registro con el mismo «{f.label}»: {values[f.key]}",
                )
                return
        self.result_values = values
        self.accept()


# =====================================================================
#  Pestaña con tabla
# =====================================================================
class CrudTab(QWidget):
    check_column: int | None = None   # columna de casillas ✓ (solo la usa Órdenes)

    def __init__(self, db, entity: Entity):
        super().__init__()
        self.db, self.entity = db, entity
        self.visible_fields = [f for f in entity.fields if f.in_table]
        self.rows: list[dict] = []

        # --- barra superior: buscador + botones ---
        self.search = QLineEdit()
        self.search.setPlaceholderText(f"Buscar en {entity.title.lower()}…")
        self.search.textChanged.connect(self._apply_filter)

        self.add_btn = QPushButton(f"＋  Dar de alta {entity.singular}")
        self.add_btn.setObjectName("primary")
        self.add_btn.clicked.connect(self.add_record)
        self.edit_btn = QPushButton("Editar")
        self.edit_btn.clicked.connect(self.edit_record)
        self.delete_btn = QPushButton("Eliminar")
        self.delete_btn.clicked.connect(self.delete_record)

        top = self.top_row = QHBoxLayout()   # las pestañas hijas pueden agregar botones aquí
        top.setSpacing(10)
        top.addWidget(self.search, 1)
        top.addWidget(self.add_btn)
        top.addWidget(self.edit_btn)
        top.addWidget(self.delete_btn)

        # --- tabla ---
        headers = (
            self._leading_headers()
            + [f.label for f in self.visible_fields]
            + self._trailing_headers()
        )
        self.table = QTableWidget(0, len(headers))
        self.table.setHorizontalHeaderLabels(headers)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.table.setAlternatingRowColors(True)
        self.table.setShowGrid(False)
        self.table.verticalHeader().setVisible(False)
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        self.table.itemSelectionChanged.connect(self._update_buttons)
        self.table.doubleClicked.connect(self._on_double_click)  # doble clic = editar

        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(14)
        layout.addLayout(top)
        extra = self._build_extra_toolbar()
        if extra is not None:
            layout.addLayout(extra)
        layout.addWidget(self.table)

        self.refresh()

    # ------------------------------------------------------------------
    #  GANCHOS: las pestañas hijas (Órdenes) los reemplazan para personalizarse
    # ------------------------------------------------------------------
    def _leading_headers(self) -> list[str]:
        return ["No."]

    def _trailing_headers(self) -> list[str]:
        return []

    def _leading_items(self, record: dict) -> list[QTableWidgetItem]:
        return [QTableWidgetItem(str(record["id"]))]

    def _trailing_items(self, record: dict) -> list[QTableWidgetItem]:
        return []

    def _prepare(self, rows: list[dict]) -> None:
        """Se llama justo después de leer los registros, antes de dibujar la tabla."""

    def _build_extra_toolbar(self):
        """Devuelve un layout con una barra extra bajo el buscador, o None."""
        return None

    def _after_filter(self) -> None:
        """Se llama cada vez que cambian las filas visibles."""

    def _make_dialog(self, record: dict | None) -> RecordDialog:
        return RecordDialog(self, self.db, self.entity, record)

    def _save_new(self, dialog: RecordDialog) -> None:
        self.db.insert(self.entity, dialog.result_values)

    def _save_edit(self, record: dict, dialog: RecordDialog) -> None:
        self.db.update(self.entity, record["id"], dialog.result_values)

    # ------------------------------------------------------------------
    #  Mostrar datos
    # ------------------------------------------------------------------
    def refresh(self) -> None:
        self.rows = self.db.all(self.entity)
        self._prepare(self.rows)
        self.table.blockSignals(True)   # evita avisos mientras se llena la tabla
        self.table.setRowCount(len(self.rows))
        for r, record in enumerate(self.rows):
            items = (
                self._leading_items(record)
                + [QTableWidgetItem(self._display(record, f)) for f in self.visible_fields]
                + self._trailing_items(record)
            )
            for c, item in enumerate(items):
                self.table.setItem(r, c, item)
        self.table.blockSignals(False)
        self.table.resizeColumnsToContents()
        self._apply_filter()
        self._update_buttons()

    @staticmethod
    def _display(record: dict, f: Field) -> str:
        value = record[f.key]
        if f.kind == "date":
            date = QDate.fromString(value, DB_DATE)
            return date.toString(SHOW_DATE) if date.isValid() else value
        if f.kind == "number":
            return f"${value:,.2f}"
        if f.kind == "integer":
            return str(value)
        if f.kind == "ref":
            return record.get(f"{f.key}__label") or "—"
        if f.kind == "multiline":
            line = " ".join(value.split())
            return line if len(line) <= 60 else line[:57] + "…"
        return value

    def _apply_filter(self) -> None:
        text = self.search.text().strip().lower()
        for r in range(self.table.rowCount()):
            haystack = " ".join(
                self.table.item(r, c).text().lower() for c in range(self.table.columnCount())
            )
            self.table.setRowHidden(r, text not in haystack)
        self._after_filter()

    def _selected(self) -> dict | None:
        row = self.table.currentRow()
        return self.rows[row] if 0 <= row < len(self.rows) else None

    def _update_buttons(self) -> None:
        has_selection = self._selected() is not None
        self.edit_btn.setEnabled(has_selection)
        self.delete_btn.setEnabled(has_selection)

    def _on_double_click(self, index) -> None:
        if index.column() == self.check_column:
            return  # doble clic sobre la casilla ✓ no abre el formulario
        self.edit_record()

    # ------------------------------------------------------------------
    #  Acciones
    # ------------------------------------------------------------------
    def add_record(self) -> None:
        dialog = self._make_dialog(None)
        if dialog.exec():
            try:
                self._save_new(dialog)
            except ValueError as error:
                QMessageBox.warning(self, "No se pudo guardar", str(error))
                return
            self.refresh()

    def edit_record(self) -> None:
        record = self._selected()
        if record is None:
            return
        dialog = self._make_dialog(record)
        if dialog.exec():
            try:
                self._save_edit(record, dialog)
            except ValueError as error:
                QMessageBox.warning(self, "No se pudo guardar", str(error))
                return
            self.refresh()

    def delete_record(self) -> None:
        record = self._selected()
        if record is None:
            return
        answer = QMessageBox.question(
            self, "Eliminar", f"¿Eliminar este {self.entity.singular}? No se puede deshacer."
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        try:
            self.db.delete(self.entity, record["id"])
        except ValueError as error:
            QMessageBox.warning(self, "No se puede eliminar", str(error))
            return
        self.refresh()
