"""Ventana para editar los mensajes de WhatsApp."""
import re

from PySide6.QtWidgets import (
    QComboBox, QDialog, QDialogButtonBox, QFormLayout, QHBoxLayout, QLabel,
    QLineEdit, QMessageBox, QPlainTextEdit, QPushButton, QVBoxLayout, QWidget,
)

from app.dialog_utils import fit_to_screen, scrollable

from app import whatsapp
from app.schema import ESTADOS

SAMPLE = {
    "cliente": "Juan Pérez", "folio": "SJ-001", "vehiculo": "Nissan Versa",
    "placas": "ABC-123", "estado": "Recibido", "costo": "$1,500.00", "fecha": "24/09/2026",
}


class MessagesDialog(QDialog):
    def __init__(self, parent, db):
        super().__init__(parent)
        self.db = db
        self.setWindowTitle("Mensajes de WhatsApp")

        self.shop = QLineEdit(db.get_setting("wa_taller", whatsapp.DEFAULT_SHOP))
        self.country = QLineEdit(db.get_setting("wa_pais", whatsapp.DEFAULT_COUNTRY))
        self.country.setMaximumWidth(80)
        form = QFormLayout()
        form.setSpacing(12)
        form.addRow("Nombre del taller", self.shop)
        form.addRow("Código de país por defecto", self.country)

        # Un mensaje para enviar la orden y uno por cada estatus
        self.keys = [("orden", "Enviar orden de trabajo")] + [(e, f"Estatus: {e}") for e in ESTADOS]
        self.texts = {key: whatsapp.get_message(db, key) for key, _ in self.keys}
        self.current: str | None = None
        self.combo = QComboBox()
        for key, label in self.keys:
            self.combo.addItem(label, key)

        self.editor = QPlainTextEdit()
        self.editor.setFixedHeight(120)
        placeholders = "  ".join(f"{p} = {d}" for p, d in whatsapp.PLACEHOLDERS.items())
        hint = QLabel(f"Puedes usar estos datos dentro del mensaje:\n{placeholders}")
        hint.setObjectName("cardLabel")
        hint.setWordWrap(True)
        self.preview = QLabel()
        self.preview.setWordWrap(True)

        reset = QPushButton("Restablecer este mensaje")
        reset.setAutoDefault(False)
        reset.clicked.connect(self._reset)
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel
        )
        save = buttons.button(QDialogButtonBox.StandardButton.Save)
        cancel = buttons.button(QDialogButtonBox.StandardButton.Cancel)
        save.setText("Guardar")
        save.setObjectName("primary")
        cancel.setText("Cancelar")
        save.setAutoDefault(False)
        cancel.setAutoDefault(False)
        buttons.accepted.connect(self._save)
        buttons.rejected.connect(self.reject)

        row = QHBoxLayout()
        row.addWidget(reset)
        row.addStretch()
        row.addWidget(buttons)

        content = QWidget()
        content_layout = QVBoxLayout(content)
        content_layout.setContentsMargins(0, 0, 0, 0)
        content_layout.setSpacing(12)
        content_layout.addLayout(form)
        content_layout.addWidget(QLabel("Mensaje a editar"))
        content_layout.addWidget(self.combo)
        content_layout.addWidget(self.editor)
        content_layout.addWidget(hint)
        content_layout.addWidget(QLabel("Vista previa con datos de ejemplo:"))
        content_layout.addWidget(self.preview)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 20, 24, 20)
        layout.setSpacing(14)
        layout.addWidget(scrollable(content), 1)
        layout.addLayout(row)
        fit_to_screen(self, 680, 700)

        self.editor.textChanged.connect(self._update_preview)
        self.shop.textChanged.connect(self._update_preview)
        self.combo.currentIndexChanged.connect(self._switch)
        self._switch(0)

    def _switch(self, index: int) -> None:
        if self.current is not None:   # guarda lo escrito antes de cambiar de mensaje
            self.texts[self.current] = self.editor.toPlainText()
        self.current = self.combo.itemData(index)
        self.editor.setPlainText(self.texts[self.current])

    def _reset(self) -> None:
        default = whatsapp.DEFAULT_MESSAGES.get(self.current, whatsapp.FALLBACK_STATUS_MESSAGE)
        self.editor.setPlainText(default)

    def _update_preview(self) -> None:
        shop = self.shop.text().strip() or whatsapp.DEFAULT_SHOP
        values = {**SAMPLE, "taller": shop}
        self.preview.setText(whatsapp.render_message(self.editor.toPlainText(), values))

    def _save(self) -> None:
        self.texts[self.current] = self.editor.toPlainText()
        for key, label in self.keys:
            if not self.texts[key].strip():
                QMessageBox.warning(self, "Mensaje vacío", f"El mensaje «{label}» no puede quedar vacío.")
                return
        self.db.set_setting("wa_taller", self.shop.text().strip() or whatsapp.DEFAULT_SHOP)
        self.db.set_setting("wa_pais", re.sub(r"\D", "", self.country.text()) or whatsapp.DEFAULT_COUNTRY)
        for key, text in self.texts.items():
            whatsapp.save_message(self.db, key, text.strip())
        self.accept()
