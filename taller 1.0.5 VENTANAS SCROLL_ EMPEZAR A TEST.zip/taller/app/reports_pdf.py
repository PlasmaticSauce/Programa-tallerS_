"""Modelo de PDF para los reportes (Órdenes, Clientes, Almacén).

Es un diseño genérico: título, filtros usados, tabla y totales, en hoja
horizontal. Sirve para cualquier ReportData sin tocar código; para cambiar
look and feel (logo, colores, pie de página), edita build_html().
"""
from datetime import date, datetime
from html import escape

from PySide6.QtCore import QMarginsF
from PySide6.QtGui import QPageLayout, QPageSize, QTextDocument
from PySide6.QtPrintSupport import QPrinter

from app.reports_data import ReportData, format_cell

RED = "#A8232A"
BORDER = "#DDDDDD"
MUTED = "#666666"

ALIGN_RIGHT = {"money", "int"}


def build_html(report: ReportData) -> str:
    header_cells = "".join(f"<th>{escape(h)}</th>" for h in report.headers)

    body_rows = []
    for row in report.rows:
        cells = []
        for value, fmt in zip(row, report.formats):
            align = ' style="text-align:right;"' if fmt in ALIGN_RIGHT else ""
            cells.append(f"<td{align}>{escape(format_cell(value, fmt))}</td>")
        body_rows.append(f"<tr>{''.join(cells)}</tr>")

    totals_row = ""
    if report.rows and report.sum_columns:
        cells = []
        for i in range(len(report.headers)):
            if i == 0:
                cells.append("<td><b>TOTAL</b></td>")
            elif i in report.sum_columns:
                total = sum(row[i] for row in report.rows)
                cells.append(f'<td style="text-align:right;"><b>{escape(format_cell(total, report.formats[i]))}</b></td>')
            else:
                cells.append("<td></td>")
        totals_row = f'<tr style="border-top: 2px solid {RED};">{"".join(cells)}</tr>'

    return f"""
    <html><body style="font-family: Arial; font-size: 9pt; color: #1A1A1A;">
        <table width="100%" style="margin-bottom: 6px;"><tr>
            <td><span style="font-size: 18pt; font-weight: bold; color: {RED};">{escape(report.title)}</span></td>
            <td align="right" style="color: {MUTED}; font-size: 8pt;">
                Generado: {datetime.now():%d/%m/%Y %H:%M}
            </td>
        </tr></table>
        <p style="color: {MUTED}; font-size: 8pt; margin-top: 0;">Filtros: {escape(report.filters_text)}</p>
        <table width="100%" cellspacing="0" cellpadding="5" style="border-collapse: collapse;">
            <thead><tr style="background: {RED}; color: #FFFFFF;">{header_cells}</tr></thead>
            <tbody>{"".join(body_rows)}{totals_row}</tbody>
        </table>
        <p style="color: {MUTED}; font-size: 8pt; margin-top: 10px;">{len(report.rows)} registro(s)</p>
    </body></html>
    """


def _printer() -> QPrinter:
    printer = QPrinter(QPrinter.PrinterMode.HighResolution)
    layout = QPageLayout(
        QPageSize(QPageSize.PageSizeId.Letter),
        QPageLayout.Orientation.Landscape,   # horizontal: las tablas de reportes son anchas
        QMarginsF(12, 12, 12, 12),
        QPageLayout.Unit.Millimeter,
    )
    printer.setPageLayout(layout)
    return printer


def export_report_pdf(report: ReportData, path: str) -> None:
    printer = _printer()
    printer.setOutputFormat(QPrinter.OutputFormat.PdfFormat)
    printer.setOutputFileName(path)
    doc = QTextDocument()
    doc.setHtml(build_html(report))
    doc.print_(printer)
