"""Aquí se define QUÉ datos guarda cada pestaña.

Para agregar o quitar un campo (por ejemplo "Año del vehículo"), solo se edita
la lista de Field de la pestaña correspondiente. La tabla, el formulario de
alta y el de edición se generan solos a partir de esta lista.
"""
import re
from dataclasses import dataclass

# kind: text | multiline | number | integer | date | choice | ref | image

# Prefijo del folio de las órdenes: SJ-001, SJ-002...
FOLIO_PREFIX = "SJ-"


def format_folio(order_id: int) -> str:
    """El folio sale del número interno de la orden (nunca se repite, aunque se borre una)."""
    return f"{FOLIO_PREFIX}{order_id:03d}"


def normalize_plate(plate: str) -> str:
    """'abc-123' y 'ABC 123' cuentan como las mismas placas."""
    return re.sub(r"[^A-Z0-9]", "", plate.upper())


@dataclass(frozen=True)
class Field:
    key: str                     # nombre interno (sin espacios ni acentos)
    label: str                   # texto que ve el usuario
    kind: str = "text"
    required: bool = False
    options: tuple[str, ...] = ()  # opciones si kind="choice"
    ref: str = ""                # tabla enlazada si kind="ref"
    in_table: bool = True        # False = solo aparece en el formulario
    unique: bool = False         # True = no se permiten valores repetidos (ej. código de barras)


@dataclass(frozen=True)
class Entity:
    table: str                   # nombre de la tabla en la base de datos
    title: str                   # título de la pestaña
    singular: str                # "cliente", "orden"...
    fields: tuple[Field, ...]


ESTADOS = (
    "Recibido",
    "En diagnóstico",
    "En reparación",
    "Esperando refacción",
    "Terminado",
    "Entregado",
)
ESTADOS_CERRADOS = ("Terminado", "Entregado")
ESTADO_COBRADO = "Entregado"

CLIENTES = Entity(
    "clientes", "Clientes", "cliente",
    (
        Field("nombre", "Nombre", required=True),
        Field("telefono", "Teléfono"),
        Field("correo", "Correo"),
        Field("direccion", "Dirección"),
        Field("notas", "Notas", "multiline", in_table=False),
    ),
)

PROVEEDORES = Entity(
    "proveedores", "Proveedores", "proveedor",
    (
        Field("empresa", "Empresa", required=True),
        Field("contacto", "Contacto"),
        Field("telefono", "Teléfono"),
        Field("correo", "Correo"),
        Field("productos", "Productos que surte", "multiline"),
        Field("notas", "Notas", "multiline", in_table=False),
    ),
)

# Las placas van antes que cliente y vehículo para que el autorrelleno se vea natural.
ORDENES = Entity(
    "ordenes", "Órdenes de trabajo", "orden",
    (
        Field("fecha", "Fecha de ingreso", "date", required=True),
        Field("placas", "Placas"),
        Field("cliente_id", "Cliente", "ref", required=True, ref="clientes"),
        Field("vehiculo", "Vehículo", required=True),
        Field("anio", "Año", "integer", in_table=False),
        Field("kilometraje", "Kilometraje", "integer", in_table=False),
        Field("mecanico", "Mecánico asignado", in_table=False),
        Field("fecha_promesa", "Fecha prometida de entrega", "date", in_table=False),
        Field("servicio", "Servicio a realizar", "multiline", required=True),
        Field("estado", "Estado", "choice", options=ESTADOS),
        Field("costo", "Costo total", "number"),
        Field("anticipo", "Anticipo pagado", "number"),
        Field("notas", "Notas internas", "multiline", in_table=False),
    ),
)

PRODUCTOS = Entity(
    "productos", "Almacén", "producto",
    (
        Field("codigo", "Código de barras", required=True, unique=True),
        Field("nombre", "Nombre", required=True),
        Field("categoria", "Categoría"),
        Field("existencia", "Existencia", "integer"),
        Field("imagen", "Imagen", "image", in_table=False),
        Field("notas", "Notas", "multiline", in_table=False),
    ),
)

# El orden importa: las tablas referenciadas (clientes) van antes que las que las usan.
ENTITIES = {e.table: e for e in (CLIENTES, PROVEEDORES, ORDENES, PRODUCTOS)}
